#This creates formtemplate def by reading fields
import json
import random



def createformtemplate(src_json):
	templatedef = { "templateName": "Clark_County_Hydrants_{0}".format(random.randint(1,10000)), "category": "Hydrants"}
	#formtemplatedef= {"id": "0", "component": "textInput", "editable": "true", "index": "0", "label": "FID", "description": "", "placeholder": "TextInput", "options": [], "required": "false"}
	formtemplatedef_org =  {"component": "textInput", "editable": "true", "options": [], "required": "false"}
	template_list = []
	for index,ele in enumerate(src_json['fields']):
		newformtempdef = formtemplatedef_org.copy()
		formtemplatedef = {}
		eletype = ele["type"]
		elename = ele["name"]
		formtemplatedef["id"]=str(index)
		formtemplatedef["index"]=str(index)
		formtemplatedef["component"] = "textInput"
		if "Integer" in eletype or "Double" in eletype:
			 formtemplatedef["component"] = "numberInput"
		formtemplatedef["label"] = elename
		formtemplatedef["description"] = elename
		formtemplatedef["placeholder"] = elename
		newformtempdef.update(formtemplatedef)
		template_list.append(newformtempdef)
	templatedef.update({"formTemplateDef":template_list})
	return templatedef
		
#Uncomment the below lines for testing
#from srcjson import src_json
#print createformtemplate(src_json)
