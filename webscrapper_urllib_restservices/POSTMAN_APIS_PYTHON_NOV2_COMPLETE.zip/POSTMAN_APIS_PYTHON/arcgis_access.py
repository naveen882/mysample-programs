import json
from pprint import pprint
import urllib
import urllib2
import random
import uuid
import requests
from form_template import createformtemplate
from notebook import getnotebook_guid
from create_points import createpoints
import time

uid = uuid.uuid4()
uid = uid.urn[9:]
tm = time.time()
tm_ms = int(round(time.time() * 1000))

def getformdefelements(formdefele,formtemplate_ele):
   attributes = {}
   for i,ele in enumerate(formdefele):
      key,value,textinput = [None,None,None]
      for k in ele:
         if k == 'label':
            key = ele[k]
         if k == 'value':
            value = ele[k]
            if 'null' in str(ele[k]):
               value = ''
            if '#' in ele[k] :
               value = ele[k].split('#')[-1]
               if 'null' in str(value):
                  value = ''
         if k == 'id':
            if ele[k] == formtemplate_ele[i]['id']: #This condition is assumuing that the equal number of elements in formdef and formtemplatedef
               #"component": "textInput",
               if formtemplate_ele[i]['component'] == 'textInput':
                  textinput = "str"

      if key is not None and value is not None:
         if 'unicode' in str(type(value)):
            try:
               value=json.loads(value)
            except Exception as e:
               pass
         attributes.update({key:value})
         if textinput == "str":
            attributes.update({key:str(value)})

   return attributes


class convert_json(object):
	def __init__(self):
		self.json = None
	def read_json(self,file_src):
		with open(file_src) as data_file:
			 self.json = json.load(data_file)
		return self.json
	def get_url_data(self,url,request_method,content_type="None",data=None,headers={}):
		method = request_method
		handler = urllib2.HTTPHandler(debuglevel=0)
		opener = urllib2.build_opener(handler)
		if data is not None:
			try:
				data = urllib.urlencode(data)
			except Exception as e:
				print e
		request = urllib2.Request(url,data,headers)
		if content_type is not None:
			request.add_header("Content-Type",content_type)
		request.get_method = lambda: method
		try:
			connection = opener.open(request)
		except urllib2.HTTPError,e:
			connection = e

		if connection.code == 200:
			resp = connection.read()
			return resp
		return None
	def get_content(self,url,request_method,content_type,auth,data=None,headers={}):
		try:
			req = urllib2.Request(url, headers={'Content-type': 'application/json','Authorization': auth})
			r = urllib2.urlopen(req,json.dumps(data))
			return r.code,r.read()
		except Exception as e:
			print e
	def post_data(self,url,data={}):
		r = requests.post(Send_to_ArcGIS,data=data)
		return r.json()

cv_json = convert_json()
authURL = "http://199.233.241.131:8080/edgeServer/"
arcgis_url = "https://www.arcgis.com/sharing/rest/generateToken"
input_param = {'username' : 'davidgbasil','password':'TerraGoEdge1','ip':'192.168.1.40','client' : 'referer','f':'json','referer':'arcgis.com','expiration':'21600'}
response = cv_json.get_url_data(arcgis_url,'POST','application/x-www-form-urlencoded',input_param)
if response is not None:
	response = json.loads(response)
	print "Arcgis token received"
	esri_geo_url = 'http://services6.arcgis.com/BwqsKUvIJgw595E5/arcgis/rest/services/Clark_County_Hydrants/FeatureServer/0/query?f=json&token=%s&where=1=1&outFields=*&outSR={"wkid":4326}'%(str(response['token']))
	esri_geo_response = cv_json.get_url_data(esri_geo_url,'GET','application/json')
	esri_geo_response = json.loads(esri_geo_response)
	print "Arcgis response received"

edge_access_url = "{authURL}oauth/token?grant_type=password&username=admin&password=admin&client_id=edgerestapp".format(**locals())
edge_token = cv_json.get_url_data(edge_access_url,'POST','application/json')
if edge_token is not None:
	print "Edge token received"
	edge_token = json.loads(edge_token)
	edge_token = edge_token['access_token']
	form_template_url = "{authURL}rest/formTemplates".format(**locals())
	auth = "Bearer {0}".format(edge_token)
	edge_template_header_param = {"Authorization":auth,"Content-type": "application/json"}
	template_data = createformtemplate(esri_geo_response)
	edge_template_code,edge_template_response = cv_json.get_content(form_template_url,'POST','application/json',auth,template_data)
	edge_template_response = json.loads(edge_template_response)
	print "Edge template id received"

	notebook_url = "{authURL}rest/notebooks".format(**locals())
	notebook_body = getnotebook_guid(str(edge_template_response['templateId']))
	notebook_code,notebookGuid = cv_json.get_content(notebook_url,'POST','application/json',auth,notebook_body)
	notebookGuid = json.loads(notebookGuid)
	notebookGuid = notebookGuid['notebookGuid']
	print "Notebook id received"

	pointnote_create1_url = "{authURL}/rest/notebooks/{notebookGuid}/notes".format(**locals())
	for ft in esri_geo_response['features']:
		pointnote1_body = createpoints(esri_geo_response,edge_template_response['templateId'],notebookGuid,uid,ft["geometry"]['x'],ft["geometry"]['y'],template_data,ft['attributes'])
		#print json.dumps(pointnote1_body)
		point1_code,point1 = cv_json.get_content(pointnote_create1_url,'POST','application/json',auth,pointnote1_body)
	print "noteboogGuid is {notebookGuid}".format(**locals())
	print "==================complete============================="
