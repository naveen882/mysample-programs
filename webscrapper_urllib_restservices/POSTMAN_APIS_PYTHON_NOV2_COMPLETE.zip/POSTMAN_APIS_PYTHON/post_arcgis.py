import json
from pprint import pprint
import urllib
import urllib2
import random
import uuid
import requests
from form_template import createformtemplate
from notebook import getnotebook_guid
from create_points import createpoints
import time
from copy import deepcopy

uid = uuid.uuid4()
uid = uid.urn[9:]
tm = time.time()
tm_ms = int(round(time.time() * 1000))

def getformdefelements(formdefele,formtemplate_ele):
   attributes = {}
   for i,ele in enumerate(formdefele):
      key,value,textinput = [None,None,None]
      for k in ele:
         if k == 'label':
            key = ele[k]
         if k == 'value':
            value = ele[k]
            if 'null' in str(ele[k]):
               value = ''
            if '#' in ele[k] :
               value = ele[k].split('#')[-1]
               if 'null' in str(value):
                  value = ''
         if k == 'id':
            if ele[k] == formtemplate_ele[i]['id']: #This condition is assumuing that the equal number of elements in formdef and formtemplatedef
               #"component": "textInput",
               if formtemplate_ele[i]['component'] == 'textInput':
                  textinput = "str"

      if key is not None and value is not None:
         if 'unicode' in str(type(value)):
            try:
               value=json.loads(value)
            except Exception as e:
               pass
         attributes.update({key:value})
         if textinput == "str":
            attributes.update({key:str(value)})

   return attributes


class convert_json(object):
	def __init__(self):
		self.json = None
	def read_json(self,file_src):
		with open(file_src) as data_file:
			 self.json = json.load(data_file)
		return self.json
	def get_url_data(self,url,request_method,content_type="None",data=None,headers={}):
		method = request_method
		handler = urllib2.HTTPHandler(debuglevel=0)
		opener = urllib2.build_opener(handler)
		if data is not None:
			try:
				data = urllib.urlencode(data)
			except Exception as e:
				print e
		request = urllib2.Request(url,data,headers)
		if content_type is not None:
			request.add_header("Content-Type",content_type)
		request.get_method = lambda: method
		try:
			connection = opener.open(request)
		except urllib2.HTTPError,e:
			connection = e

		if connection.code == 200:
			resp = connection.read()
			return resp
		return None
	def get_content(self,url,request_method,content_type,auth,data=None,headers={}):
		try:
			req = urllib2.Request(url, headers={'Content-type': 'application/json','Authorization': auth})
			r = urllib2.urlopen(req,json.dumps(data))
			return r.code,r.read()
		except Exception as e:
			pass
	def post_data(self,url,data={}):
		r = requests.post(Send_to_ArcGIS,data=data)
		return r.json()


cv_json = convert_json()
authURL = "http://199.233.241.131:8080/edgeServer/"
notebook_id="8841fefa-238a-4172-9906-931eda88e5df"
updated_time = "1478024538614"
arcgis_url = "https://www.arcgis.com/sharing/rest/generateToken"
input_param = {'username' : 'davidgbasil','password':'TerraGoEdge1','ip':'192.168.1.40','client' : 'referer','f':'json','referer':'arcgis.com','expiration':'21600'}
response = cv_json.get_url_data(arcgis_url,'POST','application/x-www-form-urlencoded',input_param)
if response is not None:
	response = json.loads(response)

edge_access_url = "{authURL}oauth/token?grant_type=password&username=admin&password=admin&client_id=edgerestapp".format(**locals())
edge_token = cv_json.get_url_data(edge_access_url,'POST','application/json')
if edge_token is not None:
	print "Edge token received"
	edge_token = json.loads(edge_token)
	edge_token = edge_token['access_token']
	form_template_url = "{authURL}rest/formTemplates".format(**locals())
	auth = "Bearer {0}".format(edge_token)
	edge_template_header_param = {"Authorization":auth,"Content-type": "application/json"}
	edit_body_url = "{authURL}/rest/notebooks/{notebook_id}/notes/getAddedEdited?updatedDateTime={updated_time}".format(**locals())
	edit_body_response = cv_json.get_url_data(edit_body_url,'GET','application/json',None,edge_template_header_param)
	json_add_edit = json.loads(edit_body_response)
	if len(json_add_edit['added']) > 0 or len(json_add_edit['edited']) > 0:
		add_list = json_add_edit['added']
		edit_list = json_add_edit['edited']
		notes_url = "{authURL}rest/notebooks/{notebook_id}/notes/".format(**locals())
		notes = cv_json.get_url_data(notes_url,'GET','application/json',None,edge_template_header_param)
		src_dict = json.loads(notes)
		json_struct = {"id":0 ,'adds':[],'updates':[]}
		added_list=[]
		edit_body=[]
		for elements in src_dict:
			for index, element in enumerate(elements['formData']):
				geometry = json.loads(elements['geometry'])
				coordinates = geometry['geometry']['coordinates']
				formdef = json.loads(element['formDef']) #unicode element
				formtemplatedef = element['formTemplateDef']
				if str(elements['noteGuid']) in add_list or str(elements['noteGuid']) in edit_list:
					print elements['noteGuid']
					li = {'li':{"geometry":{ "x": coordinates[0],"y": coordinates[1] ,"spatialReference":{"wkid": 4326}}}}
					for ele in formdef:
						if 'FID' in ele['label']:
							attributes = getformdefelements(formdef,formtemplatedef)
							li['li']['attributes'] = attributes
							if str(elements['noteGuid']) in add_list and str(elements['noteGuid']) not in added_list:
								tmp_struct_adds = deepcopy(json_struct)
								added_list.append(str(elements['noteGuid']))
								tmp_struct_adds['adds'].append(li['li'])
								edit_body.append(json.dumps(tmp_struct_adds))
							if str(elements['noteGuid']) in edit_list and str(elements['noteGuid']) not in added_list:
								tmp_struct_updates = deepcopy(json_struct)
								added_list.append(str(elements['noteGuid']))
								tmp_struct_updates['updates'].append(li['li'])
								edit_body.append(json.dumps(tmp_struct_updates))

	if len(edit_body) > 0:
		for e in edit_body:
			Send_to_ArcGIS = 'http://services6.arcgis.com/BwqsKUvIJgw595E5/arcgis/rest/services/Clark_County_Hydrants/FeatureServer/applyEdits?f=json&token={0}&edits={1}'.format(response['token'],str(e))
			argis_response = cv_json.post_data(Send_to_ArcGIS)
			print "Added successfully"
print "==================complete============================="



