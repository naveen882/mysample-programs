#This creates formtemplate def by reading fields
import json
import random
import time

tm_ms = int(round(time.time() * 1000))

#groups id is hardcoded as of now

def getnotebook_guid(template_id):
	notebook = {
        "notebookName": "Clark_County_Hydrants_{0}".format(random.randint(1,10000)),
        "notebookDescription": None,
        "users": [],
        "groups": ["t13c5234-1593-4568-90e50-a6cb5c1ac11r55"],
        "quickNoteFormTemplateId": None,
        "quickNoteNameType": None,
        "quickNoteCustomName": None,
        "lastUpdatedTime": tm_ms, #time in milliseconds
        "createdBy": "admin",
        "notebookGuid": "",
        "notesCount": 0,
        "forms":["{0}".format(template_id)],
        "basemaps": [],
        "wmsLayers": []
    }
	return notebook
		
#Uncomment the below lines for testing
#print getnotebook_guid("123")
