#This creates formtemplate def by reading fields
import json
import random
from collections import OrderedDict as od
import time
import uuid

tm_ms = int(round(time.time() * 1000))
uid = uuid.uuid4()
new_uid = uid.urn[9:]

def createpoints(src_json,template_id,notebookguid,uid,x,y,template_data,attributes):
	#point_json =  {"PDOP":"4","gpsTime":"22","altitude":"5","title":"1","formData":[{"formTemplateGuid":template_id,"category":"ESRI","formGuid":uid,"name":"ESRIWHydrantForm","formValidationAction":"None","formDef":[{"id":0,"label":"FID","value":"1","count":0,"groupId":-1,"groupRepeatableCount":-1,"isGroup":"false"},{"id":1,"label":"FEATUREID","value":"356","count":0,"groupId":-1,"groupRepeatableCount":-1,"isGroup":"false"}]}],"satellitesCount":2,"description":"ESRI Notes","HDOP":"3","tags":["ESRItag"],"notesType":"forms","isTaskNote":"false","locationDescription":"ESRI Location1","speed":"3","horizontalAccuracy":"3","noteGuid":uid,"dictionary":[],"locationProvider":"Google.com","geometry":"{\"type\":\"Feature\",\"geometry\":{\"type\":\"Point\",\"coordinates\":[-84.0219915526707,40.13278095199061]},\"properties\":{\"name\":\"\",\"distance\":[]}}","VDOP":"5","createdBy":"admin","lockType": "4","createdDateTime":1471613694000,"bearing":"9","revisions":[]}
	formdef_list = []
	#point_json = od()
	point_json = {"PDOP":"4","gpsTime":"22","altitude":"5","title":str(attributes['FID']),"formData":[{"formTemplateGuid":str(template_id),"formTemplateDef":template_data["formTemplateDef"],"category":"ESRI","formGuid":uid,"name":"ESRIWHydrantForm","formValidationAction":"None"}],"satellitesCount":2,"description":"ESRI Notes","HDOP":"3","tags":["ESRItag"],"notesType":"forms","isTaskNote":"false","locationDescription":"ESRI Location1","speed":"3","horizontalAccuracy":"3","dictionary":[],"locationProvider":"Google.com","VDOP":"5","createdBy":"admin","lockType": "4","createdDateTime":tm_ms,"bearing":"9","revisions":[]}
	formdef_org = {"id":0,"label":"FID","value":"1","count":0,"groupId":-1,"groupRepeatableCount":-1,"isGroup":"false",}
	for index,ele in enumerate(src_json['fields']):
		#print attributes
		newformdef = formdef_org.copy()
		formdef = {}
		formdef['id'] = index
		formdef['label'] = ele['name']
		formdef['value'] = str(random.randint(1,100))
		#formdef['value'] = attributes.values()[index]
		newformdef.update(formdef)
		formdef_list.append(newformdef)
	point_json["formData"][0].update({"formDef":formdef_list})
	geometry = {"type":"Feature","geometry":{"type":"Point","coordinates":[x,y]},"properties":{"name":"","distance":[]}}
	#geometry = json.loads(geometry)
	geometry = str(json.dumps(geometry))
	point_json["geometry"] = geometry
	#point_json =  {"PDOP":"4","gpsTime":"22","altitude":"5","title":"1","formData":[{"formTemplateGuid":template_id,"category":"ESRI","formGuid":uid,"name":"ESRIWHydrantForm","formValidationAction":"None","formDef":[{"id":0,"label":"FID","value":"1","count":0,"groupId":-1,"groupRepeatableCount":-1,"isGroup":"false"},{"id":1,"label":"FEATUREID","value":"356","count":0,"groupId":-1,"groupRepeatableCount":-1,"isGroup":"false"}]}],"satellitesCount":2,"description":"ESRI Notes","HDOP":"3","tags":["ESRItag"],"notesType":"forms","isTaskNote":"false","locationDescription":"ESRI Location1","speed":"3","horizontalAccuracy":"3","noteGuid":uid,"dictionary":[],"locationProvider":"Google.com","geometry":"{\"type\":\"Feature\",\"geometry\":{\"type\":\"Point\",\"coordinates\":[-84.0219915526707,40.13278095199061]},\"properties\":{\"name\":\"\",\"distance\":[]}}","VDOP":"5","createdBy":"admin","lockType": "4","createdDateTime":1471613694000,"bearing":"9","revisions":[]}
	return point_json
	
	
#Uncomment the below lines for testing
#from srcjson import src_json
#print createpoints(src_json,1,2,3,4,5,6,7)
