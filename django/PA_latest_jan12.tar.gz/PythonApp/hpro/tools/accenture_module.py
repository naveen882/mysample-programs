import re
import os
import sys

remove_pat=re.compile(r'(<.*?>)',re.MULTILINE)
html_body=re.compile(r'(<body.*>(\n|.)*?</body>)',re.IGNORECASE|re.MULTILINE)
Parent_cv_dir="C:\\Allowed\\toparse\\Accenture"
skill_file_dict={'r2r':'r2r_skill.txt',
                 'p2p':'p2p_skill.txt',
                 'o2c':'o2c_skill.txt'}
def applyRegexRule(skill):
    myRegex=skill.replace(" ","\w*\s*").replace(".","\s*(\.|\s)?\s*")
    myRegex= "\s*%s\w*\s*" % (myRegex,)
##    print myRegex
    return myRegex

skill_dict={}

for fileType in skill_file_dict:
    mySkillFile= "%s\%s" % (Parent_cv_dir,skill_file_dict[fileType])
    with open(mySkillFile,'r') as myfileObj:
        myStr=myfileObj.read()
        myfileObj.close()
        for line in myStr.split("\n"):
            skill_dict[line]={'type':fileType,'regex':re.compile(r'('+applyRegexRule(line)+')',re.IGNORECASE),'count':0}
##            print applyRegexRule(line)

##print skill_dict

##multiDir=['O2C','P2P','R2R']
html_cv_dir="cv_html"

cv_list=[]
for subDir in skill_file_dict:
    myFilePath="%s\%s\%s" % (Parent_cv_dir,subDir,html_cv_dir)
    cv_list+=(map(lambda x: "%s\%s" % (myFilePath,x),filter(lambda x: x.find(".html") >-1 ,os.listdir(myFilePath))))

##print len(cv_list)

cnt=1
for html_cv in cv_list:
    try:
        with open(html_cv, 'r') as htmlFileObj:
            html_body_search=re.search(html_body,htmlFileObj.read())
            try:
                htmlBody=html_body_search.group()
            except:
                htmlBody="NA"
            htmlStr=re.sub(remove_pat,'|',htmlBody)
##            htmlStr=htmlStr.replace("\n"," ").replace("  ","")
##            print htmlStr
            skill_per_cv=""
            for key in skill_dict:
                skill_count=len(re.findall(skill_dict[key]['regex'],htmlStr))
                if skill_count > 0:
                    skill_per_cv+="%s[%s]-%s," % (key,skill_dict[key]['type'],skill_count)
            print cnt,os.path.basename(html_cv),skill_per_cv[:-1]

    except Exception as e:
        print html_cv,"HTML file opening failed for email Search",e
    cnt+=1



