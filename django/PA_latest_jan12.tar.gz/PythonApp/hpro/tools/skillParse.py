import os
import sys
import re
import datetime








startTime=datetime.datetime.today()

cv_dir="F:\\Projects\\HirePro\\cv_txt"
html_cv_dir="F:\\Projects\\HirePro\\cv_html"
numberPlanFile="numberPlan.txt"
tier1_CollegeRegexFile="t1_collegeList.txt"
tier2_CollegeRegexFile="t2_collegeList.txt"
hsc_regexFile="hsc.txt"
ssc_regexFile="ssc.txt"
numFile=open(numberPlanFile,'r')
numFileStr= numFile.read()
numFile.close()


def createRegex(regexFile):
    with open(regexFile,'r') as myfileObj:
        myStr=myfileObj.read()
        myfileObj.close()
    myRegex=myStr.replace("\n","\s*|\s*").replace(" ","\s*").replace(".","\s*(\.|\s)?\s*")
    myRegex='\s*'+myRegex+'\s*'
##    print myRegex
    return myRegex


cv_list=map(lambda x: "%s\%s" % (cv_dir,x),filter(lambda x: x.find(".txt") >-1 ,os.listdir(cv_dir)))
skill_lsit=open("skillsdump","r").read().lower().split("\n")
##skill_search_pattern="|".join(skill_lsit)
skill_lsit=map(lambda x: " %s " % (x,),skill_lsit)

# global Search Patterns
global_degree_pattern=re.compile(r'(Bachelor|Master|Administration|Application|science|Tech|Engg|Technology|BE|degree|University|Engineering|science|diploma|Distinction|institute|college|(B(\.|-|\s)(\s*tech|E(\.|\s|:|\n)))|(BTECH)|(B\.E)|(M(\.|-|\s)(\s*tech|E(\.|\s|:|\n)))|(MTECH)|(M\.E))',re.IGNORECASE)
global_branch_pattern=re.compile(r'(Bachelor|Master|Administration|Application|science|Tech|Engg|Technology|BE|degree|University|Engineering|science|diploma|Distinction|institute|college|(B(\.|-|\s)(\s*tech|E(\.|\s|:|\n)))|(BTECH)|(B\.E)|(M(\.|-|\s)(\s*tech|E(\.|\s|:|\n)))|(MTECH)|(M\.E))',re.IGNORECASE)
global_pct_pattern=re.compile(r'(Bachelor|Master|Tech|Technology|BE|(B(\.|-)\s*(E(\.|\s|:|-)))|degree|University|Engineering|science|institute|college|diploma|Distinction)',re.IGNORECASE)
global_location_pattern=re.compile(r'(place|address|presently|currently|[\s]*(working[\s]*as)[\s]*|[\s]*(till[\s]*date)[\s]*|[\s]*(Personal[\s]*Details)[\s]*)',re.IGNORECASE)
global_year_pattern=re.compile(r'(((master|bachelor)(\s*.{0,5}?)(Engineering|Technology|Computer\s*Application|Business\s*Administration|science))|((^|\s)(B(\.|-)|M(\.|-))(\s*tech|E\s*|\sE\s))|\s+(B\.*A(\.|\s)|\spost\s*grad\w*\sdip\w*\s|B\.*B\.*A(\.|\s)|M\.*B\.*A(\.|\s)|M\.*C\.*A(\.|\s)|B\.*C\.*A(\.|\s)|B\.*S\.*C(\.|\s)|M\.*S\.*C(\.|\s)|\sB\.*A\.\s*|Distinction))',re.IGNORECASE)
global_birth_pattern=re.compile(r'(birth|DOB|personal)',re.IGNORECASE)
global_gender_pattern=re.compile(r'(gender|male|female|sex)',re.IGNORECASE)
global_email_pattern=re.compile(r'(email|gmail|yahoo|rediff|indiatimes|alternate|personal|outlook|hotmail|aol|ymail|googlemail|@)',re.IGNORECASE)
global_name_pattern=re.compile(r'(^name|(^|\s*)personal|(^|\s*)profile.*|(^|\s*)Full\s*name)',re.IGNORECASE)
global_collegeTier_pattern=re.compile(r'(Bachelor|Master|Administration|Application|science|Tech|Engg|Technology|BE|degree|University|Engineering|science|diploma|Distinction|institute|college|(B(\.|-|\s)(\s*tech|E(\.|\s|:|\n)))|(BTECH)|(B\.E)|(M(\.|-|\s)(\s*tech|E(\.|\s|:|\n)))|(MTECH)|(M\.E))',re.IGNORECASE)
global_hsc_pattern=re.compile(r'('+createRegex(hsc_regexFile)+')',re.IGNORECASE)
global_ssc_pattern=re.compile(r'('+createRegex(ssc_regexFile)+')',re.IGNORECASE)

# Sub Patterns
##degree_pattern=re.compile(r'(((master|bachelor)(\s*.{0,5}?)(Engineering|Technology|Computer\s*Application|Business\s*Administration|science))|((B(\.|-)|M(\.|-))(\s*tech|E\s*|\sE(\.|\s|:)))|\s+(B\.*A(\.|\s)|\spost\s*grad\w*\sdip\w*\s|B\.*B\.*A(\.|\s)|M\.*B\.*A(\.|\s)|M\.*C\.*A(\.|\s)|B\.*C\.*A(\.|\s)|B\.*S\.*C(\.|\s)|M\.*S\.*C(\.|\s)|\s+B\.*A\.\s*|diploma))',re.IGNORECASE)
##branch_pattern=re.compile(r'((\s*Computer\s*.{0,5}?Science|\s*Electronic\w*\s*.{0,5}?comm\w*|\s*Mech\w*?l\s*|\s*Information\s*.{0,4}?Technology|\s*Electrical\s*|\s*Instrumentation\w*\s*|M\.*C\.*A(\.|\s)|B\.*C\.*A(\.|\s)|B\.*S\.*C(\.|\s)|M\.*S\.*C(\.|\s)|E\.*C\.*E(\.|\s)|C\.*S\.*E(\.|\s)|\s*B\.*A\.\s*)|((master|bachelor)(\s*.{0,5}?)(Computer\s*Application|Business\s*Administration|\s*of\s*science)))',re.IGNORECASE)
dict_college_pattern={"T1":re.compile(r'('+createRegex(tier1_CollegeRegexFile)+')',re.IGNORECASE),
                      "T2":re.compile(r'('+createRegex(tier2_CollegeRegexFile)+')',re.IGNORECASE)}
dict_degree_pattern={"MTECH":re.compile(r'(((master)(\s*.{0,5}?)(Engineering|Technology))|((^|\s)M(\.|-|\s)(\s*tech|E(\.|\s|:|\n)))|((^|\s)MTECH)|(M\.E))',re.IGNORECASE),
             "BTECH":re.compile(r'(((bachelor)(\s*.{0,5}?)(Engineering|Technology))|((^|\s)B(\.|-|\s)(\s*tech|E(\.|\s|:|\n)))|((^|\s)BTECH)|(B\.E))',re.IGNORECASE),
             "MSC":re.compile(r'(((master)(\s*.{0,5}?)(Science))|((^|\s)M\.*S\.*C(\.|\s|\n|$|-)))',re.IGNORECASE),
             "BSC":re.compile(r'(((bachelor)(\s*.{0,5}?)(Science))|((^|\s)B\.*S\.*C(\.|\s|\n|$|-)))',re.IGNORECASE),
             "MBA":re.compile(r'(((master)(\s*.{0,5}?)(Business\s*Administration))|((^|\s)M\.*B\.*A(\.|\s|\n|$|-)))',re.IGNORECASE),
             "BBA":re.compile(r'(((bachelor)(\s*.{0,5}?)(Business\s*Administration))|((^|\s)B\.*B\.*A(\.|\s|\n|$|-)))',re.IGNORECASE),
             "MCA":re.compile(r'(((master)(\s*.{0,5}?)(Computer\s*Application))|((^|\s)M\.*C\.*A(\.|\s|\n|$|-)))',re.IGNORECASE),
             "BCA":re.compile(r'(((bachelor)(\s*.{0,5}?)(Computer\s*Application))|((^|\s)B\.*C\.*A(\.|\s|\n|$|-)))',re.IGNORECASE),
             "BA":re.compile(r'(((bachelor)(\s*.{0,5}?)(Art))|(\s+B\.*A\.\s*))',re.IGNORECASE),
             "PGDM":re.compile(r'(\spost\s*grad\w*\s*dip\w*\s)',re.IGNORECASE),
             "DIPLOMA":re.compile(r'(\s*diploma\s*)',re.IGNORECASE)
             }
dict_branch_pattern={"CSE":re.compile(r'((\s*Computer\s*.{0,5}?Science)|(C\.*S\.*E(\.|\s))|(\sC\.*S\s))',re.IGNORECASE),
                    "ECE":re.compile(r'((\s*Electronic\w*\s*.{0,5}?comm\w*)|(E\.*C\.*E(\.|\s))|(Electronics))',re.IGNORECASE),
                    "MECHANICAL":re.compile(r'(\s*Mechanical\s*)',re.IGNORECASE),
                    "IT":re.compile(r'(\s*Information\s*.{0,4}?Technology)',re.IGNORECASE),
                    "ELECTRICAL":re.compile(r'(\s*electrical\s*)',re.IGNORECASE),
                    "INSTRUMENTATION":re.compile(r'(\s*Instrumentation\s*)',re.IGNORECASE),
                    "MSC":re.compile(r'(((master)(\s*.{0,5}?)(Science))|(M\.*S\.*C(\.|\s)))',re.IGNORECASE),
                    "BSC":re.compile(r'(((bachelor)(\s*.{0,5}?)(Science))|(B\.*S\.*C(\.|\s)))',re.IGNORECASE),
                    "MBA":re.compile(r'(((master)(\s*.{0,5}?)(Business\s*Administration))|((^|\s)M\.*B\.*A(\.|\s)))',re.IGNORECASE),
                    "BBA":re.compile(r'(((bachelor)(\s*.{0,5}?)(Business\s*Administration))|(B\.*B\.*A(\.|\s)))',re.IGNORECASE),
                    "MCA":re.compile(r'(((master)(\s*.{0,5}?)(Computer\s*Application))|(M\.*C\.*A(\.|\s)))',re.IGNORECASE),
                    "BCA":re.compile(r'(((bachelor)(\s*.{0,5}?)(Computer\s*Application))|(B\.*C\.*A(\.|\s)))',re.IGNORECASE),
                    }
pct_pattern=re.compile(r"(([\d]{2}[.]?[\d]{0,2}[\s]*(%|percent))|([\d][.][\d]{1,2}[\W]*(gpa|cgpa))|((gpa|cgpa)[\W]*[\d][.][\d]{1,2}))",re.IGNORECASE)
location_pattern=re.compile(r'[\s]*(Bangalore|Gurgaon|new\s*delhi|noida|hyderabad|mumbai|chennai|manesar|pune|Bengaluru)',re.IGNORECASE)
##mobile_pattern=re.compile(r'((0|91|91-|0-)?(\d{10}|\d{5}.{0,5}?\d{5}))',re.MULTILINE)
mobile_pattern=re.compile(r'((91)?(9|8|7)(\d{9}|\d{4}.\d{5}|\d{2}(-|\s)\d{3}(-|\s*)\d{4}|\d{3}(-|\s)\d{3}(-|\s*)\d{3}|\d{2}(-|\s)\d{4}(-|\s*)\d{3}))',re.MULTILINE)
year_pattern=re.compile(r'(((19|20)(\d{2}).{0,5}?((19|20)(\d{2})))|((19|20)(\d{2}).{0,5}?(\d{2}))|((19|20)(\d{2})))',re.IGNORECASE)
birth_pattern=re.compile(r'(((?<=birth)|(?<=DOB))?((19)(\d{2})))',re.IGNORECASE)
gender_pattern=re.compile(r'(male|female)',re.IGNORECASE)
email_pattern=re.compile(r'((\w*[.]*\w*[.]*\w+[\s]*(@)\w+[.]*\w*[.]*(com|net|in))(.{0,5}(\w*[.]*\w*[.]*\w+[\s]*(@)\w+[.]*\w*[.]*(com|net|in)?))?)',re.IGNORECASE)
name_pattern=re.compile(r'(.*)')
find_digit_pattern=re.compile(r'((\d*))',re.IGNORECASE)
##college_pattern=re.compile(r'(.*)')

##print dict_college_pattern
##sys.exit()

dictConfig={}
dictConfig['degree']={}
dictConfig['degree']['keyWord']=global_degree_pattern
dictConfig['degree']['pattern']=dict_degree_pattern
dictConfig['degree']['result']=[]
dictConfig['degree']['text']=[]
dictConfig['branch']={}
dictConfig['branch']['keyWord']=global_branch_pattern
dictConfig['branch']['pattern']=dict_branch_pattern
dictConfig['branch']['result']=[]
dictConfig['branch']['text']=[]
dictConfig['degreePct']={}
dictConfig['degreePct']['keyWord']=global_pct_pattern
dictConfig['degreePct']['pattern']=pct_pattern
dictConfig['degreePct']['result']=[]
dictConfig['location']={}
dictConfig['location']['keyWord']=global_location_pattern
dictConfig['location']['pattern']=location_pattern
dictConfig['location']['result']=[]
dictConfig['yearPass']={}
dictConfig['yearPass']['keyWord']=global_year_pattern
dictConfig['yearPass']['pattern']=year_pattern
dictConfig['yearPass']['result']=[]
dictConfig['dob']={}
dictConfig['dob']['keyWord']=global_birth_pattern
dictConfig['dob']['pattern']=birth_pattern
dictConfig['dob']['result']=[]
dictConfig['gender']={}
dictConfig['gender']['keyWord']=global_gender_pattern
dictConfig['gender']['pattern']=gender_pattern
dictConfig['gender']['result']=[]
dictConfig['email']={}
dictConfig['email']['keyWord']=global_email_pattern
dictConfig['email']['pattern']=email_pattern
dictConfig['email']['result']=[]
##dictConfig['name']={}
##dictConfig['name']['keyWord']=global_name_pattern
##dictConfig['name']['pattern']=name_pattern
##dictConfig['name']['result']=[]
dictConfig['collegeTier']={}
dictConfig['collegeTier']['keyWord']=global_collegeTier_pattern
dictConfig['collegeTier']['pattern']=dict_college_pattern
dictConfig['collegeTier']['result']=[]
dictConfig['collegeTier']['text']=[]
dictConfig['hsc']={}
dictConfig['hsc']['keyWord']=global_hsc_pattern
dictConfig['hsc']['pattern']=pct_pattern
dictConfig['hsc']['result']=[]
dictConfig['ssc']={}
dictConfig['ssc']['keyWord']=global_ssc_pattern
dictConfig['ssc']['pattern']=pct_pattern
dictConfig['ssc']['result']=[]


remove_pat=re.compile(r'((<.*?>)|(<img.*?>)|(<a(.|\n)*?a>)|(<p.*?>)|(<span.*?>)|(</p>)|(</span>)|(</li>)|(</ul>)|(<li.*?>)|(<ul.*?>)|(<style.*>(\n|.)*?</style>))',re.IGNORECASE|re.MULTILINE)

html_body=re.compile(r'(<body.*>(\n|.)*?</body>)',re.IGNORECASE|re.MULTILINE)

myResult="%s," % ("File Name",)
for key in dictConfig:
    myResult+="%s," % (key,)
myResult+="%s,%s,%s,%s" % ("Contact Number","Skills","DB Branch","DB Degree")
print myResult

for i,cv in enumerate(cv_list):
    try:
        with open(cv, 'r') as fileObj:
            textStr=fileObj.read().strip().replace("  "," ").replace(")"," ").replace("("," ").replace(":"," ").replace("}"," ").replace("{"," ").replace(","," ")
            fileObj.close()
##            print textStr
            cvSkill_list=filter(lambda x: x.endswith("0")== False ,map(lambda x: "%s-%s" % (x,str(textStr.lower().count(x))) ,skill_lsit))
            contact_result=re.search(mobile_pattern,textStr)
            try:
                contactNum=contact_result.group().replace(" ","").replace("-","").replace("+","")
                if len(contactNum)==12:
                    contactNum=contactNum[2:]
                loc_search=re.search(r'(('+contactNum[:4]+').*)',numFileStr,re.MULTILINE)
                try:
                    contactNum="%s (%s)" % (contactNum,loc_search.group().split(",")[-1:][0])
                except:
                    pass
            except:
                html_cv="%s\%s" % (html_cv_dir,os.path.basename(cv).replace("txt","html"))
                try:
                    with open(html_cv, 'r') as htmlFileObj:
                        html_body_search=re.search(html_body,htmlFileObj.read())
                        try:
                            htmlBody=html_body_search.group()
                        except:
                            htmlBody="NA"
                        htmlStr=re.sub(remove_pat,'|',htmlBody)
                        htmlStr=htmlStr.replace("\n"," ").replace("  ","")
##                        print htmlStr
                        contact_result=re.search(mobile_pattern,htmlStr)
                        try:
                            contactNum=contact_result.group().replace(" ","").replace("-","").replace("+","")
                            if len(contactNum)==12:
                                contactNum=contactNum[2:]
                            loc_search=re.search(r'(('+contactNum[:4]+').*)',numFileStr,re.MULTILINE)
                            try:
                                contactNum="%s (%s)" % (contactNum,loc_search.group().split(",")[-1:][0])
                            except:
                                pass
##                            print cv,contactNum
                        except:
                            contactNum="Not Found"
                        htmlFileObj.close()
                except Exception as e:
                    print html_cv,"HTML file opening failed for Number Search",e
            dictConfig['degree']['text']=[]
            dictConfig['branch']['text']=[]
            dictConfig['collegeTier']['text']=[]

            for key in dictConfig:
                dictConfig[key]['result']=[]
                lines=textStr.split("\n")
                global_pattern=dictConfig[key]['keyWord']
                for lineIdx,line in enumerate(lines):
##                    print line+"XXXXXXX------>>"
                    keyWordSearch=re.search(global_pattern,line)
                    try:
                        keyWordSearch.group()
                        try:
                            if type(dictConfig[key]['pattern']) is dict:
                                for subKey in dictConfig[key]['pattern']:
                                    search_result=re.search(dictConfig[key]['pattern'][subKey],line)
                                    try:
                                        dictConfig[key]['result'].append(search_result.group().replace(",",""))
                                        dictConfig[key]['text'].append(subKey)
                                    except:
                                        pass
                            else:
                                search_result=re.search(dictConfig[key]['pattern'],line)
##                                print line
##                                dictConfig[key]['result'].append(search_result.group()+" [ "+line.replace(","," ")+" ] ")
                                dictConfig[key]['result'].append(search_result.group().replace(",",""))
                                if dictConfig.has_key('hsc'):
                                    if key=='hsc':
                                        break
                                if dictConfig.has_key('ssc'):
                                    if key=='hsc':
                                        break
##                                print line
                        except:
                            if dictConfig.has_key('location'):
                                if key=='location':
                                    try:
                                        search_result=re.search(dictConfig[key]['pattern']," ".join(lines[lineIdx:lineIdx+10]))
                                        dictConfig[key]['result'].append(search_result.group().strip())
                                    except:
                                        pass
                            if dictConfig.has_key('dob'):
                                if key=='dob':
                                    try:
                                        search_result=re.search(dictConfig[key]['pattern']," ".join(lines[lineIdx:lineIdx+3]))
                                        dictConfig[key]['result'].append(search_result.group().replace(",",""))
                                    except:
                                        pass
                            if dictConfig.has_key('degreePct'):
                                if key=='degreePct':
                                    try:
                                        search_result=re.search(dictConfig[key]['pattern']," ".join(lines[lineIdx:lineIdx+4]))
                                        dictConfig[key]['result'].append(search_result.group().replace(",",""))
                                    except:
                                        pass
                            if dictConfig.has_key('hsc'):
                                if key=='hsc':
                                    try:
                                        search_result=re.search(dictConfig[key]['pattern']," ".join(lines[lineIdx:lineIdx+7]))
                                        print lines[lineIdx:lineIdx+5]
                                        dictConfig[key]['result'].append(search_result.group().replace(",",""))
                                        break
                                    except:
                                        pass
                            if dictConfig.has_key('ssc'):
                                if key=='ssc':
                                    try:
                                        search_result=re.search(dictConfig[key]['pattern']," ".join(lines[lineIdx:lineIdx+7]))
##                                        print lines[lineIdx:lineIdx+5]
                                        dictConfig[key]['result'].append(search_result.group().replace(",",""))
                                        break
                                    except:
                                        pass
                    except :
                        pass

##        print cv,",",contactNum
        if len(dictConfig['email']['result'])==0:
            html_cv="%s\%s" % (html_cv_dir,os.path.basename(cv).replace("txt","html"))
            try:
                with open(html_cv, 'r') as htmlFileObj:
                    html_body_search=re.search(html_body,htmlFileObj.read())
                    htmlFileObj.close()
                    try:
                        htmlBody=html_body_search.group()
                    except:
                        htmlBody="NA"
                    htmlStr=re.sub(remove_pat,'|',htmlBody)
                    htmlStr=htmlStr.replace("\n"," ").replace("  ","")
##                    print htmlStr
                    email_search=re.search(email_pattern,htmlStr)
                    try:
                        dictConfig[key]['result'].append(email_search.group())
                    except:
                        pass
            except Exception as e:
                print html_cv,"HTML file opening failed for email Search",e

        myResult="%s," % (os.path.basename(cv),)
##        cvName=re.sub(find_digit_pattern,'',os.path.basename(cv))
        for key in dictConfig:
            myResult+="%s," % ("|".join(set(dictConfig[key]['result'])))
        myResult+="%s,%s," % (contactNum,"|".join(cvSkill_list))
##        myResult+="%s,%s" % ("|".join(set(dictConfig['branch']['text'])),"|".join(set(dictConfig['degree']['text'])))
        myResult+="%s,%s" % ("|".join(set(dictConfig['branch']['text'])),"|".join(set(dictConfig['degree']['text'])),"|".join(set(dictConfig['collegeTier']['text'])))
        print myResult
    except Exception as e:
        print "Error ---> %s" % (e)

print "Total time taken : %s" % (datetime.datetime.today()-startTime)
