#-------------------------------------------------------------------------------
# Name:        db to xls converter
# Purpose:
#
# Author:      prajput
#
# Created:     06/01/2016
# Copyright:   (c) prajput 2016
#-------------------------------------------------------------------------------


import xlwt

class myExcelReport:
    def __init__(self):
        self.wbName=""
        self.wbPath=""
        self.col_sequence=[]
        self.worksheet_name="Sheet1"
        self.data_dict={}
    def generate_report(self):
        reportPath="%s\%s" % (self.wbPath,self.wbName)
        font0 = xlwt.Font()
        font0.name = "Times New Roman"
        font0.bold = True
        font0.outline = True
        style0 = xlwt.XFStyle()
        style0.font = font0
        wb = xlwt.Workbook()
        ws0 = wb.add_sheet(self.worksheet_name)
        try:
            for idx,colName in enumerate(self.col_sequence):
                ws0.write(0, idx, colName, style0)
                if self.data_dict.has_key(colName):
                    for idx_ele,ele in enumerate(self.data_dict[colName]):
                        ws0.write(idx_ele+1, idx, ele, style0)
            wb.save(reportPath)
            return [1,reportPath,'']
        except Exception as err:
            return [0,reportPath,err]



myDict={"Col1":[idx for idx in xrange(20)],
        "Col2":[idx for idx in xrange(15)],
        "Col3":[idx for idx in xrange(17)],
        "Col4":[idx for idx in xrange(25)],
        "Col5":[idx for idx in xrange(23)],
        "Col6":[idx for idx in xrange(28)]}

col_sequence=['Col1','Col2','Col3','Col4','Col5','Col6','Col7']

myReport=myExcelReport()
myReport.wbName="myReport.xls"
myReport.wbPath="c:\Allowed"
myReport.col_sequence=col_sequence
myReport.data_dict=myDict
myResponse=myReport.generate_report()


if myResponse[0]==0:
    print "Unable to generate the report because [%s]" % (myResponse[2],)
elif myResponse[0]==1:
    print "%s" % (myResponse[1])


