import os
import sys
import datetimeve

startTime=datetime.datetime.today()

# #######################################################################
# #######################################################################
# #######################################################################

# Please make sure that liberoffice is configured as a service on your server/system
# "-headless --convert-to html:HTML" is used for html conversion
# "-headless --convert-to txt:Text" is used for html conversion

parent_dir="F:\\Projects\\HirePro" # parent directory for raw as well as converted files.
doc_cv_dir="%s\%s" % (parent_dir,"cv_doc") # Directory where you should store doc / docx files
html_cv_dir="%s\%s" % (parent_dir,"cv_html") # export directory for html files
html_cv_dir="%s\%s" % (parent_dir,"cv_txt") # export directory for text files

doc2Html_command="C:\Allowed\LibreOfficePortable\App\libreoffice\program\soffice -headless --convert-to html:HTML -outdir %s \"XX\"  --web" % (html_cv_dir)

def runShellCommand(command):
    op=os.popen(command)
    print >> sys.stderr, "%s [%s]" % (command,op.read())

cv_list=map(lambda x: doc2Html_command.replace("XX","%s\%s") % (doc_cv_dir,x),filter(lambda x: x.find(".doc") >-1 ,os.listdir(doc_cv_dir)))

map(lambda x: runShellCommand(x),cv_list)

print "Total time taken : %s" % (datetime.datetime.today()-startTime)
