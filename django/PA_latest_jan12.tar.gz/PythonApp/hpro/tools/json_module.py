import json


class jsonObj:
    def to_JSON(self):
        return json.dumps(self, default=lambda o: o.__dict__,sort_keys=True, indent=1)



dict_input={'app1':[{'fname':'pankaj','lname':'Rajput'},{'fname':'pankaj','lname':'Rajput'},{'fname':'pankaj','lname':'Rajput'}]}

arr_input=[idx for idx in xrange(20)]


myJson=jsonObj()
myJson.report1=dict_input
myJson.report2=arr_input
myJson.report3=jsonObj()
myJson.report3.newApp=arr_input
myJson.report3.anotherApp=[{'fname':'pankaj','lname':'Rajput'},{'fname':'pankaj','lname':'Rajput'},{'fname':'pankaj','lname':'Rajput'}]



print myJson.to_JSON()
