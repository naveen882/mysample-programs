from __future__ import unicode_literals

from django.db import models


class Academics(models.Model):
    branch_id = models.IntegerField(blank=True, null=True)
    degree_id = models.IntegerField(blank=True, null=True)
    cut_off_from = models.FloatField(blank=True, null=True)
    cut_off_to = models.FloatField(blank=True, null=True)
    num_of_hiring = models.IntegerField(blank=True, null=True)
    comment = models.CharField(max_length=255, blank=True, null=True)
    is_percentage = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    eligibilitycriteria = models.ForeignKey('EligibilityCriterias', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'academics'


class ActionEvents(models.Model):
    version = models.IntegerField()
    subject = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    link_to_id = models.IntegerField(blank=True, null=True)
    target_id = models.IntegerField(blank=True, null=True)
    event_type = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    link_to_id_type = models.CharField(max_length=255, blank=True, null=True)
    target_id_type = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'action_events'


class Actions(models.Model):
    version = models.IntegerField()
    action_name = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    is_default = models.IntegerField(blank=True, null=True)
    depend_on_action_id = models.IntegerField(blank=True, null=True)
    action_label = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    module = models.ForeignKey('Modules', blank=True, null=True)
    action = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'actions'


class ActivityAttachments(models.Model):
    version = models.IntegerField()
    attachment_type_id = models.IntegerField(blank=True, null=True)
    source_item_id = models.IntegerField(blank=True, null=True)
    source_item_type = models.CharField(max_length=255, blank=True, null=True)
    target_item_id = models.IntegerField(blank=True, null=True)
    target_item_type = models.CharField(max_length=255, blank=True, null=True)
    attachment_name = models.TextField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'activity_attachments'


class ActivityCoordinators(models.Model):
    user_id = models.IntegerField(blank=True, null=True)
    staffingactivity = models.ForeignKey('StaffingActivitys', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'activity_coordinators'


class ActivityEvents(models.Model):
    version = models.IntegerField()
    event_type = models.IntegerField(blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    subject = models.TextField(blank=True, null=True)
    link_to_id = models.IntegerField(blank=True, null=True)
    link_to_type = models.CharField(max_length=255, blank=True, null=True)
    target_id = models.IntegerField(blank=True, null=True)
    target_type = models.CharField(max_length=255, blank=True, null=True)
    actor_id = models.IntegerField(blank=True, null=True)
    actor_type = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'activity_events'


class ActivityFileContents(models.Model):
    file_content = models.TextField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'activity_file_contents'


class ActivityFiles(models.Model):
    version = models.IntegerField()
    title = models.CharField(max_length=255, blank=True, null=True)
    original_file_name = models.TextField(blank=True, null=True)
    file_type_id = models.IntegerField(blank=True, null=True)
    file_type_text = models.CharField(max_length=50, blank=True, null=True)
    file_format_id = models.IntegerField(blank=True, null=True)
    file_size = models.BigIntegerField()
    is_compressed = models.IntegerField(blank=True, null=True)
    is_encrypted = models.IntegerField(blank=True, null=True)
    target_path = models.CharField(max_length=255, blank=True, null=True)
    file_created_on = models.DateTimeField()
    file_modified_on = models.DateTimeField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    activityfilecontent = models.ForeignKey(ActivityFileContents, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'activity_files'


class ActivityGroups(models.Model):
    group_id = models.IntegerField(blank=True, null=True)
    staffingactivity = models.ForeignKey('StaffingActivitys', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'activity_groups'


class ActivityStatusCallbackConfigs(models.Model):
    version = models.IntegerField()
    title = models.CharField(max_length=255, blank=True, null=True)
    activity_id = models.IntegerField(blank=True, null=True)
    type_of_candidate = models.IntegerField(blank=True, null=True)
    entity_type = models.IntegerField(blank=True, null=True)
    entity_id = models.IntegerField(blank=True, null=True)
    activity_status_action = models.IntegerField(blank=True, null=True)
    activity_completed_status = models.IntegerField(blank=True, null=True)
    next_action_valule = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'activity_status_callback_configs'


class AlertMessages(models.Model):
    version = models.IntegerField()
    reciever_id = models.IntegerField(blank=True, null=True)
    reciever_department = models.IntegerField(blank=True, null=True)
    hire_pro_entity = models.IntegerField(blank=True, null=True)
    hire_pro_entity_id = models.IntegerField(blank=True, null=True)
    message = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'alert_messages'


class AnswerChoices(models.Model):
    choice = models.CharField(max_length=1, blank=True, null=True)
    answer = models.CharField(max_length=255, blank=True, null=True)
    html_string = models.TextField(blank=True, null=True)
    no_of_attachments = models.IntegerField()
    marks = models.FloatField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    question = models.ForeignKey('Questions', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'answer_choices'


class Answers(models.Model):
    correct_answer = models.CharField(max_length=255, blank=True, null=True)
    html_string = models.TextField(blank=True, null=True)
    no_of_attachments = models.IntegerField()
    language_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    question = models.ForeignKey('Questions', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'answers'


class ApiContracts(models.Model):
    version = models.IntegerField()
    auth_key = models.CharField(max_length=255, blank=True, null=True)
    valid_from = models.DateTimeField(blank=True, null=True)
    valid_to = models.DateTimeField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'api_contracts'


class ApiMethods(models.Model):
    method_name = models.CharField(max_length=255, blank=True, null=True)
    method_url = models.CharField(max_length=255, blank=True, null=True)
    module_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'api_methods'


class AppPreferences(models.Model):
    version = models.IntegerField()
    user_id = models.IntegerField(blank=True, null=True)
    content = models.TextField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    type = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'app_preferences'


class ApplicantEvents(models.Model):
    version = models.IntegerField()
    subject = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    candidate_id = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    event_type = models.IntegerField(blank=True, null=True)
    job_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'applicant_events'


class ApplicantReports(models.Model):
    candidate_id = models.IntegerField(blank=True, null=True)
    candidate_name = models.CharField(max_length=255, blank=True, null=True)
    current_organization = models.CharField(max_length=255, blank=True, null=True)
    source = models.CharField(max_length=255, blank=True, null=True)
    job = models.CharField(max_length=255, blank=True, null=True)
    previous_status = models.CharField(max_length=255, blank=True, null=True)
    current_status = models.CharField(max_length=255, blank=True, null=True)
    date = models.DateTimeField(blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    user_name = models.CharField(max_length=255, blank=True, null=True)
    applicant_report_type = models.IntegerField(blank=True, null=True)
    customer = models.CharField(max_length=255, blank=True, null=True)
    item_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'applicant_reports'


class ApplicantStatusItems(models.Model):
    version = models.IntegerField(blank=True, null=True)
    status_id = models.IntegerField()
    comments = models.TextField(blank=True, null=True)
    applican_status_date = models.DateTimeField(blank=True, null=True)
    no_of_attachments = models.IntegerField()
    is_private = models.IntegerField(blank=True, null=True)
    applicant_status_reason_id = models.IntegerField(blank=True, null=True)
    is_feedback_exists = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    applicantstatus = models.ForeignKey('ApplicantStatuss', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'applicant_status_items'


class ApplicantStatusReasons(models.Model):
    status_reason_value = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    resumestatus = models.ForeignKey('ResumeStatuss', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'applicant_status_reasons'


class ApplicantStatuss(models.Model):
    current_status_id = models.IntegerField()
    forwarded_date = models.DateTimeField(blank=True, null=True)
    candidate_spoc = models.IntegerField(blank=True, null=True)
    resume_type_id = models.IntegerField(blank=True, null=True)
    rotated_by = models.IntegerField(blank=True, null=True)
    position_id = models.IntegerField(blank=True, null=True)
    is_deleted = models.IntegerField()
    applicant_status_manager_id = models.IntegerField()
    comments = models.TextField(blank=True, null=True)
    current_status_reason_id = models.IntegerField(blank=True, null=True)
    source_id = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    master_job_requisition_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    job = models.ForeignKey('Jobs', blank=True, null=True)
    candidate = models.ForeignKey('Candidates', blank=True, null=True)
    recruitevent = models.ForeignKey('RecruitEvents', blank=True, null=True)
    offer = models.ForeignKey('Offers', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'applicant_statuss'


class ApplicantTestInfos(models.Model):
    test_id = models.IntegerField(blank=True, null=True)
    applicant_status_item_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'applicant_test_infos'


class ApplicantsBySources(models.Model):
    version = models.IntegerField()
    source_id = models.IntegerField()
    candidate_id = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    job = models.ForeignKey('Jobs', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'applicants_by_sources'


class AppointmentItems(models.Model):
    version = models.IntegerField()
    subject = models.TextField(blank=True, null=True)
    type_id = models.IntegerField(blank=True, null=True)
    is_all_day_event = models.IntegerField()
    busy_status = models.IntegerField()
    location_id = models.IntegerField(blank=True, null=True)
    location_text = models.CharField(max_length=100, blank=True, null=True)
    organizer_email = models.CharField(max_length=60, blank=True, null=True)
    reminder_minutes_before_start = models.IntegerField()
    is_reminder_set = models.IntegerField()
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    no_of_attachments = models.IntegerField()
    is_read = models.IntegerField()
    acceptance_status = models.IntegerField()
    is_recurring = models.IntegerField()
    is_private = models.IntegerField()
    contact_id = models.IntegerField(blank=True, null=True)
    contact_type = models.CharField(max_length=255, blank=True, null=True)
    organizer_contact_id = models.IntegerField(blank=True, null=True)
    organizer_contact_type = models.CharField(max_length=255, blank=True, null=True)
    parent_thread_id = models.IntegerField(blank=True, null=True)
    importance = models.IntegerField(blank=True, null=True)
    sensitivity = models.IntegerField(blank=True, null=True)
    status = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    body = models.ForeignKey('Bodys', blank=True, null=True)
    appointmentitem = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'appointment_items'


class ApprovalConfigurations(models.Model):
    version = models.IntegerField()
    entity_type_id = models.IntegerField(blank=True, null=True)
    level = models.IntegerField(blank=True, null=True)
    entity_id = models.IntegerField(blank=True, null=True)
    types_of_approval_configuration = models.IntegerField(blank=True, null=True)
    notification_prefrence_id = models.IntegerField(blank=True, null=True)
    operation_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'approval_configurations'


class ApprovalEvents(models.Model):
    version = models.IntegerField()
    subject = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    entity_id = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    candidate_id = models.IntegerField(blank=True, null=True)
    level = models.IntegerField(blank=True, null=True)
    entity_type_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'approval_events'


class Approvers(models.Model):
    user_id = models.IntegerField(blank=True, null=True)
    approver_department = models.IntegerField(blank=True, null=True)
    approvalconfiguration = models.ForeignKey(ApprovalConfigurations, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'approvers'


class AssessedFeedbacks(models.Model):
    candidate_id = models.IntegerField()
    skill_id = models.IntegerField()
    marks = models.IntegerField(blank=True, null=True)
    comment = models.CharField(max_length=255, blank=True, null=True)
    is_applicable = models.IntegerField(blank=True, null=True)
    applicant_status_item_id = models.IntegerField()
    is_deleted = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    configassessmentfeedback = models.ForeignKey('ConfigAssessmentFeedbacks', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'assessed_feedbacks'


class AssessmentApprovalConfigurations(models.Model):
    id = models.ForeignKey(ApprovalConfigurations, db_column='id', primary_key=True)
    question_id = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'assessment_approval_configurations'


class AssessmentLines(models.Model):
    version = models.IntegerField()
    name = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'assessment_lines'


class AssessmentLogs(models.Model):
    version = models.IntegerField()
    subject = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    event_type = models.IntegerField(blank=True, null=True)
    question_id = models.IntegerField(blank=True, null=True)
    question_paper_id = models.IntegerField(blank=True, null=True)
    test_id = models.IntegerField(blank=True, null=True)
    blue_print_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'assessment_logs'


class AssessmentTemplates(models.Model):
    assessment_template_name = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    is_vendor_screening_template = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'assessment_templates'


class AssignedTaskActors(models.Model):
    user_id = models.IntegerField(blank=True, null=True)
    user_group_id = models.IntegerField(blank=True, null=True)
    task_actor_type = models.IntegerField(blank=True, null=True)
    assignedtask = models.ForeignKey('AssignedTasks', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'assigned_task_actors'


class AssignedTaskHistorys(models.Model):
    status = models.IntegerField(blank=True, null=True)
    comments = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    assignedtask = models.ForeignKey('AssignedTasks', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'assigned_task_historys'


class AssignedTasks(models.Model):
    version = models.IntegerField()
    due_date = models.DateTimeField(blank=True, null=True)
    status = models.IntegerField(blank=True, null=True)
    candidate_id = models.IntegerField(blank=True, null=True)
    is_visible_to_candidate = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    assignee_user = models.IntegerField(blank=True, null=True)
    approver_user = models.IntegerField(blank=True, null=True)
    reporter_user = models.IntegerField(blank=True, null=True)
    reporter_department = models.IntegerField(blank=True, null=True)
    approver_department = models.IntegerField(blank=True, null=True)
    assignee_department = models.IntegerField(blank=True, null=True)
    reporter_group = models.IntegerField(blank=True, null=True)
    approver_group = models.IntegerField(blank=True, null=True)
    approver_group_users = models.CharField(max_length=255, blank=True, null=True)
    assignee_group = models.IntegerField(blank=True, null=True)
    comments = models.CharField(max_length=255, blank=True, null=True)
    completed_date = models.DateTimeField(blank=True, null=True)
    approved_date = models.DateTimeField(blank=True, null=True)
    reported_date = models.DateTimeField(blank=True, null=True)
    task_id = models.IntegerField(blank=True, null=True)
    activity_id = models.IntegerField(blank=True, null=True)
    candidate_group = models.IntegerField(blank=True, null=True)
    form_id = models.IntegerField(blank=True, null=True)
    filled_form_id = models.IntegerField(blank=True, null=True)
    is_auto_approved = models.IntegerField(blank=True, null=True)
    duration = models.IntegerField(blank=True, null=True)
    notes = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'assigned_tasks'


class Attachments(models.Model):
    version = models.IntegerField()
    attachment_type_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    source_item_type = models.CharField(max_length=255, blank=True, null=True)
    source_item_id = models.IntegerField(blank=True, null=True)
    target_item_type = models.CharField(max_length=255, blank=True, null=True)
    target_item_id = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'attachments'


class AttendeeStatuss(models.Model):
    attendee_email_address = models.CharField(max_length=60, blank=True, null=True)
    is_required = models.IntegerField()
    acceptance_status = models.IntegerField()
    busy_status = models.IntegerField()
    attendee_contact_id = models.IntegerField(blank=True, null=True)
    attendee_contact_type = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    appointmentitem = models.ForeignKey(AppointmentItems, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'attendee_statuss'


class AuthorizationCredentials(models.Model):
    version = models.IntegerField()
    role_name = models.CharField(max_length=255, blank=True, null=True)
    action_id = models.IntegerField()
    tenant_alias = models.CharField(max_length=50, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'authorization_credentials'


class Bfsicandidates(models.Model):
    version = models.IntegerField()
    driving_licence = models.CharField(max_length=255, blank=True, null=True)
    is_apply_driving_licence = models.IntegerField(blank=True, null=True)
    vehicle_type = models.CharField(max_length=255, blank=True, null=True)
    is_apply_pancard = models.IntegerField(blank=True, null=True)
    is_apply_passport = models.IntegerField(blank=True, null=True)
    number_of_offers = models.IntegerField(blank=True, null=True)
    land_mark_of_current_address = models.CharField(max_length=255, blank=True, null=True)
    land_mark_of_permanent_address = models.CharField(max_length=255, blank=True, null=True)
    cast_id = models.IntegerField(blank=True, null=True)
    cast_text = models.CharField(max_length=255, blank=True, null=True)
    category_id = models.IntegerField(blank=True, null=True)
    category_text = models.CharField(max_length=255, blank=True, null=True)
    religion_id = models.IntegerField(blank=True, null=True)
    religion_text = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    familydetail = models.ForeignKey('FamilyDetails', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'bfsicandidates'


class BillingPlans(models.Model):
    version = models.IntegerField()
    available_data_base_usage = models.IntegerField(blank=True, null=True)
    available_down_load_size = models.IntegerField(blank=True, null=True)
    cost_per_user = models.IntegerField(blank=True, null=True)
    available_time = models.IntegerField(blank=True, null=True)
    data_base_usage_cost_per_mb = models.IntegerField(blank=True, null=True)
    down_load_size_cost_per_mb = models.IntegerField(blank=True, null=True)
    plan_name = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'billing_plans'


class BluePrintSplitRatios(models.Model):
    version = models.IntegerField()
    split_ratio = models.IntegerField(blank=True, null=True)
    low = models.IntegerField()
    medium = models.IntegerField()
    high = models.IntegerField()
    is_latest = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'blue_print_split_ratios'


class BluePrints(models.Model):
    version = models.IntegerField()
    blue_print_name = models.CharField(max_length=255, blank=True, null=True)
    total_questions = models.IntegerField()
    foreign_blue_print_id = models.IntegerField()
    split_ratio = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'blue_prints'


class Bodys(models.Model):
    body_encoding = models.IntegerField(blank=True, null=True)
    body_format = models.IntegerField()
    body_content = models.TextField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'bodys'


class BrowniePointConfigurations(models.Model):
    version = models.IntegerField()
    brownie_point_currency_ratio = models.FloatField(blank=True, null=True)
    tax_percentage = models.FloatField(blank=True, null=True)
    max_amount_exempted = models.FloatField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'brownie_point_configurations'


class BulkInterviewers(models.Model):
    interviewer = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    bulkinterview = models.ForeignKey('BulkInterviews', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'bulk_interviewers'


class BulkInterviews(models.Model):
    version = models.IntegerField()
    interview_stage = models.IntegerField(blank=True, null=True)
    interview_round = models.IntegerField(blank=True, null=True)
    interview_address = models.CharField(max_length=255, blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    job_id = models.IntegerField(blank=True, null=True)
    duration = models.IntegerField(blank=True, null=True)
    batch_size = models.IntegerField(blank=True, null=True)
    interviews_before_break = models.IntegerField(blank=True, null=True)
    break_duration = models.IntegerField(blank=True, null=True)
    first_batch_start_time = models.DateTimeField(blank=True, null=True)
    final_batch_end_time = models.DateTimeField(blank=True, null=True)
    interview_days = models.CharField(max_length=255, blank=True, null=True)
    is_interview_scheduled = models.IntegerField(blank=True, null=True)
    start_date = models.DateTimeField(blank=True, null=True)
    end_date = models.DateTimeField(blank=True, null=True)
    day_of_interview = models.IntegerField(blank=True, null=True)
    last_interviewed_batch = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'bulk_interviews'


class BulkMailRecepients(models.Model):
    version = models.IntegerField()
    candidate_name = models.CharField(max_length=250, blank=True, null=True)
    candidate_email = models.CharField(max_length=250, blank=True, null=True)
    is_sent = models.IntegerField()
    bulk_mail_sender_id = models.IntegerField()
    entity_id = models.IntegerField(blank=True, null=True)
    entity_type = models.CharField(max_length=255, blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'bulk_mail_recepients'


class BulkMailSenders(models.Model):
    version = models.IntegerField()
    sender_name = models.CharField(max_length=250, blank=True, null=True)
    sender_email = models.CharField(max_length=250, blank=True, null=True)
    template_id = models.IntegerField(blank=True, null=True)
    scheduled_time = models.DateTimeField(blank=True, null=True)
    size = models.BigIntegerField()
    last_processed_date = models.DateTimeField(blank=True, null=True)
    is_completed = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'bulk_mail_senders'


class BusinessActionBillingPrices(models.Model):
    version = models.IntegerField()
    business_action_id = models.IntegerField()
    price = models.BigIntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'business_action_billing_prices'


class BusinessActions(models.Model):
    version = models.IntegerField()
    action_name = models.CharField(max_length=255, blank=True, null=True)
    is_billable = models.IntegerField()
    is_metered = models.IntegerField()
    is_logged = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'business_actions'


class BusinessPlans(models.Model):
    version = models.IntegerField()
    financial_year = models.IntegerField()
    quarter = models.CharField(max_length=255, blank=True, null=True)
    business_unit_id = models.IntegerField()
    year_plan = models.FloatField()
    quarter_plan = models.FloatField()
    business_unit_name = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'business_plans'


class BusinessUnits(models.Model):
    version = models.IntegerField()
    title = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    geography = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    company = models.ForeignKey('Companys', blank=True, null=True)
    businessunit = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'business_units'


class CallRemarkActions(models.Model):
    version = models.IntegerField()
    level_id = models.IntegerField(blank=True, null=True)
    remark_id = models.IntegerField(blank=True, null=True)
    remark_count = models.IntegerField(blank=True, null=True)
    action = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'call_remark_actions'


class CampusApprovalConfigurations(models.Model):
    id = models.ForeignKey(ApprovalConfigurations, db_column='id', primary_key=True)
    event_id = models.IntegerField(blank=True, null=True)
    job_role_id = models.IntegerField(blank=True, null=True)
    business_unit_id = models.IntegerField(blank=True, null=True)
    location_id = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'campus_approval_configurations'


class CampusCalendars(models.Model):
    name = models.TextField(blank=True, null=True)
    type = models.IntegerField(blank=True, null=True)
    from_date = models.DateTimeField(blank=True, null=True)
    to_date = models.DateTimeField(blank=True, null=True)
    detail = models.TextField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    campusinformation = models.ForeignKey('CampusInformations', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'campus_calendars'


class CampusCollegeTypes(models.Model):
    college_type_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    campusinformation = models.ForeignKey('CampusInformations', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'campus_college_types'


class CampusConfigurations(models.Model):
    version = models.IntegerField()
    is_campus_job_approve_enabled = models.IntegerField()
    is_campus_candidate_offer_approve_enabled = models.IntegerField()
    is_campus_tpo_offer_approve_enabled = models.IntegerField()
    campus_candidate_visibility = models.TextField(blank=True, null=True)
    num_of_max_offers_for_campus = models.IntegerField(blank=True, null=True)
    num_of_offers_for_dream_job = models.IntegerField(blank=True, null=True)
    num_of_offers_for_non_dream_job = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'campus_configurations'


class CampusContactInfos(models.Model):
    name = models.TextField(blank=True, null=True)
    designation_id = models.IntegerField(blank=True, null=True)
    contact_number = models.CharField(max_length=255, blank=True, null=True)
    email = models.CharField(max_length=255, blank=True, null=True)
    photo_file_path = models.TextField(blank=True, null=True)
    type = models.IntegerField(blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    campusinformation = models.ForeignKey('CampusInformations', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'campus_contact_infos'


class CampusCourseCurriculums(models.Model):
    course_ids = models.TextField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    campuscourse = models.ForeignKey('CampusCourses', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'campus_course_curriculums'


class CampusCourses(models.Model):
    degree_id = models.IntegerField(blank=True, null=True)
    branch_id = models.IntegerField(blank=True, null=True)
    academic_format = models.IntegerField(blank=True, null=True)
    duration = models.IntegerField(blank=True, null=True)
    strength = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    campusinformation = models.ForeignKey('CampusInformations', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'campus_courses'


class CampusCriterias(models.Model):
    year_of_passing = models.IntegerField(blank=True, null=True)
    eligibility_criteria_id = models.IntegerField(blank=True, null=True)
    salary_package_id = models.IntegerField(blank=True, null=True)
    is_prior_experience = models.IntegerField(blank=True, null=True)
    comment = models.CharField(max_length=255, blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    month_of_passing = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'campus_criterias'


class CampusEntranceCriterias(models.Model):
    name = models.TextField(blank=True, null=True)
    degree_id = models.IntegerField(blank=True, null=True)
    branch_id = models.IntegerField(blank=True, null=True)
    entrance_exam = models.IntegerField(blank=True, null=True)
    opening_rank = models.IntegerField(blank=True, null=True)
    closing_rank = models.IntegerField(blank=True, null=True)
    criteria = models.TextField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    campusinformation = models.ForeignKey('CampusInformations', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'campus_entrance_criterias'


class CampusEventActivityComments(models.Model):
    comment = models.TextField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    campuseventactivity = models.ForeignKey('CampusEventActivitys', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'campus_event_activity_comments'


class CampusEventActivitys(models.Model):
    activity_type_id = models.IntegerField(blank=True, null=True)
    date_from = models.DateTimeField(blank=True, null=True)
    date_to = models.DateTimeField(blank=True, null=True)
    comments = models.CharField(max_length=255, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    started_on = models.DateTimeField(blank=True, null=True)
    completed_on = models.DateTimeField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    recruitevent = models.ForeignKey('RecruitEvents', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'campus_event_activitys'


class CampusEventCandidates(models.Model):
    recruit_event_id = models.IntegerField(blank=True, null=True)
    campus_candidate_id = models.IntegerField(blank=True, null=True)
    corporate_candidate_id = models.IntegerField(blank=True, null=True)
    job_id = models.IntegerField(blank=True, null=True)
    campus_tenant_id = models.IntegerField(blank=True, null=True)
    corporate_tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'campus_event_candidates'


class CampusGroups(models.Model):
    version = models.IntegerField()
    source_id = models.IntegerField(blank=True, null=True)
    group_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    source_tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'campus_groups'


class CampusImages(models.Model):
    type = models.IntegerField(blank=True, null=True)
    file_path = models.TextField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    campusinformation = models.ForeignKey('CampusInformations', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'campus_images'


class CampusInformations(models.Model):
    version = models.IntegerField()
    campus_overview = models.TextField(blank=True, null=True)
    university_id = models.IntegerField(blank=True, null=True)
    year_of_establishment = models.IntegerField(blank=True, null=True)
    campus_type = models.IntegerField(blank=True, null=True)
    campus_diversity = models.IntegerField(blank=True, null=True)
    campus_id = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'campus_informations'


class CampusInfrastructures(models.Model):
    name = models.TextField(blank=True, null=True)
    infrastructure_type_id = models.IntegerField(blank=True, null=True)
    infrastructure_detail_id = models.IntegerField(blank=True, null=True)
    value = models.CharField(max_length=255, blank=True, null=True)
    comment = models.TextField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    campusinformation = models.ForeignKey(CampusInformations, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'campus_infrastructures'


class CampusInternshipDetails(models.Model):
    degree_id = models.IntegerField(blank=True, null=True)
    duration = models.IntegerField(blank=True, null=True)
    duration_type = models.IntegerField(blank=True, null=True)
    from_date_month = models.DateTimeField(blank=True, null=True)
    to_date_month = models.DateTimeField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    campusinformation = models.ForeignKey(CampusInformations, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'campus_internship_details'


class CampusInterviewers(models.Model):
    interviewer = models.IntegerField(blank=True, null=True)
    is_interviewed = models.IntegerField()
    interviewer_comments = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    applicantstatusitem = models.ForeignKey(ApplicantStatusItems, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'campus_interviewers'


class CampusOffers(models.Model):
    company_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    candidate = models.ForeignKey('Candidates', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'campus_offers'


class CampusPlacementTrends(models.Model):
    year = models.IntegerField(blank=True, null=True)
    company_id = models.IntegerField(blank=True, null=True)
    industry_id = models.IntegerField(blank=True, null=True)
    role_id = models.IntegerField(blank=True, null=True)
    branches_allowed = models.CharField(max_length=255, blank=True, null=True)
    degrees_allowed = models.CharField(max_length=255, blank=True, null=True)
    branch_id = models.IntegerField(blank=True, null=True)
    degree_id = models.IntegerField(blank=True, null=True)
    salary_offered_from = models.DecimalField(max_digits=19, decimal_places=5, blank=True, null=True)
    salary_offered_to = models.DecimalField(max_digits=19, decimal_places=5, blank=True, null=True)
    comment = models.TextField(blank=True, null=True)
    hiring_type = models.IntegerField(blank=True, null=True)
    placement_number = models.DecimalField(max_digits=19, decimal_places=5, blank=True, null=True)
    gender = models.IntegerField(blank=True, null=True)
    percentage_from = models.FloatField(blank=True, null=True)
    percentage_to = models.FloatField(blank=True, null=True)
    is_percentage = models.IntegerField(blank=True, null=True)
    visit_date_from = models.DateTimeField(blank=True, null=True)
    visit_date_to = models.DateTimeField(blank=True, null=True)
    num_of_offers = models.IntegerField(blank=True, null=True)
    currency = models.CharField(max_length=15, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    campusinformation = models.ForeignKey(CampusInformations, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'campus_placement_trends'


class CampusRankings(models.Model):
    year = models.IntegerField(blank=True, null=True)
    ranking_agency = models.IntegerField(blank=True, null=True)
    source = models.CharField(max_length=255, blank=True, null=True)
    rank = models.IntegerField(blank=True, null=True)
    comment = models.TextField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    campusinformation = models.ForeignKey(CampusInformations, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'campus_rankings'


class CandidateActivitys(models.Model):
    version = models.IntegerField()
    candidate_id = models.IntegerField(blank=True, null=True)
    activity_id = models.IntegerField(blank=True, null=True)
    status = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'candidate_activitys'


class CandidateBuddys(models.Model):
    user_id = models.IntegerField(blank=True, null=True)
    candidate = models.ForeignKey('Candidates', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'candidate_buddys'


class CandidateCompanyPreferences(models.Model):
    company_id = models.IntegerField(blank=True, null=True)
    priority_id = models.IntegerField(blank=True, null=True)
    priority_text = models.CharField(max_length=30, blank=True, null=True)
    company_text = models.CharField(max_length=100, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    candidatepreference = models.ForeignKey('CandidatePreferences', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'candidate_company_preferences'


class CandidateEditPropertyInfos(models.Model):
    type_of_object = models.CharField(max_length=255, blank=True, null=True)
    object_id = models.IntegerField(blank=True, null=True)
    property_name = models.CharField(max_length=255, blank=True, null=True)
    edited_value = models.CharField(max_length=255, blank=True, null=True)
    old_value = models.CharField(max_length=255, blank=True, null=True)
    is_removed = models.IntegerField(blank=True, null=True)
    collection_index = models.IntegerField(blank=True, null=True)
    property_type = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    candidateeditrequest = models.ForeignKey('CandidateEditRequests', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'candidate_edit_property_infos'


class CandidateEditRequests(models.Model):
    version = models.IntegerField()
    candidate_id = models.IntegerField()
    status_id = models.IntegerField(blank=True, null=True)
    reason_of_rejection = models.TextField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    candidateuploadresume = models.ForeignKey('CandidateUploadResumes', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'candidate_edit_requests'


class CandidateEducationProfiles(models.Model):
    college_id = models.IntegerField(blank=True, null=True)
    college_text = models.CharField(max_length=100, blank=True, null=True)
    degree_id = models.IntegerField(blank=True, null=True)
    degree_text = models.CharField(max_length=100, blank=True, null=True)
    degree_type_id = models.IntegerField(blank=True, null=True)
    degree_type_text = models.CharField(max_length=50, blank=True, null=True)
    end_year = models.IntegerField(blank=True, null=True)
    is_final = models.IntegerField(blank=True, null=True)
    percentage = models.FloatField(blank=True, null=True)
    start_year = models.IntegerField(blank=True, null=True)
    university_id = models.IntegerField(blank=True, null=True)
    university_text = models.CharField(max_length=100, blank=True, null=True)
    start_month = models.IntegerField(blank=True, null=True)
    end_month = models.IntegerField(blank=True, null=True)
    education_type = models.IntegerField(blank=True, null=True)
    is_percentage = models.IntegerField(blank=True, null=True)
    institute_type_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    candidate = models.ForeignKey('Candidates', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'candidate_education_profiles'


class CandidateEvents(models.Model):
    version = models.IntegerField()
    subject = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    job_id = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    event_type = models.IntegerField(blank=True, null=True)
    candidate_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'candidate_events'


class CandidateFullTexts(models.Model):
    candidate_resume_full_text = models.TextField(blank=True, null=True)
    rank = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'candidate_full_texts'


class CandidateLocationPreferences(models.Model):
    location_id = models.IntegerField()
    location_text = models.CharField(max_length=100, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    candidatepreference = models.ForeignKey('CandidatePreferences', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'candidate_location_preferences'


class CandidateOriginalSourceInfos(models.Model):
    expiry_date = models.DateTimeField(blank=True, null=True)
    status = models.IntegerField(blank=True, null=True)
    comments = models.TextField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'candidate_original_source_infos'


class CandidatePofuCategorizations(models.Model):
    version = models.IntegerField()
    category = models.CharField(max_length=255, blank=True, null=True)
    no_of_calls = models.IntegerField()
    no_of_days = models.IntegerField()
    tenant_id = models.IntegerField()
    role_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'candidate_pofu_categorizations'


class CandidatePreferences(models.Model):
    desired_salary_from = models.FloatField(blank=True, null=True)
    desired_salary_to = models.FloatField(blank=True, null=True)
    desired_title_id = models.IntegerField(blank=True, null=True)
    desired_title_text = models.CharField(max_length=50, blank=True, null=True)
    job_category_id1 = models.IntegerField(blank=True, null=True)
    job_category_text = models.CharField(max_length=50, blank=True, null=True)
    notes = models.CharField(max_length=255, blank=True, null=True)
    other_compensation = models.CharField(max_length=255, blank=True, null=True)
    is_willing_to_relocate = models.IntegerField(blank=True, null=True)
    job_category_id2 = models.IntegerField(blank=True, null=True)
    job_category_id3 = models.IntegerField(blank=True, null=True)
    job_category_id4 = models.IntegerField(blank=True, null=True)
    company_type_id = models.IntegerField(blank=True, null=True)
    company_type_text = models.CharField(max_length=50, blank=True, null=True)
    company_sub_type_id = models.IntegerField(blank=True, null=True)
    company_sub_type_text = models.CharField(max_length=50, blank=True, null=True)
    notice_period = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'candidate_preferences'


class CandidateSalarys(models.Model):
    date_created = models.DateTimeField(blank=True, null=True)
    company_name = models.CharField(max_length=100, blank=True, null=True)
    basic = models.FloatField(blank=True, null=True)
    flexible = models.FloatField(blank=True, null=True)
    pf = models.FloatField(blank=True, null=True)
    performance_bonus = models.FloatField(blank=True, null=True)
    gratuity = models.FloatField(blank=True, null=True)
    super_annuation = models.FloatField(blank=True, null=True)
    insurance = models.FloatField(blank=True, null=True)
    medical = models.FloatField(blank=True, null=True)
    stocks = models.CharField(max_length=255, blank=True, null=True)
    comments = models.CharField(max_length=255, blank=True, null=True)
    offer_id = models.IntegerField(blank=True, null=True)
    currency = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    candidate = models.ForeignKey('Candidates', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'candidate_salarys'


class CandidateScores(models.Model):
    category_id = models.IntegerField(blank=True, null=True)
    score = models.FloatField(blank=True, null=True)
    correct_anwers = models.IntegerField(blank=True, null=True)
    in_correct_answers = models.IntegerField(blank=True, null=True)
    qn_paper_id = models.CharField(max_length=255, blank=True, null=True)
    qn_paper_code = models.CharField(max_length=255, blank=True, null=True)
    un_attended_questions = models.IntegerField(blank=True, null=True)
    total_no_of_subjective_questions = models.IntegerField(blank=True, null=True)
    group_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    testuser = models.ForeignKey('TestUsers', blank=True, null=True)
    candidatescore = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'candidate_scores'


class CandidateSemesterWiseDetails(models.Model):
    semester_id = models.IntegerField(blank=True, null=True)
    percentage_or_cgp = models.FloatField(blank=True, null=True)
    start_year = models.IntegerField(blank=True, null=True)
    end_year = models.IntegerField(blank=True, null=True)
    start_month = models.IntegerField(blank=True, null=True)
    end_month = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    candidateeducationprofile = models.ForeignKey(CandidateEducationProfiles, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'candidate_semester_wise_details'


class CandidateSocialNetworkDetails(models.Model):
    version = models.IntegerField()
    face_book_link = models.CharField(max_length=255, blank=True, null=True)
    face_book_details = models.CharField(max_length=255, blank=True, null=True)
    twitter_link = models.CharField(max_length=255, blank=True, null=True)
    twitter_details = models.CharField(max_length=255, blank=True, null=True)
    linked_in_link = models.CharField(max_length=255, blank=True, null=True)
    linked_in_details = models.CharField(max_length=255, blank=True, null=True)
    candidate_id = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'candidate_social_network_details'


class CandidateSpocs(models.Model):
    version = models.IntegerField()
    user_id = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    candidate = models.ForeignKey('Candidates', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'candidate_spocs'


class CandidateStaffingProfiles(models.Model):
    actual_joining_date = models.DateTimeField(blank=True, null=True)
    expected_joining_date = models.DateTimeField(blank=True, null=True)
    history_info = models.CharField(max_length=255, blank=True, null=True)
    comment = models.CharField(max_length=255, blank=True, null=True)
    status_modified_on = models.DateTimeField(blank=True, null=True)
    criticality = models.IntegerField(blank=True, null=True)
    is_calls_assigned = models.IntegerField(blank=True, null=True)
    call_status = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'candidate_staffing_profiles'


class CandidateStatuss(models.Model):
    candidate_satus_id = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    candidate = models.ForeignKey('Candidates', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'candidate_statuss'


class CandidateUploadResumes(models.Model):
    file_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'candidate_upload_resumes'


class CandidateWorkProfiles(models.Model):
    deisignation_id = models.IntegerField(blank=True, null=True)
    designation_text = models.CharField(max_length=75, blank=True, null=True)
    employer_id = models.IntegerField(blank=True, null=True)
    employer_text = models.CharField(max_length=100, blank=True, null=True)
    location_id = models.IntegerField(blank=True, null=True)
    location_text = models.CharField(max_length=75, blank=True, null=True)
    reason_for_leaving = models.TextField(blank=True, null=True)
    yearly_salary = models.IntegerField(blank=True, null=True)
    from_month = models.IntegerField(blank=True, null=True)
    to_month = models.IntegerField(blank=True, null=True)
    from_year = models.IntegerField(blank=True, null=True)
    to_year = models.IntegerField(blank=True, null=True)
    is_latest = models.IntegerField(blank=True, null=True)
    industry = models.IntegerField(blank=True, null=True)
    expertise = models.IntegerField(blank=True, null=True)
    sub_expertise = models.IntegerField(blank=True, null=True)
    sub_expertise2 = models.IntegerField(blank=True, null=True)
    title = models.CharField(max_length=255, blank=True, null=True)
    bulk_custom_field_string = models.TextField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    candidate = models.ForeignKey('Candidates', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'candidate_work_profiles'


class Candidates(models.Model):
    version = models.IntegerField()
    current_employer_id = models.IntegerField(blank=True, null=True)
    current_employer_text = models.CharField(max_length=100, blank=True, null=True)
    current_location_id = models.IntegerField(blank=True, null=True)
    date_of_birth = models.DateTimeField(blank=True, null=True)
    final_degree_id = models.IntegerField(blank=True, null=True)
    final_degree_text = models.CharField(max_length=100, blank=True, null=True)
    final_department_id = models.IntegerField(blank=True, null=True)
    final_department_text = models.CharField(max_length=70, blank=True, null=True)
    gender = models.IntegerField(blank=True, null=True)
    is_fresher = models.IntegerField(blank=True, null=True)
    current_location_text = models.CharField(max_length=75, blank=True, null=True)
    marital_status = models.IntegerField(blank=True, null=True)
    opening_status_id = models.IntegerField(blank=True, null=True)
    status_id = models.IntegerField(blank=True, null=True)
    total_experience = models.IntegerField(blank=True, null=True)
    notes = models.TextField(blank=True, null=True)
    relevant_experience = models.IntegerField(blank=True, null=True)
    expertise_id1 = models.IntegerField(blank=True, null=True)
    expertise_text = models.CharField(max_length=50, blank=True, null=True)
    expertise_id2 = models.IntegerField(blank=True, null=True)
    hierarchy_id = models.IntegerField(blank=True, null=True)
    hierarchy_text = models.CharField(max_length=50, blank=True, null=True)
    university_id = models.IntegerField(blank=True, null=True)
    university_text = models.CharField(max_length=100, blank=True, null=True)
    email1 = models.CharField(max_length=100, blank=True, null=True)
    email2 = models.CharField(max_length=100, blank=True, null=True)
    first_name = models.CharField(max_length=75, blank=True, null=True)
    importance = models.IntegerField()
    last_name = models.CharField(max_length=75, blank=True, null=True)
    middle_name = models.CharField(max_length=75, blank=True, null=True)
    mobile1 = models.CharField(max_length=20, blank=True, null=True)
    phone_office = models.CharField(max_length=100, blank=True, null=True)
    phone_residence = models.CharField(max_length=100, blank=True, null=True)
    sensitivity = models.IntegerField(blank=True, null=True)
    salutation = models.IntegerField(blank=True, null=True)
    college_id = models.IntegerField(blank=True, null=True)
    college_text = models.CharField(max_length=100, blank=True, null=True)
    resume_grade_id = models.IntegerField(blank=True, null=True)
    no_of_attachments = models.IntegerField()
    experience_updated_on = models.DateTimeField(blank=True, null=True)
    technology_text = models.TextField(blank=True, null=True)
    current_ctc = models.CharField(max_length=255, blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    brownie_point_total = models.IntegerField(blank=True, null=True)
    sourcer = models.IntegerField(blank=True, null=True)
    sourcer_log = models.TextField(blank=True, null=True)
    crm_status_date = models.DateTimeField(blank=True, null=True)
    address1 = models.CharField(max_length=255, blank=True, null=True)
    address2 = models.CharField(max_length=255, blank=True, null=True)
    address3 = models.CharField(max_length=255, blank=True, null=True)
    notice_period = models.IntegerField(blank=True, null=True)
    skill_id = models.IntegerField(blank=True, null=True)
    current_source_id = models.IntegerField(blank=True, null=True)
    sourcer_modified_date = models.DateTimeField(blank=True, null=True)
    percentage_or_cgp = models.FloatField(blank=True, null=True)
    is_percentage = models.IntegerField(blank=True, null=True)
    original_candidate_id = models.IntegerField()
    pan_card = models.CharField(max_length=255, blank=True, null=True)
    passport = models.CharField(max_length=255, blank=True, null=True)
    country_code = models.CharField(max_length=255, blank=True, null=True)
    duplicate_or_blacklist_comment = models.CharField(max_length=255, blank=True, null=True)
    black_list_mode = models.IntegerField()
    is_set_resume_status_to_crm = models.IntegerField(blank=True, null=True)
    is_rejected = models.IntegerField()
    is_partial_duplicate = models.IntegerField()
    soft_delete_type = models.IntegerField(blank=True, null=True)
    candidate_photo_file_id = models.IntegerField(blank=True, null=True)
    candidate_photo_path = models.CharField(max_length=255, blank=True, null=True)
    is_hirepro_vendor_candidate = models.IntegerField()
    is_utilized = models.IntegerField()
    audio_file_name = models.CharField(max_length=255, blank=True, null=True)
    password = models.CharField(max_length=255, blank=True, null=True)
    candidate_name = models.CharField(max_length=255, blank=True, null=True)
    percentage_of_duplication = models.IntegerField()
    bulk_custom_field_string = models.TextField(blank=True, null=True)
    owner_id = models.IntegerField(blank=True, null=True)
    usn = models.CharField(max_length=20, blank=True, null=True)
    country = models.IntegerField(blank=True, null=True)
    nationality = models.IntegerField(blank=True, null=True)
    type_of_candidate = models.IntegerField()
    original_source_id = models.IntegerField()
    source_modified_by = models.IntegerField(blank=True, null=True)
    source_modified_on = models.DateTimeField(blank=True, null=True)
    originated_from = models.IntegerField(blank=True, null=True)
    candidate_user_id = models.IntegerField(blank=True, null=True)
    level_id = models.IntegerField(blank=True, null=True)
    role_id = models.IntegerField(blank=True, null=True)
    mentor = models.IntegerField(blank=True, null=True)
    buddies = models.CharField(max_length=255, blank=True, null=True)
    bu_id = models.IntegerField(blank=True, null=True)
    current_activity = models.IntegerField(blank=True, null=True)
    activity_status = models.IntegerField(blank=True, null=True)
    current_experience = models.IntegerField(blank=True, null=True)
    bpo_experience = models.IntegerField(blank=True, null=True)
    date_custom_field1 = models.DateTimeField(blank=True, null=True)
    date_custom_field2 = models.DateTimeField(blank=True, null=True)
    text_area1 = models.TextField(blank=True, null=True)
    text_area2 = models.TextField(blank=True, null=True)
    text_area3 = models.TextField(blank=True, null=True)
    text_area4 = models.TextField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    true_false2 = models.IntegerField(blank=True, null=True)
    true_false1 = models.IntegerField(blank=True, null=True)
    integer5 = models.IntegerField(blank=True, null=True)
    integer4 = models.IntegerField(blank=True, null=True)
    integer3 = models.IntegerField(blank=True, null=True)
    integer2 = models.IntegerField(blank=True, null=True)
    integer1 = models.IntegerField(blank=True, null=True)
    text5 = models.CharField(max_length=50, blank=True, null=True)
    text4 = models.CharField(max_length=50, blank=True, null=True)
    text3 = models.CharField(max_length=50, blank=True, null=True)
    text2 = models.CharField(max_length=50, blank=True, null=True)
    text1 = models.CharField(max_length=50, blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    candidatepreference = models.ForeignKey(CandidatePreferences, blank=True, null=True)
    candidateoriginalsourceinfo = models.ForeignKey(CandidateOriginalSourceInfos, blank=True, null=True)
    candidatefulltext = models.ForeignKey(CandidateFullTexts, blank=True, null=True)
    familydetail = models.ForeignKey('FamilyDetails', blank=True, null=True)
    candidatestaffingprofile = models.ForeignKey(CandidateStaffingProfiles, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'candidates'


class CatalogGroupMembers(models.Model):
    catalog_value_id = models.IntegerField()
    sequence = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    cataloggroup = models.ForeignKey('CatalogGroups', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'catalog_group_members'


class CatalogGroups(models.Model):
    version = models.IntegerField()
    name = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    catalog_master_id = models.IntegerField(blank=True, null=True)
    is_direct_binding = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    cataloggroup = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'catalog_groups'


class CatalogMasters(models.Model):
    version = models.IntegerField()
    catalog_name = models.CharField(max_length=50, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    is_code_applicable = models.IntegerField()
    is_repeating_value = models.IntegerField()
    is_system_catalog = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    catalogmaster = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'catalog_masters'


class CatalogValues(models.Model):
    code = models.CharField(max_length=20, blank=True, null=True)
    value = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    catalogmaster = models.ForeignKey(CatalogMasters, blank=True, null=True)
    catalogvalue = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'catalog_values'


class ChatMessages(models.Model):
    message = models.CharField(max_length=255, blank=True, null=True)
    direction = models.IntegerField(blank=True, null=True)
    session_id = models.CharField(db_column='session__id', max_length=255, blank=True, null=True)  # Field renamed because it contained more than one '_' in a row.
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'chat_messages'


class ChatSessions(models.Model):
    version = models.IntegerField()
    user_id = models.IntegerField(blank=True, null=True)
    ipaddress = models.CharField(max_length=255, blank=True, null=True)
    is_first_request = models.IntegerField()
    sent_time = models.DateTimeField(blank=True, null=True)
    recieved_time = models.DateTimeField(blank=True, null=True)
    support_user_id = models.IntegerField(blank=True, null=True)
    session_alive = models.IntegerField(blank=True, null=True)
    user_name = models.CharField(max_length=255, blank=True, null=True)
    anonymous_id = models.IntegerField(blank=True, null=True)
    true_false2 = models.IntegerField(blank=True, null=True)
    true_false1 = models.IntegerField(blank=True, null=True)
    integer5 = models.IntegerField(blank=True, null=True)
    integer4 = models.IntegerField(blank=True, null=True)
    integer3 = models.IntegerField(blank=True, null=True)
    integer2 = models.IntegerField(blank=True, null=True)
    integer1 = models.IntegerField(blank=True, null=True)
    text5 = models.CharField(max_length=50, blank=True, null=True)
    text4 = models.CharField(max_length=50, blank=True, null=True)
    text3 = models.CharField(max_length=50, blank=True, null=True)
    text2 = models.CharField(max_length=50, blank=True, null=True)
    text1 = models.CharField(max_length=50, blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'chat_sessions'


class CodingQuestionAttachments(models.Model):
    version = models.IntegerField()
    input_file_id = models.IntegerField(blank=True, null=True)
    output_file_id = models.IntegerField(blank=True, null=True)
    weightage = models.FloatField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    question = models.ForeignKey('Questions', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'coding_question_attachments'


class CodingQuestionLanguages(models.Model):
    version = models.IntegerField()
    language_id = models.IntegerField(blank=True, null=True)
    code_snippet = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    question = models.ForeignKey('Questions', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'coding_question_languages'


class CollegeGroups(models.Model):
    version = models.IntegerField()
    source_id = models.IntegerField(blank=True, null=True)
    group_name = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    collegegroup = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'college_groups'


class Colleges(models.Model):
    college_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    recruitevent = models.ForeignKey('RecruitEvents', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'colleges'


class CommunicationHistorys(models.Model):
    version = models.IntegerField()
    message = models.CharField(max_length=255, blank=True, null=True)
    receiver = models.IntegerField(blank=True, null=True)
    title = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    reference_id = models.IntegerField(blank=True, null=True)
    medium_type = models.IntegerField(blank=True, null=True)
    medium = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    communicationhistory = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'communication_historys'


class CompanyEvents(models.Model):
    version = models.IntegerField()
    subject = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    link_to_id = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    event_type = models.IntegerField(blank=True, null=True)
    company_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'company_events'


class CompanyUsers(models.Model):
    version = models.IntegerField()
    company_id = models.IntegerField()
    user_id = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'company_users'


class Companys(models.Model):
    version = models.IntegerField()
    company_name = models.CharField(max_length=255, blank=True, null=True)
    main_website = models.CharField(max_length=100, blank=True, null=True)
    job_website = models.CharField(max_length=255, blank=True, null=True)
    industry_id = models.IntegerField(blank=True, null=True)
    dictionary_id = models.IntegerField(blank=True, null=True)
    key_technologies = models.CharField(max_length=255, blank=True, null=True)
    reappear_duration = models.IntegerField(blank=True, null=True)
    email1 = models.CharField(max_length=255, blank=True, null=True)
    email2 = models.CharField(max_length=50, blank=True, null=True)
    mobile1 = models.CharField(max_length=20, blank=True, null=True)
    phone_office = models.CharField(max_length=255, blank=True, null=True)
    phone_other = models.CharField(max_length=20, blank=True, null=True)
    site_url = models.CharField(max_length=255, blank=True, null=True)
    fax_number = models.CharField(max_length=20, blank=True, null=True)
    notes = models.TextField(blank=True, null=True)
    valid_from = models.DateTimeField(blank=True, null=True)
    valid_till = models.DateTimeField(blank=True, null=True)
    no_of_attachments = models.IntegerField()
    location_id = models.IntegerField(blank=True, null=True)
    location_text = models.CharField(max_length=75, blank=True, null=True)
    organization_type = models.CharField(max_length=255, blank=True, null=True)
    organization_type_id = models.IntegerField()
    is_source = models.IntegerField()
    is_consultant = models.IntegerField(blank=True, null=True)
    is_tenant = models.IntegerField(blank=True, null=True)
    organization_title = models.CharField(max_length=100, blank=True, null=True)
    organization_description = models.TextField(blank=True, null=True)
    primary_owner_id = models.IntegerField(blank=True, null=True)
    resume_validity = models.IntegerField(blank=True, null=True)
    address1 = models.TextField(blank=True, null=True)
    address2 = models.CharField(max_length=255, blank=True, null=True)
    out_placement_from_date = models.DateTimeField(blank=True, null=True)
    out_placement_to_date = models.DateTimeField(blank=True, null=True)
    sensitivity = models.IntegerField(blank=True, null=True)
    country_code = models.CharField(max_length=255, blank=True, null=True)
    activity_id = models.IntegerField(blank=True, null=True)
    owner_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    true_false2 = models.IntegerField(blank=True, null=True)
    true_false1 = models.IntegerField(blank=True, null=True)
    integer5 = models.IntegerField(blank=True, null=True)
    integer4 = models.IntegerField(blank=True, null=True)
    integer3 = models.IntegerField(blank=True, null=True)
    integer2 = models.IntegerField(blank=True, null=True)
    integer1 = models.IntegerField(blank=True, null=True)
    text5 = models.CharField(max_length=50, blank=True, null=True)
    text4 = models.CharField(max_length=50, blank=True, null=True)
    text3 = models.CharField(max_length=50, blank=True, null=True)
    text2 = models.CharField(max_length=50, blank=True, null=True)
    text1 = models.CharField(max_length=50, blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    contract = models.ForeignKey('Contracts', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'companys'


class Compliances(models.Model):
    version = models.IntegerField()
    initial_resume_status_id = models.IntegerField(blank=True, null=True)
    final_resume_status_id = models.IntegerField(blank=True, null=True)
    time_limit = models.IntegerField(blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'compliances'


class ConfigAssessmentFeedbacks(models.Model):
    job_id = models.IntegerField()
    status_id = models.IntegerField()
    is_rating_required = models.IntegerField(blank=True, null=True)
    is_deleted = models.IntegerField(blank=True, null=True)
    recruit_event_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    assessmenttemplate = models.ForeignKey(AssessmentTemplates, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'config_assessment_feedbacks'


class Consultants(models.Model):
    source = models.ForeignKey('Sources', primary_key=True)
    is_agreement_signed = models.IntegerField()
    company_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'consultants'


class Contacts(models.Model):
    version = models.IntegerField()
    email1 = models.CharField(max_length=50, blank=True, null=True)
    email2 = models.CharField(max_length=50, blank=True, null=True)
    first_name = models.CharField(max_length=75, blank=True, null=True)
    last_name = models.CharField(max_length=75, blank=True, null=True)
    middle_name = models.CharField(max_length=75, blank=True, null=True)
    mobile1 = models.CharField(max_length=20, blank=True, null=True)
    phone_office = models.CharField(max_length=20, blank=True, null=True)
    phone_residence = models.CharField(max_length=20, blank=True, null=True)
    salutation = models.IntegerField()
    job_title = models.CharField(max_length=100, blank=True, null=True)
    notes = models.TextField(blank=True, null=True)
    imaddress = models.CharField(max_length=60, blank=True, null=True)
    department = models.CharField(max_length=75, blank=True, null=True)
    office = models.CharField(max_length=75, blank=True, null=True)
    nick_name = models.CharField(max_length=50, blank=True, null=True)
    anniversary = models.DateTimeField(blank=True, null=True)
    spouse_name = models.CharField(max_length=75, blank=True, null=True)
    date_of_birth = models.DateTimeField(blank=True, null=True)
    category = models.IntegerField(blank=True, null=True)
    photo = models.IntegerField(blank=True, null=True)
    address1 = models.CharField(max_length=255, blank=True, null=True)
    address2 = models.CharField(max_length=255, blank=True, null=True)
    address3 = models.CharField(max_length=255, blank=True, null=True)
    name = models.CharField(max_length=75, blank=True, null=True)
    country_code = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'contacts'


class ContractDetails(models.Model):
    experience_level_id = models.IntegerField(blank=True, null=True)
    billing = models.FloatField(blank=True, null=True)
    billing_amount = models.FloatField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    contract = models.ForeignKey('Contracts', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'contract_details'


class ContractEvents(models.Model):
    version = models.IntegerField()
    subject = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    link_to_id = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    event_type = models.IntegerField(blank=True, null=True)
    contract_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'contract_events'


class ContractIps(models.Model):
    ip_address = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    apicontract = models.ForeignKey(ApiContracts, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'contract_ips'


class ContractMethods(models.Model):
    method_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    apicontract = models.ForeignKey(ApiContracts, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'contract_methods'


class ContractModules(models.Model):
    module_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    apicontract = models.ForeignKey(ApiContracts, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'contract_modules'


class Contracts(models.Model):
    version = models.IntegerField()
    name = models.CharField(max_length=75, blank=True, null=True)
    default_resume_validity = models.IntegerField()
    retainer = models.FloatField(blank=True, null=True)
    transition_time = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'contracts'


class CtcStructures(models.Model):
    version = models.IntegerField()
    provident_fund_percent = models.FloatField(blank=True, null=True)
    super_annuation_fund_percent = models.FloatField(blank=True, null=True)
    hra_percent = models.FloatField()
    level_id = models.IntegerField()
    salary_structure_template_file_id = models.IntegerField(blank=True, null=True)
    offer_template_file_id = models.IntegerField(blank=True, null=True)
    component_ain_percent = models.FloatField(blank=True, null=True)
    component_bin_percent = models.FloatField(blank=True, null=True)
    custom_field_a1_percent = models.FloatField(blank=True, null=True)
    custom_field_a1_label = models.CharField(max_length=255, blank=True, null=True)
    custom_field_a2_percent = models.FloatField(blank=True, null=True)
    custom_field_a2_label = models.CharField(max_length=255, blank=True, null=True)
    custom_field_a3_flat = models.FloatField(blank=True, null=True)
    custom_field_a3_label = models.CharField(max_length=255, blank=True, null=True)
    custom_field_a4_flat = models.FloatField(blank=True, null=True)
    custom_field_a4_label = models.CharField(max_length=255, blank=True, null=True)
    custom_field_a5_flat = models.FloatField(blank=True, null=True)
    custom_field_a5_label = models.CharField(max_length=255, blank=True, null=True)
    custom_field_b1_percent = models.FloatField(blank=True, null=True)
    custom_field_b1_label = models.CharField(max_length=255, blank=True, null=True)
    custom_field_b2_percent = models.FloatField(blank=True, null=True)
    custom_field_b2_label = models.CharField(max_length=255, blank=True, null=True)
    custom_field_b3_flat = models.FloatField(blank=True, null=True)
    custom_field_b3_label = models.CharField(max_length=255, blank=True, null=True)
    custom_field_b4_flat = models.FloatField(blank=True, null=True)
    custom_field_b4_label = models.CharField(max_length=255, blank=True, null=True)
    custom_field_b5_flat = models.FloatField(blank=True, null=True)
    custom_field_b5_label = models.CharField(max_length=255, blank=True, null=True)
    basic_salary_percent = models.FloatField()
    offered_amount_left_in_alabel = models.CharField(max_length=255, blank=True, null=True)
    offered_amount_left_in_blabel = models.CharField(max_length=255, blank=True, null=True)
    custom_field_a6_label = models.CharField(max_length=255, blank=True, null=True)
    custom_field_a6_percent = models.FloatField(blank=True, null=True)
    custom_field_a7_label = models.CharField(max_length=255, blank=True, null=True)
    custom_field_a7_percent = models.FloatField(blank=True, null=True)
    custom_field_a8_label = models.CharField(max_length=255, blank=True, null=True)
    custom_field_a8_flat = models.FloatField(blank=True, null=True)
    custom_field_a9_label = models.CharField(max_length=255, blank=True, null=True)
    custom_field_a9_flat = models.FloatField(blank=True, null=True)
    custom_field_a10_label = models.CharField(max_length=255, blank=True, null=True)
    custom_field_a10_flat = models.FloatField(blank=True, null=True)
    custom_field_a11_label = models.CharField(max_length=255, blank=True, null=True)
    custom_field_a11_flat = models.FloatField(blank=True, null=True)
    custom_field_a12_label = models.CharField(max_length=255, blank=True, null=True)
    custom_field_a12_flat = models.FloatField(blank=True, null=True)
    location_id = models.IntegerField(blank=True, null=True)
    custom_field_a13_flat = models.FloatField(blank=True, null=True)
    custom_field_a13_label = models.CharField(max_length=255, blank=True, null=True)
    custom_field_a14_flat = models.FloatField(blank=True, null=True)
    custom_field_a14_label = models.CharField(max_length=255, blank=True, null=True)
    custom_field_b6_flat = models.FloatField(blank=True, null=True)
    custom_field_b6_label = models.CharField(max_length=255, blank=True, null=True)
    custom_field_b7_flat = models.FloatField(blank=True, null=True)
    custom_field_b7_label = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'ctc_structures'


class CustomerBusinessUnits(models.Model):
    tenant_id = models.IntegerField(blank=True, null=True)
    businessunit = models.ForeignKey(BusinessUnits, blank=True, null=True)
    customer = models.ForeignKey('Customers', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'customer_business_units'


class CustomerCandidateSources(models.Model):
    version = models.IntegerField()
    customer_id = models.IntegerField()
    candidate_id = models.IntegerField()
    source_id = models.IntegerField()
    is_source_expired = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'customer_candidate_sources'


class CustomerCustomEntityFieldsDefss(models.Model):
    version = models.IntegerField()
    property_name = models.CharField(max_length=255, blank=True, null=True)
    property_type = models.CharField(max_length=255, blank=True, null=True)
    label = models.CharField(max_length=255, blank=True, null=True)
    entity_name = models.CharField(max_length=255, blank=True, null=True)
    is_visible = models.IntegerField(blank=True, null=True)
    is_required = models.IntegerField(blank=True, null=True)
    is_visible_in_grid = models.IntegerField(blank=True, null=True)
    is_visible_in_search = models.IntegerField(blank=True, null=True)
    sequence = models.IntegerField(blank=True, null=True)
    customer_id = models.IntegerField(blank=True, null=True)
    job_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'customer_custom_entity_fields_defss'


class CustomerCustomEntityFieldss(models.Model):
    version = models.IntegerField()
    integer1 = models.IntegerField(blank=True, null=True)
    integer2 = models.IntegerField(blank=True, null=True)
    integer3 = models.IntegerField(blank=True, null=True)
    integer4 = models.IntegerField(blank=True, null=True)
    string1 = models.CharField(max_length=255, blank=True, null=True)
    string2 = models.CharField(max_length=255, blank=True, null=True)
    string3 = models.CharField(max_length=255, blank=True, null=True)
    string4 = models.CharField(max_length=255, blank=True, null=True)
    date_time1 = models.DateTimeField(blank=True, null=True)
    date_time2 = models.DateTimeField(blank=True, null=True)
    boolean1 = models.IntegerField(blank=True, null=True)
    boolean2 = models.IntegerField(blank=True, null=True)
    candidate_id = models.IntegerField(blank=True, null=True)
    customer_id = models.IntegerField(blank=True, null=True)
    job_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'customer_custom_entity_fieldss'


#class CustomerVendorContracts(models.Model):
#    version = models.IntegerField()
#    vendor_id = models.IntegerField()
#    customer_tenant_id = models.IntegerField()
#    contract_id = models.IntegerField()
#    expiry_date_from = models.DateTimeField(blank=True, null=True)
#    expiry_date_to = models.DateTimeField(blank=True, null=True)
#    tenant_id = models.IntegerField(blank=True, null=True)
#    published_on = models.DateTimeField(blank=True, null=True)
#    published_by = models.IntegerField(blank=True, null=True)
#    is_active = models.IntegerField(blank=True, null=True)
#    is_draft = models.IntegerField(blank=True, null=True)
#    is_archived = models.IntegerField(blank=True, null=True)
#    is_alive = models.IntegerField()
#    created_by = models.IntegerField()
#    created_on = models.DateTimeField()
#    modified_by = models.IntegerField(blank=True, null=True)
#    modified_on = models.DateTimeField(blank=True, null=True)
#    is_deleted = models.IntegerField()
#    guid = models.CharField(max_length=16)
#    customervendorcontracts = models.ForeignKey('self', blank=True, null=True)

#    class Meta:
#        managed = False
        db_table = 'customer_vendor_contracts'


class Customers(models.Model):
    version = models.IntegerField()
    type_of_customer = models.IntegerField(blank=True, null=True)
    status = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    company = models.ForeignKey(Companys, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'customers'


class DailyBusinessReports(models.Model):
    version = models.IntegerField()
    candidate_id = models.IntegerField()
    candidate_name = models.CharField(max_length=255, blank=True, null=True)
    billing_amount = models.CharField(max_length=255, blank=True, null=True)
    day = models.CharField(max_length=255, blank=True, null=True)
    email_id = models.CharField(max_length=255, blank=True, null=True)
    status_id = models.CharField(max_length=255)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'daily_business_reports'


class DashBoardCandidatesJoiningReports(models.Model):
    candidate_name = models.CharField(max_length=255, blank=True, null=True)
    company_name = models.CharField(max_length=255, blank=True, null=True)
    job_name = models.CharField(max_length=255, blank=True, null=True)
    joining_date = models.DateTimeField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'dash_board_candidates_joining_reports'


class DashBoardRequisitionStatusReports(models.Model):
    selected_name = models.CharField(max_length=255, blank=True, null=True)
    selected_count = models.IntegerField(blank=True, null=True)
    joined_count = models.IntegerField(blank=True, null=True)
    to_forward_name = models.CharField(max_length=255, blank=True, null=True)
    to_forward_count = models.IntegerField(blank=True, null=True)
    matching_name = models.CharField(max_length=255, blank=True, null=True)
    matching_count = models.IntegerField(blank=True, null=True)
    joined_name = models.CharField(max_length=255, blank=True, null=True)
    company_name = models.CharField(max_length=255, blank=True, null=True)
    job_name = models.CharField(max_length=255, blank=True, null=True)
    number_of_openings = models.IntegerField(blank=True, null=True)
    forwarded_name = models.CharField(max_length=255, blank=True, null=True)
    forwarded_count = models.IntegerField(blank=True, null=True)
    number_of_openings_name = models.CharField(max_length=255, blank=True, null=True)
    is_yesterday_status = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    shortlisted_name = models.CharField(max_length=255, blank=True, null=True)
    shortlisted_count = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'dash_board_requisition_status_reports'


class DashboardArticleDesignationDepartments(models.Model):
    designation_id = models.IntegerField()
    department_id = models.IntegerField()
    is_active = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    dashboardarticle = models.ForeignKey('DashboardArticles', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'dashboard_article_designation_departments'


class DashboardArticles(models.Model):
    version = models.IntegerField()
    title = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    order_id = models.IntegerField()
    summary = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'dashboard_articles'


class DaysOfWeeks(models.Model):
    day_of_week = models.IntegerField()
    recurrence = models.ForeignKey('Recurrences', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'days_of_weeks'


class DefaultActionss(models.Model):
    module_id = models.IntegerField(blank=True, null=True)
    action_id = models.IntegerField(blank=True, null=True)
    role_name = models.CharField(max_length=255, blank=True, null=True)
    is_deleted = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'default_actionss'


class Departments(models.Model):
    version = models.IntegerField()
    email1 = models.CharField(max_length=50, blank=True, null=True)
    email2 = models.CharField(max_length=50, blank=True, null=True)
    mobile1 = models.CharField(max_length=20, blank=True, null=True)
    phone_office = models.CharField(max_length=20, blank=True, null=True)
    phone_other = models.CharField(max_length=20, blank=True, null=True)
    fax_number = models.CharField(max_length=20, blank=True, null=True)
    site_url = models.CharField(max_length=255, blank=True, null=True)
    address1 = models.CharField(max_length=255, blank=True, null=True)
    address2 = models.CharField(max_length=255, blank=True, null=True)
    location = models.IntegerField(blank=True, null=True)
    spoc = models.IntegerField(blank=True, null=True)
    country_code = models.CharField(max_length=255, blank=True, null=True)
    is_onboarding_department = models.IntegerField(blank=True, null=True)
    department_name = models.CharField(max_length=50, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    company = models.ForeignKey(Companys, blank=True, null=True)
    department = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'departments'


class DirectApplicants(models.Model):
    source = models.ForeignKey('Sources', primary_key=True)
    is_default_direct_applicant = models.IntegerField(blank=True, null=True)
    direct_applicant_email_id = models.CharField(max_length=50, blank=True, null=True)
    direct_applicant_email_password = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'direct_applicants'


class DisableCatalogss(models.Model):
    catalog_value_id = models.IntegerField(blank=True, null=True)
    is_duplicated = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'disable_catalogss'


class Domains(models.Model):
    domain_id = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    candidate = models.ForeignKey(Candidates, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'domains'


class DuplicateCandidates(models.Model):
    duplicate_candidate_id = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    candidate = models.ForeignKey(Candidates, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'duplicate_candidates'


class EditedAnswerChoices(models.Model):
    choice = models.CharField(max_length=1, blank=True, null=True)
    answer = models.CharField(max_length=255, blank=True, null=True)
    html_string = models.TextField(blank=True, null=True)
    no_of_attachments = models.IntegerField()
    marks = models.FloatField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    editedquestion = models.ForeignKey('EditedQuestions', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'edited_answer_choices'


class EditedAnswers(models.Model):
    correct_answer = models.CharField(max_length=255, blank=True, null=True)
    html_string = models.TextField(blank=True, null=True)
    no_of_attachments = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    editedquestion = models.ForeignKey('EditedQuestions', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'edited_answers'


class EditedQuestionAttachments(models.Model):
    version = models.IntegerField()
    file_id = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    editedquestion = models.ForeignKey('EditedQuestions', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'edited_question_attachments'


class EditedQuestionNoteAttachments(models.Model):
    version = models.IntegerField()
    file_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    editedquestion = models.ForeignKey('EditedQuestions', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'edited_question_note_attachments'


class EditedQuestions(models.Model):
    version = models.IntegerField()
    author = models.IntegerField(blank=True, null=True)
    category_id = models.IntegerField(blank=True, null=True)
    correct = models.IntegerField()
    difficulty_level = models.IntegerField(blank=True, null=True)
    hirepro_question_id = models.IntegerField(blank=True, null=True)
    html_string = models.TextField(blank=True, null=True)
    in_correct = models.IntegerField()
    instruction_id = models.IntegerField(blank=True, null=True)
    is_qa_pending = models.IntegerField(blank=True, null=True)
    is_revised = models.IntegerField()
    is_survey_question = models.IntegerField()
    no_of_attachments = models.IntegerField()
    notes = models.TextField(blank=True, null=True)
    preview_id = models.IntegerField(blank=True, null=True)
    question_flag = models.IntegerField(blank=True, null=True)
    question_label = models.CharField(max_length=255, blank=True, null=True)
    question_originality = models.IntegerField(blank=True, null=True)
    question_reuse = models.IntegerField(blank=True, null=True)
    question_str = models.CharField(max_length=255, blank=True, null=True)
    question_type = models.IntegerField(blank=True, null=True)
    source_id = models.IntegerField(blank=True, null=True)
    source_text = models.CharField(max_length=255, blank=True, null=True)
    status_id = models.IntegerField(blank=True, null=True)
    sub_categories_id = models.IntegerField(blank=True, null=True)
    sub_topic_id = models.IntegerField(blank=True, null=True)
    sub_topic_unit_id = models.IntegerField(blank=True, null=True)
    tag_id = models.IntegerField(blank=True, null=True)
    total_attempt = models.IntegerField()
    un_attempted = models.IntegerField()
    original_question_child_id = models.IntegerField(blank=True, null=True)
    original_question_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    editedquestion = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'edited_questions'


class EffortPipeLineReports(models.Model):
    version = models.IntegerField()
    job_id = models.IntegerField(blank=True, null=True)
    job_title = models.CharField(max_length=255, blank=True, null=True)
    job_code_id = models.IntegerField(blank=True, null=True)
    job_code_text = models.CharField(max_length=255, blank=True, null=True)
    source_id = models.IntegerField(blank=True, null=True)
    source_name = models.CharField(max_length=255, blank=True, null=True)
    business_unit_id = models.IntegerField(blank=True, null=True)
    sub_business_unit_id = models.IntegerField(blank=True, null=True)
    business_unit_text = models.CharField(max_length=255, blank=True, null=True)
    sub_business_unit_text = models.CharField(max_length=255, blank=True, null=True)
    status_id = models.IntegerField(blank=True, null=True)
    status_text = models.CharField(max_length=255, blank=True, null=True)
    anchor_id = models.IntegerField(blank=True, null=True)
    total_cvuploaded = models.IntegerField(blank=True, null=True)
    cvscreened_shortlisted = models.IntegerField(blank=True, null=True)
    cvscreened_rejected = models.IntegerField(blank=True, null=True)
    qualified_for_technical_screening = models.IntegerField(blank=True, null=True)
    technical_screening_shortlisted = models.IntegerField(blank=True, null=True)
    technical_screening_rejected = models.IntegerField(blank=True, null=True)
    technical_interview_shortlisted = models.IntegerField(blank=True, null=True)
    technical_interview_rejected = models.IntegerField(blank=True, null=True)
    second_interview_shortlisted = models.IntegerField(blank=True, null=True)
    second_interview_rejected = models.IntegerField(blank=True, null=True)
    final_interview_shortlisted = models.IntegerField(blank=True, null=True)
    final_interview_rejected = models.IntegerField(blank=True, null=True)
    hrinterview_shortlisted = models.IntegerField(blank=True, null=True)
    hrinterview_rejected = models.IntegerField(blank=True, null=True)
    qualified_for_offer = models.IntegerField(blank=True, null=True)
    fitment_in_process = models.IntegerField(blank=True, null=True)
    offer_with_drawn = models.IntegerField(blank=True, null=True)
    offer_released = models.IntegerField(blank=True, null=True)
    joined = models.IntegerField(blank=True, null=True)
    qualified_for_technical_interview = models.IntegerField(blank=True, null=True)
    qualified_for_second_interview = models.IntegerField(blank=True, null=True)
    qualified_for_final_interview = models.IntegerField(blank=True, null=True)
    qualified_for_hrinterview = models.IntegerField(blank=True, null=True)
    anchor_name = models.CharField(max_length=255, blank=True, null=True)
    primary_owner_id = models.IntegerField(blank=True, null=True)
    primary_owner_name = models.CharField(max_length=255, blank=True, null=True)
    job_name = models.CharField(max_length=255, blank=True, null=True)
    offer_accepted = models.IntegerField(blank=True, null=True)
    pipeline_in_cv_screened = models.IntegerField(blank=True, null=True)
    pipeline_in_technical_screening = models.IntegerField(blank=True, null=True)
    pipeline_in_technical_interivew = models.IntegerField(blank=True, null=True)
    pipeline_in_second_interview = models.IntegerField(blank=True, null=True)
    pipeline_in_final_interview = models.IntegerField(blank=True, null=True)
    pipeline_in_hr_interview = models.IntegerField(blank=True, null=True)
    pipeline_in_offer = models.IntegerField(blank=True, null=True)
    job_created_date = models.DateTimeField(blank=True, null=True)
    third_interview_shortlisted = models.IntegerField(blank=True, null=True)
    third_interview_rejected = models.IntegerField(blank=True, null=True)
    pipeline_in_third_interview = models.IntegerField(blank=True, null=True)
    fourth_interview_shortlisted = models.IntegerField(blank=True, null=True)
    fourth_interview_rejected = models.IntegerField(blank=True, null=True)
    pipeline_in_fourth_interview = models.IntegerField(blank=True, null=True)
    fifth_interview_shortlisted = models.IntegerField(blank=True, null=True)
    fifth_interview_rejected = models.IntegerField(blank=True, null=True)
    pipeline_in_fifth_interview = models.IntegerField(blank=True, null=True)
    sixth_interview_shortlisted = models.IntegerField(blank=True, null=True)
    sixth_interview_rejected = models.IntegerField(blank=True, null=True)
    pipeline_in_sixth_interview = models.IntegerField(blank=True, null=True)
    qualified_for_third_interview = models.IntegerField(blank=True, null=True)
    qualified_for_fourth_interview = models.IntegerField(blank=True, null=True)
    qualified_for_fifth_interview = models.IntegerField(blank=True, null=True)
    qualified_for_sixth_interview = models.IntegerField(blank=True, null=True)
    request_date = models.DateTimeField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    hirepro_source_id = models.IntegerField(blank=True, null=True)
    self_service_type = models.IntegerField(blank=True, null=True)
    is_source_wise = models.IntegerField()
    types_of_source = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    integer1 = models.IntegerField(blank=True, null=True)
    integer2 = models.IntegerField(blank=True, null=True)
    integer3 = models.IntegerField(blank=True, null=True)
    integer4 = models.IntegerField(blank=True, null=True)
    integer5 = models.IntegerField(blank=True, null=True)
    text1 = models.CharField(max_length=255, blank=True, null=True)
    text2 = models.CharField(max_length=255, blank=True, null=True)
    text3 = models.CharField(max_length=255, blank=True, null=True)
    text4 = models.CharField(max_length=255, blank=True, null=True)
    text5 = models.CharField(max_length=255, blank=True, null=True)
    date_time1 = models.DateTimeField(blank=True, null=True)
    date_time2 = models.DateTimeField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'effort_pipe_line_reports'


class EligibilityCriteriaSkills(models.Model):
    skill_id = models.IntegerField(blank=True, null=True)
    skill_level = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    eligibilitycriteria = models.ForeignKey('EligibilityCriterias', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'eligibility_criteria_skills'


class EligibilityCriterias(models.Model):
    version = models.IntegerField()
    name = models.CharField(max_length=255, blank=True, null=True)
    is_utilized = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    from_expirence_in_months = models.IntegerField(blank=True, null=True)
    to_expirence_in_months = models.IntegerField(blank=True, null=True)
    task_id = models.IntegerField(blank=True, null=True)
    is_auto_checked_ec = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'eligibility_criterias'


class EmployeeEvents(models.Model):
    version = models.IntegerField()
    subject = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    link_to_id = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    event_type = models.IntegerField(blank=True, null=True)
    employee_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'employee_events'


class EmployeeLevels(models.Model):
    version = models.IntegerField()
    title = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    average_cost = models.FloatField()
    average_productivity_ratio = models.FloatField()
    gacost = models.FloatField()
    hierarchy = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'employee_levels'


class EmployeeReferralLogs(models.Model):
    version = models.IntegerField()
    candidate_id = models.IntegerField(blank=True, null=True)
    job_id = models.IntegerField(blank=True, null=True)
    source_id = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    candidate_originated_from = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    is_tagged = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'employee_referral_logs'


class Employees(models.Model):
    version = models.IntegerField()
    email1 = models.CharField(max_length=50, blank=True, null=True)
    email2 = models.CharField(max_length=50, blank=True, null=True)
    first_name = models.CharField(max_length=75, blank=True, null=True)
    last_name = models.CharField(max_length=75, blank=True, null=True)
    middle_name = models.CharField(max_length=75, blank=True, null=True)
    mobile1 = models.CharField(max_length=20, blank=True, null=True)
    phone_office = models.CharField(max_length=20, blank=True, null=True)
    phone_residence = models.CharField(max_length=20, blank=True, null=True)
    salutation = models.IntegerField(blank=True, null=True)
    notes = models.CharField(max_length=255, blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    address1 = models.CharField(max_length=255, blank=True, null=True)
    address2 = models.CharField(max_length=255, blank=True, null=True)
    address3 = models.CharField(max_length=255, blank=True, null=True)
    employee_referrals_id = models.CharField(max_length=255, blank=True, null=True)
    password = models.CharField(max_length=255, blank=True, null=True)
    is_employee_referral = models.IntegerField(blank=True, null=True)
    employee_status = models.IntegerField(blank=True, null=True)
    employee_level_id = models.IntegerField(blank=True, null=True)
    date_of_birth = models.DateTimeField(blank=True, null=True)
    country_code = models.CharField(max_length=255, blank=True, null=True)
    designation_id = models.IntegerField(blank=True, null=True)
    onboarding_candidate_id = models.IntegerField(blank=True, null=True)
    employee_name = models.CharField(max_length=50, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    employee = models.ForeignKey('self', blank=True, null=True)
    department = models.ForeignKey(Departments, blank=True, null=True)
    businessunit = models.ForeignKey(BusinessUnits, blank=True, null=True)
    company = models.ForeignKey(Companys, blank=True, null=True)
    interviewer = models.ForeignKey('Interviewers', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'employees'


class EntitiesPropertys(models.Model):
    version = models.IntegerField()
    property_name = models.CharField(max_length=255, blank=True, null=True)
    property_type = models.CharField(max_length=255, blank=True, null=True)
    is_custom_field = models.IntegerField(blank=True, null=True)
    is_catalog_field = models.IntegerField(blank=True, null=True)
    catalog_master_name = models.CharField(max_length=255, blank=True, null=True)
    minimum_length = models.IntegerField(blank=True, null=True)
    maximum_length = models.IntegerField(blank=True, null=True)
    is_default_tenant_property = models.IntegerField()
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    entityinfo = models.ForeignKey('EntityInfos', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'entities_propertys'


class EntityAttachments(models.Model):
    version = models.IntegerField()
    attachment_type = models.IntegerField(blank=True, null=True)
    entity_type = models.IntegerField(blank=True, null=True)
    entity_id = models.IntegerField(blank=True, null=True)
    path = models.TextField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'entity_attachments'


class EntityGridPropertyDefns(models.Model):
    property_order = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    entitygridproperty = models.ForeignKey('EntityGridPropertys', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'entity_grid_property_defns'


class EntityGridPropertys(models.Model):
    version = models.IntegerField()
    module_name = models.IntegerField(blank=True, null=True)
    grid_name = models.IntegerField(blank=True, null=True)
    entityproperty_id = models.IntegerField()
    is_static = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'entity_grid_propertys'


class EntityInfos(models.Model):
    version = models.IntegerField()
    entity_name = models.CharField(max_length=255, blank=True, null=True)
    type_string = models.CharField(max_length=255, blank=True, null=True)
    module_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'entity_infos'


class EntityPropertyDefinitions(models.Model):
    property_label = models.CharField(max_length=255, blank=True, null=True)
    property_order = models.IntegerField()
    is_mandatory = models.IntegerField(blank=True, null=True)
    is_catalog = models.IntegerField()
    master_name_if_catalog = models.CharField(max_length=255, blank=True, null=True)
    is_not_visible = models.IntegerField()
    is_visible_in_grid = models.IntegerField()
    is_visible_in_search = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    entityproperty = models.ForeignKey('EntityPropertys', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'entity_property_definitions'


class EntityPropertyWeightages(models.Model):
    version = models.IntegerField()
    formentitymap_id = models.IntegerField()
    weightage = models.IntegerField(blank=True, null=True)
    profile_label = models.CharField(max_length=255, blank=True, null=True)
    parent_property_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'entity_property_weightages'


class EntityPropertys(models.Model):
    version = models.IntegerField()
    property_name = models.CharField(max_length=255, blank=True, null=True)
    entity_type = models.IntegerField()
    property_type = models.CharField(max_length=255, blank=True, null=True)
    is_custom_property = models.IntegerField()
    property_code = models.CharField(max_length=255)
    mandatory_type = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'entity_propertys'


class EventLocations(models.Model):
    venue_location_id = models.IntegerField(blank=True, null=True)
    venue_location_text = models.CharField(max_length=255, blank=True, null=True)
    job_location_id = models.IntegerField(blank=True, null=True)
    job_location_text = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    recruitevent = models.ForeignKey('RecruitEvents', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'event_locations'


class Events(models.Model):
    version = models.IntegerField()
    event_type = models.IntegerField(blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    subject = models.TextField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    actor_type = models.CharField(max_length=255, blank=True, null=True)
    actor_id = models.IntegerField(blank=True, null=True)
    link_to_type = models.CharField(max_length=255, blank=True, null=True)
    link_to_id = models.IntegerField(blank=True, null=True)
    target_type = models.CharField(max_length=255, blank=True, null=True)
    target_id = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'events'


class ExpRanges(models.Model):
    version = models.IntegerField()
    initial_experience = models.FloatField(blank=True, null=True)
    final_experience = models.FloatField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'exp_ranges'


class ExperienceRanges(models.Model):
    version = models.IntegerField()
    experience_start = models.IntegerField(blank=True, null=True)
    experience_end = models.IntegerField(blank=True, null=True)
    experience_label = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'experience_ranges'


class ExternalHrOwners(models.Model):
    employee_id = models.IntegerField(blank=True, null=True)
    company_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    job = models.ForeignKey('Jobs', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'external_hr_owners'


class ExtractorListeners(models.Model):
    version = models.IntegerField()
    email = models.CharField(max_length=50, blank=True, null=True)
    email_password = models.CharField(max_length=50, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    source = models.ForeignKey('Sources', blank=True, null=True)
    password = models.CharField(max_length=255, blank=True, null=True)
    mail_server = models.CharField(max_length=255, blank=True, null=True)
    port = models.IntegerField(blank=True, null=True)
    is_all_mail_sync_enabled = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'extractor_listeners'


class FamilyDetails(models.Model):
    head_of_family = models.IntegerField(blank=True, null=True)
    hofprofession = models.CharField(max_length=255, blank=True, null=True)
    total_house_income = models.DecimalField(max_digits=19, decimal_places=5, blank=True, null=True)
    annual_income = models.DecimalField(max_digits=19, decimal_places=5, blank=True, null=True)
    dependents = models.IntegerField(blank=True, null=True)
    siblings = models.IntegerField(blank=True, null=True)
    father_name = models.CharField(max_length=255, blank=True, null=True)
    mother_name = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'family_details'


class FeedBackForms(models.Model):
    max_score = models.IntegerField()
    client_expectation = models.TextField(blank=True, null=True)
    job_id = models.IntegerField()
    feed_back_forms_attachment_id = models.IntegerField(blank=True, null=True)
    interview_name = models.CharField(max_length=255, blank=True, null=True)
    is_interviewer_feed_back_not_visible = models.IntegerField(blank=True, null=True)
    interview_round = models.CharField(max_length=255, blank=True, null=True)
    assessment_template_id = models.IntegerField()
    stage_id = models.IntegerField()
    is_rating_required = models.IntegerField(blank=True, null=True)
    interview_mode = models.IntegerField(blank=True, null=True)
    is_automation_process_needed = models.IntegerField(blank=True, null=True)
    recruit_event_id = models.IntegerField(blank=True, null=True)
    conflict_config = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'feed_back_forms'


class FileContents(models.Model):
    file_content = models.TextField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'file_contents'


class FileLists(models.Model):
    version = models.IntegerField()
    resume_source_id = models.IntegerField(blank=True, null=True)
    initial_file_path = models.TextField(blank=True, null=True)
    status = models.IntegerField(blank=True, null=True)
    date_added = models.DateTimeField(blank=True, null=True)
    subject = models.CharField(max_length=255, blank=True, null=True)
    mail_id = models.IntegerField()
    log = models.CharField(max_length=255, blank=True, null=True)
    original_file_id = models.IntegerField(blank=True, null=True)
    html_file_id = models.IntegerField(blank=True, null=True)
    xml_file_id = models.IntegerField(blank=True, null=True)
    candidate_id = models.IntegerField()
    teared_file_id = models.IntegerField(blank=True, null=True)
    is_indexed = models.IntegerField(blank=True, null=True)
    is_skills_extracted = models.IntegerField(blank=True, null=True)
    object_status = models.IntegerField(blank=True, null=True)
    candidate_source_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'file_lists'


class Files(models.Model):
    version = models.IntegerField()
    title = models.TextField(blank=True, null=True)
    original_file_name = models.TextField(blank=True, null=True)
    file_type_id = models.IntegerField(blank=True, null=True)
    file_type_text = models.CharField(max_length=50, blank=True, null=True)
    file_format_id = models.IntegerField(blank=True, null=True)
    file_size = models.BigIntegerField()
    is_compressed = models.IntegerField(blank=True, null=True)
    is_encrypted = models.IntegerField(blank=True, null=True)
    target_path = models.TextField(blank=True, null=True)
    file_created_on = models.DateTimeField()
    file_modified_on = models.DateTimeField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    filecontent = models.ForeignKey(FileContents, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'files'


class FilledFormContents(models.Model):
    control_id = models.IntegerField(blank=True, null=True)
    control_value = models.CharField(max_length=255, blank=True, null=True)
    form_control_type = models.IntegerField(blank=True, null=True)
    form_entity_map_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    filledform = models.ForeignKey('FilledForms', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'filled_form_contents'


class FilledForms(models.Model):
    version = models.IntegerField()
    form_filled_by = models.IntegerField(blank=True, null=True)
    form_id = models.IntegerField(blank=True, null=True)
    comments = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'filled_forms'


class FixedRtcChildQuestions(models.Model):
    question_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    rtcrandomizedquestion = models.ForeignKey('RtcRandomizedQuestions', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'fixed_rtc_child_questions'


class FormControlGroups(models.Model):
    name = models.CharField(max_length=255, blank=True, null=True)
    label = models.CharField(max_length=255, blank=True, null=True)
    sequence = models.IntegerField(blank=True, null=True)
    form = models.ForeignKey('Forms', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'form_control_groups'


class FormControls(models.Model):
    name = models.CharField(max_length=255, blank=True, null=True)
    label = models.CharField(max_length=255, blank=True, null=True)
    tool_tip = models.CharField(max_length=255, blank=True, null=True)
    is_mandatory = models.IntegerField(blank=True, null=True)
    max_length = models.IntegerField(blank=True, null=True)
    catalog_master_name = models.CharField(max_length=255, blank=True, null=True)
    group_control_values = models.CharField(max_length=255, blank=True, null=True)
    group_id = models.IntegerField(blank=True, null=True)
    group_name = models.CharField(max_length=255, blank=True, null=True)
    sequence_id = models.IntegerField(blank=True, null=True)
    settings = models.CharField(max_length=255, blank=True, null=True)
    validation_type = models.IntegerField(blank=True, null=True)
    form_control_type = models.IntegerField(blank=True, null=True)
    form_entity_map_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    form = models.ForeignKey('Forms', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'form_controls'


class FormEntityMaps(models.Model):
    version = models.IntegerField()
    name = models.CharField(max_length=255, blank=True, null=True)
    entity_id = models.IntegerField(blank=True, null=True)
    entity_property = models.CharField(max_length=255, blank=True, null=True)
    weightage = models.IntegerField(blank=True, null=True)
    entity_catalog = models.CharField(max_length=255, blank=True, null=True)
    control_type = models.IntegerField(blank=True, null=True)
    validation_type = models.IntegerField(blank=True, null=True)
    group_value = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    formentitymap = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'form_entity_maps'


class FormValidationRules(models.Model):
    control_id = models.IntegerField(blank=True, null=True)
    validation_rule = models.IntegerField(blank=True, null=True)
    validation_data = models.CharField(max_length=255, blank=True, null=True)
    dependent_rule_id = models.IntegerField(blank=True, null=True)
    dependent_action = models.IntegerField(blank=True, null=True)
    formvalidation = models.ForeignKey('FormValidations', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'form_validation_rules'


class FormValidations(models.Model):
    version = models.IntegerField()
    title = models.CharField(max_length=255, blank=True, null=True)
    form_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'form_validations'


class Forms(models.Model):
    version = models.IntegerField()
    title = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    hirepro_form_id = models.IntegerField(blank=True, null=True)
    is_required_validation = models.IntegerField(blank=True, null=True)
    type_of_form = models.IntegerField(blank=True, null=True)
    is_need_to_pass_all_validations = models.IntegerField(blank=True, null=True)
    validation_failure_message = models.CharField(max_length=255, blank=True, null=True)
    validation_failure_action = models.IntegerField(blank=True, null=True)
    header = models.CharField(max_length=255, blank=True, null=True)
    footer = models.CharField(max_length=255, blank=True, null=True)
    disclaimer = models.CharField(max_length=255, blank=True, null=True)
    is_system_form = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'forms'


class Groups(models.Model):
    version = models.IntegerField()
    name = models.CharField(max_length=75, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    department_id = models.IntegerField(blank=True, null=True)
    total_members = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'groups'


class HelpDeskParticipants(models.Model):
    tenant_id = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    department_id = models.IntegerField(blank=True, null=True)
    query_participant_type = models.IntegerField(blank=True, null=True)
    helpdesk = models.ForeignKey('HelpDesks', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'help_desk_participants'


class HelpDesks(models.Model):
    version = models.IntegerField()
    help_desk_status = models.IntegerField(blank=True, null=True)
    sub_query_status = models.IntegerField(blank=True, null=True)
    message = models.CharField(max_length=255, blank=True, null=True)
    sender = models.IntegerField(blank=True, null=True)
    receiver = models.IntegerField(blank=True, null=True)
    title = models.CharField(max_length=255, blank=True, null=True)
    sender_department = models.IntegerField(blank=True, null=True)
    receiver_department = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    reference_id = models.IntegerField(blank=True, null=True)
    category_id = models.IntegerField(blank=True, null=True)
    criticality = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    helpdesk = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'help_desks'


class HireproQuestionLogs(models.Model):
    version = models.IntegerField()
    hirepro_question_id = models.IntegerField(blank=True, null=True)
    destination_tenant_id = models.IntegerField(blank=True, null=True)
    destination_question_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'hirepro_question_logs'


class HiringForecastByWeeks(models.Model):
    week = models.IntegerField()
    demand = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    hiringforecast = models.ForeignKey('HiringForecasts', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'hiring_forecast_by_weeks'


class HiringForecasts(models.Model):
    version = models.IntegerField()
    department_id = models.IntegerField()
    location_id = models.IntegerField(blank=True, null=True)
    sub_department_id = models.IntegerField(blank=True, null=True)
    year = models.IntegerField()
    quarter = models.IntegerField(blank=True, null=True)
    demand = models.IntegerField()
    skill_category_id = models.IntegerField(blank=True, null=True)
    competency_id = models.IntegerField(blank=True, null=True)
    job_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'hiring_forecasts'


class IcalItems(models.Model):
    version = models.IntegerField()
    uid = models.TextField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    appointmentitem = models.ForeignKey(AppointmentItems, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'ical_items'


class InternalHrOwners(models.Model):
    user_id = models.IntegerField()
    owner_type = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    job = models.ForeignKey('Jobs', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'internal_hr_owners'


class InternalOwners(models.Model):
    owner_type = models.IntegerField(blank=True, null=True)
    employee_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    customer = models.ForeignKey(Customers, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'internal_owners'


class InterviewCandidates(models.Model):
    candidate_id = models.IntegerField(blank=True, null=True)
    applicant_status_id = models.IntegerField(blank=True, null=True)
    interview_time = models.DateTimeField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    interviewrequest = models.ForeignKey('InterviewRequests', blank=True, null=True)
    bulkinterview = models.ForeignKey(BulkInterviews, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'interview_candidates'


class InterviewFilledFeedbackForms(models.Model):
    interviewer_dicision = models.IntegerField(blank=True, null=True)
    comment = models.CharField(max_length=255, blank=True, null=True)
    feedback_reason = models.IntegerField(blank=True, null=True)
    interviewed_time = models.DateTimeField(blank=True, null=True)
    interview_duration = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    interviewrequest = models.ForeignKey('InterviewRequests', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'interview_filled_feedback_forms'


class InterviewInterviwers(models.Model):
    interviewer = models.IntegerField(blank=True, null=True)
    interview_time = models.DateTimeField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    interviewrequest = models.ForeignKey('InterviewRequests', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'interview_interviwers'


class InterviewPanels(models.Model):
    version = models.IntegerField()
    user_id = models.IntegerField(blank=True, null=True)
    panel_name = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    interviewpanel = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'interview_panels'


class InterviewRequests(models.Model):
    interview_time = models.DateTimeField(blank=True, null=True)
    interview_type = models.IntegerField(blank=True, null=True)
    is_interviewed = models.IntegerField(blank=True, null=True)
    stage_id = models.IntegerField(blank=True, null=True)
    client_decision_status = models.IntegerField(blank=True, null=True)
    interviewer_comment = models.TextField(blank=True, null=True)
    venue_detail = models.TextField(blank=True, null=True)
    feed_back_form_id = models.IntegerField()
    is_reschedule_requested = models.IntegerField()
    interview_mode_id = models.IntegerField(blank=True, null=True)
    job_id = models.IntegerField(blank=True, null=True)
    tech_screening = models.IntegerField(blank=True, null=True)
    location_id = models.IntegerField(blank=True, null=True)
    interveiwee_score = models.FloatField(blank=True, null=True)
    is_deleted = models.IntegerField()
    reschedule_request_comment = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'interview_requests'


class InterviewerFeedbacks(models.Model):
    applicant_status_id = models.IntegerField()
    interviewer_id = models.IntegerField(blank=True, null=True)
    interview_request_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    interviewfilledfeedbackform = models.ForeignKey(InterviewFilledFeedbackForms, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'interviewer_feedbacks'


class Interviewers(models.Model):
    status = models.IntegerField(blank=True, null=True)
    is_qualified_interviewer = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'interviewers'


class Issues(models.Model):
    issue_subject_id = models.IntegerField()
    issue_type_id = models.IntegerField()
    description = models.CharField(max_length=255, blank=True, null=True)
    resolution_type_id = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    job = models.ForeignKey('Jobs', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'issues'


class JobAndListTagRule(models.Model):
    version = models.IntegerField()
    job_search_text = models.CharField(max_length=255, blank=True, null=True)
    job_id = models.IntegerField(blank=True, null=True)
    list_search_text = models.CharField(max_length=255, blank=True, null=True)
    search_area = models.IntegerField(blank=True, null=True)
    list_id = models.IntegerField(blank=True, null=True)
    rule_priority = models.IntegerField()
    is_job_tagging_rule_enabled = models.IntegerField()
    is_list_tagging_rule_enabled = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'job_and_list_tag_rule'


class JobApprovalLevels(models.Model):
    version = models.IntegerField()
    name = models.TextField(blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    approver_user_id = models.IntegerField()
    approval_sequence = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'job_approval_levels'


class JobApprovers(models.Model):
    is_approved = models.IntegerField()
    user_id = models.IntegerField()
    approver_level_id = models.IntegerField()
    is_current_approver = models.IntegerField()
    job_approver_status = models.IntegerField(blank=True, null=True)
    comment = models.CharField(max_length=250, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    job = models.ForeignKey('Jobs', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'job_approvers'


class JobAssessmentTemplates(models.Model):
    assessment_template_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    job = models.ForeignKey('Jobs', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'job_assessment_templates'


class JobBusinessUnits(models.Model):
    bu_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'job_business_units'


class JobCategorys(models.Model):
    category_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    job = models.ForeignKey('Jobs', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'job_categorys'


class JobCodeAssessmentTemplates(models.Model):
    assessment_template_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    jobcode = models.ForeignKey('JobCodes', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'job_code_assessment_templates'


class JobCodeCompetencys(models.Model):
    competency_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    jobcode = models.ForeignKey('JobCodes', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'job_code_competencys'


class JobCodePoints(models.Model):
    version = models.IntegerField()
    hierarchy_id = models.IntegerField()
    skill_category_id = models.IntegerField()
    points = models.FloatField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'job_code_points'


class JobCodes(models.Model):
    version = models.IntegerField()
    code = models.CharField(max_length=255, blank=True, null=True)
    requirement_name = models.CharField(max_length=255, blank=True, null=True)
    department_id = models.IntegerField(blank=True, null=True)
    sub_department_id = models.IntegerField(blank=True, null=True)
    skill_category_id = models.IntegerField(blank=True, null=True)
    job_code_point_id = models.IntegerField(blank=True, null=True)
    no_of_attachments = models.IntegerField(blank=True, null=True)
    experience_from = models.IntegerField(blank=True, null=True)
    experience_to = models.IntegerField(blank=True, null=True)
    hierarchy_id = models.IntegerField(blank=True, null=True)
    salary_start = models.FloatField(blank=True, null=True)
    salary_end = models.FloatField(blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'job_codes'


class JobCompetencys(models.Model):
    competency_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    job = models.ForeignKey('Jobs', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'job_competencys'


class JobDelays(models.Model):
    delay_from = models.DateTimeField(blank=True, null=True)
    delay_to = models.DateTimeField(blank=True, null=True)
    comments = models.TextField(blank=True, null=True)
    is_not_required = models.IntegerField()
    delay_category_id = models.IntegerField(blank=True, null=True)
    no_of_attachments = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    job = models.ForeignKey('Jobs', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'job_delays'


class JobEducationDetails(models.Model):
    degree_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    job = models.ForeignKey('Jobs', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'job_education_details'


class JobEvents(models.Model):
    version = models.IntegerField()
    subject = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    source_id = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    event_type = models.IntegerField(blank=True, null=True)
    job_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'job_events'


class JobFullTexts(models.Model):
    jobsearch_fulltext = models.TextField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'job_full_texts'


class JobInterviewers(models.Model):
    interviewer_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    job = models.ForeignKey('Jobs', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'job_interviewers'


class JobLocations(models.Model):
    location_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    job = models.ForeignKey('Jobs', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'job_locations'


class JobPositions(models.Model):
    req_code = models.CharField(max_length=255)
    date_open = models.DateTimeField(blank=True, null=True)
    date_closed = models.DateTimeField(blank=True, null=True)
    job_position_status_id = models.IntegerField(blank=True, null=True)
    is_freezed = models.IntegerField()
    offered_date = models.DateTimeField(blank=True, null=True)
    joined_date = models.DateTimeField(blank=True, null=True)
    date_dropped = models.DateTimeField(blank=True, null=True)
    offer_accepted_date = models.DateTimeField(blank=True, null=True)
    source_id = models.IntegerField(blank=True, null=True)
    is_position_joined_or_dropped = models.IntegerField()
    planned_date_of_joining = models.DateTimeField(blank=True, null=True)
    is_internal_conversion = models.IntegerField()
    type_of_position = models.IntegerField(blank=True, null=True)
    remarks = models.TextField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    job = models.ForeignKey('Jobs', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'job_positions'


class JobPostings(models.Model):
    duplicate_template = models.IntegerField(blank=True, null=True)
    maximum_no_of_resumes = models.IntegerField(blank=True, null=True)
    posting_date = models.DateTimeField(blank=True, null=True)
    open_date = models.DateTimeField(blank=True, null=True)
    closed_date = models.DateTimeField(blank=True, null=True)
    points = models.FloatField(blank=True, null=True)
    status = models.IntegerField(blank=True, null=True)
    note = models.CharField(max_length=255, blank=True, null=True)
    source_id = models.IntegerField(blank=True, null=True)
    screening_template = models.IntegerField(blank=True, null=True)
    no_of_duplicates = models.IntegerField(blank=True, null=True)
    no_of_resumes_sourced = models.IntegerField(blank=True, null=True)
    self_service_type = models.IntegerField(blank=True, null=True)
    posted_by = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    job = models.ForeignKey('Jobs', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'job_postings'


class JobRequiredSkills(models.Model):
    skill_id = models.IntegerField(blank=True, null=True)
    priority_id = models.IntegerField(blank=True, null=True)
    mandatory_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    job = models.ForeignKey('Jobs', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'job_required_skills'


class JobScreeningRules(models.Model):
    priority = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    screeningrule = models.ForeignKey('ScreeningRules', blank=True, null=True)
    job = models.ForeignKey('Jobs', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'job_screening_rules'


class JobSlas(models.Model):
    version = models.IntegerField()
    job_id = models.IntegerField()
    stage_id = models.IntegerField()
    active_pipeline_count = models.IntegerField()
    good_pipeline_range_from = models.IntegerField()
    good_pipeline_range_to = models.IntegerField()
    avg_pipeline_range_from = models.IntegerField()
    avg_pipeline_range_to = models.IntegerField()
    ageing_range_from = models.IntegerField()
    ageing_range_to = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'job_slas'


class Jobs(models.Model):
    version = models.IntegerField()
    notes = models.TextField(blank=True, null=True)
    jobs_to_be_filled_within = models.DateTimeField(blank=True, null=True)
    requirements_priority_id = models.IntegerField(blank=True, null=True)
    status_id = models.IntegerField(blank=True, null=True)
    visibility_id = models.IntegerField(blank=True, null=True)
    category_id = models.IntegerField(blank=True, null=True)
    location_id = models.IntegerField(blank=True, null=True)
    location_text = models.CharField(max_length=75, blank=True, null=True)
    salary_start = models.FloatField(blank=True, null=True)
    salary_end = models.FloatField(blank=True, null=True)
    benefits = models.TextField(blank=True, null=True)
    experience_start = models.IntegerField(blank=True, null=True)
    experience_end = models.IntegerField(blank=True, null=True)
    technology_text = models.TextField(blank=True, null=True)
    no_of_openings = models.IntegerField()
    expertise_id = models.IntegerField(blank=True, null=True)
    hierarchy_id = models.IntegerField(blank=True, null=True)
    no_of_attachments = models.IntegerField()
    sensitivity = models.IntegerField(blank=True, null=True)
    primary_internal_hr_owner_id = models.IntegerField()
    primary_external_hr_owner_id = models.IntegerField()
    is_private = models.IntegerField()
    job_title = models.TextField(blank=True, null=True)
    is_company_confidential = models.IntegerField(blank=True, null=True)
    type_of_job = models.IntegerField(blank=True, null=True)
    projected_no_of_closer = models.IntegerField()
    customer_requisition_status = models.IntegerField(blank=True, null=True)
    avg_billing_amount_per_position = models.FloatField()
    expected_total_billing_amount = models.FloatField(blank=True, null=True)
    difficulty_level = models.IntegerField(blank=True, null=True)
    percentage_of_billing_we_do = models.FloatField()
    is_job_approved = models.IntegerField()
    skill_id = models.IntegerField(blank=True, null=True)
    job_open_date = models.DateTimeField(blank=True, null=True)
    job_closed_date = models.DateTimeField(blank=True, null=True)
    role_id = models.IntegerField(blank=True, null=True)
    publish_to_employee_referral = models.IntegerField(blank=True, null=True)
    parent_job_thread_id = models.IntegerField(blank=True, null=True)
    is_freezed = models.IntegerField()
    experience_range_id = models.IntegerField(blank=True, null=True)
    department_id = models.IntegerField(blank=True, null=True)
    is_budgeted = models.IntegerField(blank=True, null=True)
    criticality = models.IntegerField(blank=True, null=True)
    job_code_id = models.IntegerField(blank=True, null=True)
    hiring_manager_id = models.IntegerField(blank=True, null=True)
    work_mode = models.IntegerField(blank=True, null=True)
    other_work_mode = models.CharField(max_length=255, blank=True, null=True)
    type_of_organization = models.IntegerField(blank=True, null=True)
    other_interviewer = models.CharField(max_length=255, blank=True, null=True)
    project_start_date = models.DateTimeField(blank=True, null=True)
    is_travel_required = models.IntegerField(blank=True, null=True)
    cost_centre = models.CharField(max_length=255, blank=True, null=True)
    is_replacement = models.IntegerField(blank=True, null=True)
    replacement_text = models.CharField(max_length=255, blank=True, null=True)
    job_code_other_text = models.CharField(max_length=255, blank=True, null=True)
    job_code_point = models.IntegerField(blank=True, null=True)
    no_of_positions_joined_or_dropped = models.IntegerField(blank=True, null=True)
    sub_department_id = models.IntegerField(blank=True, null=True)
    priority_id = models.IntegerField(blank=True, null=True)
    date_custom_field1 = models.DateTimeField(blank=True, null=True)
    date_custom_field2 = models.DateTimeField(blank=True, null=True)
    is_part_time_job = models.IntegerField()
    original_req_id = models.IntegerField(blank=True, null=True)
    is_heads_up_position = models.IntegerField()
    delay_days = models.IntegerField(blank=True, null=True)
    is_utilized = models.IntegerField()
    audio_file_name = models.CharField(max_length=255, blank=True, null=True)
    business_unit_id = models.IntegerField(blank=True, null=True)
    sub_business_unit_id = models.IntegerField(blank=True, null=True)
    is_screening_rule_configured = models.IntegerField(blank=True, null=True)
    job_name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    internal_requisition_status = models.IntegerField(blank=True, null=True)
    position = models.IntegerField(blank=True, null=True)
    is_portal_hot_job = models.IntegerField(blank=True, null=True)
    status_modified_on_delay = models.DateTimeField(blank=True, null=True)
    is_job_posting_active = models.IntegerField(blank=True, null=True)
    is_utilized_in_event = models.IntegerField(blank=True, null=True)
    job_approvers_names = models.CharField(max_length=255, blank=True, null=True)
    function_id = models.IntegerField(blank=True, null=True)
    sub_function_id = models.IntegerField(blank=True, null=True)
    search_status_id = models.IntegerField(blank=True, null=True)
    selection_process_id = models.IntegerField(blank=True, null=True)
    male_diversity = models.IntegerField(blank=True, null=True)
    female_diversity = models.IntegerField(blank=True, null=True)
    years_of_passing = models.CharField(max_length=255, blank=True, null=True)
    master_job_id = models.IntegerField(blank=True, null=True)
    is_status_notification = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    true_false2 = models.IntegerField(blank=True, null=True)
    true_false1 = models.IntegerField(blank=True, null=True)
    integer5 = models.IntegerField(blank=True, null=True)
    integer4 = models.IntegerField(blank=True, null=True)
    integer3 = models.IntegerField(blank=True, null=True)
    integer2 = models.IntegerField(blank=True, null=True)
    integer1 = models.IntegerField(blank=True, null=True)
    text5 = models.CharField(max_length=50, blank=True, null=True)
    text4 = models.CharField(max_length=50, blank=True, null=True)
    text3 = models.CharField(max_length=50, blank=True, null=True)
    text2 = models.CharField(max_length=50, blank=True, null=True)
    text1 = models.CharField(max_length=50, blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    company = models.ForeignKey(Companys, blank=True, null=True)
    jobfulltext = models.ForeignKey(JobFullTexts, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'jobs'


class LanguageKnowns(models.Model):
    language_id = models.IntegerField()
    proficiency = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    candidate = models.ForeignKey(Candidates, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'language_knowns'


class LanuageBarriers(models.Model):
    language_id = models.IntegerField(blank=True, null=True)
    proficiency = models.IntegerField(blank=True, null=True)
    num_of_hiring = models.IntegerField(blank=True, null=True)
    comment = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    eligibilitycriteria = models.ForeignKey(EligibilityCriterias, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'lanuage_barriers'


class LegacyData(models.Model):
    source = models.ForeignKey('Sources', primary_key=True)
    resume_source_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'legacy_data'


class ListItems(models.Model):
    is_read = models.IntegerField()
    is_starred = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    list = models.ForeignKey('Lists', blank=True, null=True)
    item_type = models.CharField(max_length=255, blank=True, null=True)
    item_id = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'list_items'


class ListUsers(models.Model):
    user_id = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    list = models.ForeignKey('Lists', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'list_users'


class Lists(models.Model):
    version = models.IntegerField()
    list_name = models.CharField(max_length=50, blank=True, null=True)
    target_type = models.IntegerField(blank=True, null=True)
    is_smart = models.IntegerField()
    search_type = models.IntegerField(blank=True, null=True)
    is_public = models.IntegerField()
    smart_condition = models.TextField(blank=True, null=True)
    notes = models.TextField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'lists'


class MacroTechnicals(models.Model):
    macro_technical_id = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    candidate = models.ForeignKey(Candidates, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'macro_technicals'


class MailCounts(models.Model):
    version = models.IntegerField()
    sent_mail_count = models.IntegerField(blank=True, null=True)
    received_mail_count = models.IntegerField(blank=True, null=True)
    draft_mail_count = models.IntegerField(blank=True, null=True)
    bulk_mail_count = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    latest_mail_count = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'mail_counts'


class MailItems(models.Model):
    version = models.IntegerField()
    received_time = models.DateTimeField(blank=True, null=True)
    is_read = models.IntegerField()
    email_address = models.CharField(max_length=60, blank=True, null=True)
    is_to = models.IntegerField()
    is_cc = models.IntegerField()
    is_bcc = models.IntegerField()
    subject = models.TextField(blank=True, null=True)
    sent_time = models.DateTimeField(blank=True, null=True)
    no_of_attachments = models.IntegerField(blank=True, null=True)
    flag_to = models.IntegerField(blank=True, null=True)
    flag_due_by = models.DateTimeField(blank=True, null=True)
    is_flag_completed = models.IntegerField()
    is_reminder_set = models.IntegerField()
    reminder_minutes_before_start = models.IntegerField()
    to_email_ids = models.TextField(blank=True, null=True)
    cc_email_ids = models.TextField(blank=True, null=True)
    bcc_email_ids = models.TextField(blank=True, null=True)
    communication_direction = models.IntegerField()
    from_email_id = models.CharField(max_length=60, blank=True, null=True)
    sender_email_id = models.CharField(max_length=60, blank=True, null=True)
    size = models.BigIntegerField()
    contact_id = models.IntegerField(blank=True, null=True)
    contact_type = models.CharField(max_length=255, blank=True, null=True)
    sensitivity = models.IntegerField(blank=True, null=True)
    importance = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    body = models.ForeignKey(Bodys, blank=True, null=True)
    mailitem = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'mail_items'


class MailValidators(models.Model):
    from_email_address = models.CharField(max_length=255, blank=True, null=True)
    from_email_domain = models.CharField(max_length=255, blank=True, null=True)
    subject = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'mail_validators'


class MassMailAdmins(models.Model):
    version = models.IntegerField()
    user_id = models.IntegerField(blank=True, null=True)
    user_email = models.CharField(max_length=255, blank=True, null=True)
    daily_quota = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'mass_mail_admins'


class MassMailCounters(models.Model):
    version = models.IntegerField()
    user_email = models.CharField(max_length=255, blank=True, null=True)
    mail_counter = models.IntegerField(blank=True, null=True)
    curent_date = models.DateTimeField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'mass_mail_counters'


class MassMailLogs(models.Model):
    version = models.IntegerField()
    user_email = models.CharField(max_length=255, blank=True, null=True)
    curent_date = models.DateTimeField(blank=True, null=True)
    log = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'mass_mail_logs'


class MasterConfigurationEvents(models.Model):
    version = models.IntegerField()
    subject = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    link_to_id = models.IntegerField(blank=True, null=True)
    target_id = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    event_type = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'master_configuration_events'


class MasterConfigurations(models.Model):
    version = models.IntegerField()
    resume_repository = models.CharField(max_length=255, blank=True, null=True)
    decompressed_file = models.CharField(max_length=255, blank=True, null=True)
    mail_server = models.CharField(max_length=255, blank=True, null=True)
    optional_mail_server = models.CharField(max_length=255, blank=True, null=True)
    file_repository = models.CharField(max_length=255, blank=True, null=True)
    event_log_directory = models.CharField(max_length=255, blank=True, null=True)
    no_of_days_to_keep_events_in_database = models.IntegerField(blank=True, null=True)
    send_mail_to_user = models.IntegerField(blank=True, null=True)
    self_service_url = models.CharField(max_length=255, blank=True, null=True)
    self_service_mail_template = models.CharField(max_length=255, blank=True, null=True)
    direct_mail_users = models.TextField(blank=True, null=True)
    send_sent_mail_copy_to_outlook = models.IntegerField(blank=True, null=True)
    refer_job_mail_template = models.CharField(max_length=255, blank=True, null=True)
    content_attachment_storage_mode = models.IntegerField(blank=True, null=True)
    activity_attachment_storage_mode = models.IntegerField(blank=True, null=True)
    other_attachment_storage_mode = models.IntegerField(blank=True, null=True)
    daily_report_recepients = models.TextField(blank=True, null=True)
    is_job_approve_enabled = models.IntegerField()
    active_validity_period = models.IntegerField(blank=True, null=True)
    alive_validity_period = models.IntegerField(blank=True, null=True)
    candidate_sourcer_expiry_days = models.IntegerField(blank=True, null=True)
    pop3_mail_server = models.CharField(max_length=255, blank=True, null=True)
    mail_server_port = models.IntegerField(blank=True, null=True)
    notification_sender_email_id = models.CharField(max_length=50, blank=True, null=True)
    notification_sender_email_password = models.CharField(max_length=50, blank=True, null=True)
    employee_referral_to_email_password = models.CharField(max_length=50, blank=True, null=True)
    employee_referral_to_email = models.CharField(max_length=50, blank=True, null=True)
    internal_employee_referral_email_domain = models.CharField(max_length=50, blank=True, null=True)
    is_position_manager_enabled = models.IntegerField()
    is_job_posting_detail_enabled = models.IntegerField()
    is_action_to_be_taken_after_source_expiry = models.IntegerField()
    on_duplication_found_action = models.IntegerField(blank=True, null=True)
    assessment_template_id = models.IntegerField(blank=True, null=True)
    job_primary_owner = models.IntegerField(blank=True, null=True)
    ctc_approver1 = models.IntegerField(blank=True, null=True)
    ctc_approver2 = models.IntegerField(blank=True, null=True)
    duplication_check_period = models.IntegerField(blank=True, null=True)
    is_reject_candidate_on_app_status_rejected = models.IntegerField()
    export_candidate_properties_text = models.CharField(max_length=255, blank=True, null=True)
    is_partial_duplicate_by_admin = models.IntegerField(blank=True, null=True)
    is_black_list_candidate_required = models.IntegerField(blank=True, null=True)
    is_close_job_on_all_positions_filled = models.IntegerField()
    is_ssl_mailserver = models.IntegerField(blank=True, null=True)
    is_offer_manager_enabled = models.IntegerField()
    password_expiry_limit_in_days = models.IntegerField(blank=True, null=True)
    is_employee_create_enabled = models.IntegerField(blank=True, null=True)
    is_status_notification_for_employee_referral_enabled = models.IntegerField(blank=True, null=True)
    is_bulk_interview_time_optional = models.IntegerField()
    pofu_status_id = models.IntegerField(blank=True, null=True)
    position_tag_status_id = models.IntegerField(blank=True, null=True)
    forecast_settings = models.CharField(max_length=255, blank=True, null=True)
    rejected_candidate_visibility = models.CharField(max_length=255, blank=True, null=True)
    vendor_billing_verifier = models.IntegerField(blank=True, null=True)
    is_show_source_as_hirepro = models.IntegerField(blank=True, null=True)
    vendor_account_help_desk_email_id = models.CharField(max_length=255, blank=True, null=True)
    campus_hiring_enabled = models.IntegerField(blank=True, null=True)
    resume_stage_settings_for_source_expiry = models.CharField(max_length=255, blank=True, null=True)
    question_reusage_statistics = models.IntegerField(blank=True, null=True)
    default_entity_config = models.CharField(max_length=255, blank=True, null=True)
    is_salary_structure_customizable = models.IntegerField()
    is_campus_candidates_approve_enabled = models.IntegerField()
    date_of_joining_notification_to_business_user = models.TextField(blank=True, null=True)
    is_new_campus_hiring_enabled = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    is_question_approver_flow_enabled = models.IntegerField()
    is_auto_job_tag_employee_referral = models.IntegerField()
    mail_server_user_id = models.CharField(max_length=255, blank=True, null=True)
    offer_mail_onbehalf_of = models.CharField(max_length=255, blank=True, null=True)
    duplication_rule_text = models.TextField(blank=True, null=True)
    duplication_rule_weightage = models.CharField(max_length=200, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'master_configurations'


class MasterJobRequisitionCriterias(models.Model):
    version = models.IntegerField()
    eligibility_criteria_id = models.IntegerField(blank=True, null=True)
    salary_package_id = models.IntegerField(blank=True, null=True)
    campus_id = models.IntegerField(blank=True, null=True)
    campus_group_id = models.IntegerField(blank=True, null=True)
    state_id = models.IntegerField(blank=True, null=True)
    city_id = models.IntegerField(blank=True, null=True)
    venue = models.TextField(blank=True, null=True)
    recruit_event_id = models.IntegerField(blank=True, null=True)
    ec_positive_status_id = models.IntegerField(blank=True, null=True)
    ec_negetive_status_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    masterjobrequisition = models.ForeignKey('MasterJobRequisitions', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_job_requisition_criterias'


class MasterJobRequisitions(models.Model):
    version = models.IntegerField()
    location_id = models.IntegerField(blank=True, null=True)
    business_unit_id = models.IntegerField(blank=True, null=True)
    hiring_manager_id = models.IntegerField(blank=True, null=True)
    no_of_males = models.IntegerField(blank=True, null=True)
    no_of_females = models.IntegerField(blank=True, null=True)
    no_of_openings = models.IntegerField(blank=True, null=True)
    year_of_passing_from = models.IntegerField(blank=True, null=True)
    year_of_passing_to = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    job = models.ForeignKey(Jobs, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'master_job_requisitions'


class MasterJobs(models.Model):
    version = models.IntegerField()
    name = models.CharField(max_length=255, blank=True, null=True)
    year_of_passing_from = models.IntegerField(blank=True, null=True)
    year_of_passing_to = models.IntegerField(blank=True, null=True)
    is_utilized_in_event = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    master_job_status = models.IntegerField(blank=True, null=True)
    true_false2 = models.IntegerField(blank=True, null=True)
    true_false1 = models.IntegerField(blank=True, null=True)
    integer5 = models.IntegerField(blank=True, null=True)
    integer4 = models.IntegerField(blank=True, null=True)
    integer3 = models.IntegerField(blank=True, null=True)
    integer2 = models.IntegerField(blank=True, null=True)
    integer1 = models.IntegerField(blank=True, null=True)
    text5 = models.CharField(max_length=50, blank=True, null=True)
    text4 = models.CharField(max_length=50, blank=True, null=True)
    text3 = models.CharField(max_length=50, blank=True, null=True)
    text2 = models.CharField(max_length=50, blank=True, null=True)
    text1 = models.CharField(max_length=50, blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'master_jobs'


class MasterReports(models.Model):
    version = models.IntegerField()
    job_id = models.IntegerField(blank=True, null=True)
    job_name = models.CharField(max_length=255, blank=True, null=True)
    job_code_id = models.IntegerField(blank=True, null=True)
    position_code = models.CharField(max_length=255, blank=True, null=True)
    business_unit_id = models.IntegerField(blank=True, null=True)
    sub_business_unit_id = models.IntegerField(blank=True, null=True)
    hiring_manager_id = models.IntegerField(blank=True, null=True)
    request_date = models.DateTimeField(blank=True, null=True)
    project_start_date = models.DateTimeField(blank=True, null=True)
    offer_date = models.DateTimeField(blank=True, null=True)
    joining_date = models.DateTimeField(blank=True, null=True)
    comment = models.CharField(max_length=255, blank=True, null=True)
    ageing = models.IntegerField(blank=True, null=True)
    tareaction_time = models.IntegerField(blank=True, null=True)
    request_to_selected_tat = models.IntegerField(blank=True, null=True)
    selected_to_joining_tat = models.IntegerField(blank=True, null=True)
    request_to_joined_tat = models.IntegerField(blank=True, null=True)
    req_cancelled_or_on_hold_date = models.DateTimeField(blank=True, null=True)
    ageing_request_to_drop_date = models.IntegerField(blank=True, null=True)
    job_code_text = models.CharField(max_length=255, blank=True, null=True)
    business_unit_text = models.CharField(max_length=255, blank=True, null=True)
    sub_business_unit_text = models.CharField(max_length=255, blank=True, null=True)
    hiring_manager_text = models.CharField(max_length=255, blank=True, null=True)
    position_status_id = models.IntegerField(blank=True, null=True)
    position_status_text = models.CharField(max_length=255, blank=True, null=True)
    offer_accepted_date = models.DateTimeField(blank=True, null=True)
    planned_date_of_joining = models.DateTimeField(blank=True, null=True)
    candidate_id = models.IntegerField(blank=True, null=True)
    candidate_name = models.CharField(max_length=255, blank=True, null=True)
    job_status = models.CharField(max_length=255, blank=True, null=True)
    job_text1 = models.CharField(max_length=255, blank=True, null=True)
    job_text2 = models.CharField(max_length=255, blank=True, null=True)
    job_text3 = models.CharField(max_length=255, blank=True, null=True)
    job_text4 = models.CharField(max_length=255, blank=True, null=True)
    job_integer1 = models.IntegerField(blank=True, null=True)
    job_integer2 = models.IntegerField(blank=True, null=True)
    skill_category = models.CharField(max_length=255, blank=True, null=True)
    offer_pending_date = models.DateTimeField(blank=True, null=True)
    position_closed_date = models.DateTimeField(blank=True, null=True)
    priority = models.CharField(max_length=255, blank=True, null=True)
    source = models.CharField(max_length=255, blank=True, null=True)
    source_type = models.IntegerField(blank=True, null=True)
    matching_to_offer_pending_tat = models.IntegerField(blank=True, null=True)
    offer_pending_to_fitment_approved_tat = models.IntegerField(blank=True, null=True)
    offer_pending_to_selected_tat = models.IntegerField(blank=True, null=True)
    recruiter_name = models.CharField(max_length=255, blank=True, null=True)
    job_date_custom_field1 = models.DateTimeField(blank=True, null=True)
    job_date_custom_field2 = models.DateTimeField(blank=True, null=True)
    candidate_text1 = models.CharField(max_length=255, blank=True, null=True)
    candidate_text2 = models.CharField(max_length=255, blank=True, null=True)
    candidate_text3 = models.CharField(max_length=255, blank=True, null=True)
    candidate_text4 = models.CharField(max_length=255, blank=True, null=True)
    candidate_integer1 = models.IntegerField(blank=True, null=True)
    candidate_integer2 = models.IntegerField(blank=True, null=True)
    heads_up_position = models.IntegerField()
    original_requisition_id = models.IntegerField(blank=True, null=True)
    part_time_job = models.IntegerField()
    cost_centre = models.CharField(max_length=255, blank=True, null=True)
    replacement = models.CharField(max_length=255, blank=True, null=True)
    position_type = models.IntegerField(blank=True, null=True)
    request_to_selected_delay = models.IntegerField(blank=True, null=True)
    selected_to_joining_delay = models.IntegerField(blank=True, null=True)
    request_to_joined_delay = models.IntegerField(blank=True, null=True)
    matching_to_offer_pending_delay = models.IntegerField(blank=True, null=True)
    offer_pending_to_fitment_approved_delay = models.IntegerField(blank=True, null=True)
    offer_pending_to_selected_delay = models.IntegerField(blank=True, null=True)
    position_id = models.IntegerField(blank=True, null=True)
    aging_delay = models.IntegerField(blank=True, null=True)
    tareaction_time_delay = models.IntegerField(blank=True, null=True)
    aging_request_to_drop_date_delay = models.IntegerField(blank=True, null=True)
    job_text5 = models.CharField(max_length=255, blank=True, null=True)
    job_integer3 = models.IntegerField(blank=True, null=True)
    job_integer4 = models.IntegerField(blank=True, null=True)
    job_integer5 = models.IntegerField(blank=True, null=True)
    candidate_text5 = models.CharField(max_length=255, blank=True, null=True)
    candidate_integer3 = models.IntegerField(blank=True, null=True)
    candidate_integer4 = models.IntegerField(blank=True, null=True)
    candidate_integer5 = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'master_reports'


class MenuItems(models.Model):
    version = models.IntegerField()
    menu_name = models.CharField(max_length=255, blank=True, null=True)
    url = models.CharField(max_length=255, blank=True, null=True)
    module_id = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'menu_items'


class MessangerItems(models.Model):
    version = models.IntegerField()
    message = models.TextField(blank=True, null=True)
    no_of_attachments = models.IntegerField(blank=True, null=True)
    contact_id = models.IntegerField(blank=True, null=True)
    contact_type = models.CharField(max_length=255, blank=True, null=True)
    is_read = models.IntegerField(blank=True, null=True)
    subject = models.CharField(max_length=250, blank=True, null=True)
    to_collection = models.TextField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    messangeritem = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'messanger_items'


class Mifreports(models.Model):
    version = models.IntegerField()
    candidate_id = models.IntegerField(blank=True, null=True)
    candidate_name = models.CharField(max_length=255, blank=True, null=True)
    job_id = models.IntegerField(blank=True, null=True)
    job_name = models.CharField(max_length=255, blank=True, null=True)
    grade = models.CharField(max_length=255, blank=True, null=True)
    process = models.CharField(max_length=255, blank=True, null=True)
    phone = models.CharField(max_length=255, blank=True, null=True)
    mobile = models.CharField(max_length=255, blank=True, null=True)
    email = models.CharField(max_length=255, blank=True, null=True)
    alternate_email = models.CharField(max_length=255, blank=True, null=True)
    degree_text = models.CharField(max_length=255, blank=True, null=True)
    highest_qualification = models.CharField(max_length=255, blank=True, null=True)
    degree_type_text = models.CharField(max_length=255, blank=True, null=True)
    stream = models.CharField(max_length=255, blank=True, null=True)
    year_of_passing = models.CharField(max_length=255, blank=True, null=True)
    percentage_of_cgpa = models.FloatField(blank=True, null=True)
    date_of_birth = models.DateTimeField(blank=True, null=True)
    candidate_created_on = models.DateTimeField(blank=True, null=True)
    source_type = models.IntegerField(blank=True, null=True)
    source = models.CharField(max_length=255, blank=True, null=True)
    stages = models.CharField(max_length=255, blank=True, null=True)
    scores = models.CharField(max_length=255, blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'mifreports'


class ModuleBillingPrices(models.Model):
    version = models.IntegerField()
    module_id = models.IntegerField()
    price = models.BigIntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'module_billing_prices'


class ModuleGridConfigurations(models.Model):
    version = models.IntegerField()
    module = models.IntegerField(blank=True, null=True)
    grid_method_name = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'module_grid_configurations'


class ModuleGridEnabledPropertys(models.Model):
    grid_property = models.CharField(max_length=255, blank=True, null=True)
    property_order = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    modulegridconfiguration = models.ForeignKey(ModuleGridConfigurations, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'module_grid_enabled_propertys'


class Modules(models.Model):
    version = models.IntegerField()
    module_name = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    url = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'modules'


class MonthlyEffortPipeLineReports(models.Model):
    version = models.IntegerField()
    job_id = models.IntegerField(blank=True, null=True)
    job_name = models.CharField(max_length=255, blank=True, null=True)
    source_id = models.IntegerField(blank=True, null=True)
    source_name = models.CharField(max_length=255, blank=True, null=True)
    month = models.IntegerField(blank=True, null=True)
    year = models.IntegerField(blank=True, null=True)
    total_cv_sourced = models.IntegerField(blank=True, null=True)
    number_of_first_level_interview = models.IntegerField(blank=True, null=True)
    number_of_first_level_shortlisted = models.IntegerField(blank=True, null=True)
    number_of_final_round_interviews = models.IntegerField(blank=True, null=True)
    number_of_final_round_shortlisted = models.IntegerField(blank=True, null=True)
    number_of_no_shows = models.IntegerField(blank=True, null=True)
    number_of_offer_released = models.IntegerField(blank=True, null=True)
    number_of_offer_accepted = models.IntegerField(blank=True, null=True)
    number_of_joinees = models.IntegerField(blank=True, null=True)
    business_unit_id = models.IntegerField(blank=True, null=True)
    type_of_source = models.IntegerField(blank=True, null=True)
    hirepro_source_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'monthly_effort_pipe_line_reports'


class NonAcademics(models.Model):
    nacategory_id = models.IntegerField(blank=True, null=True)
    nacategory_value_id = models.IntegerField(blank=True, null=True)
    num_of_hiring = models.IntegerField(blank=True, null=True)
    comment = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    eligibilitycriteria = models.ForeignKey(EligibilityCriterias, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'non_academics'


class NonComplianceCandidatess(models.Model):
    candidate_id = models.IntegerField(blank=True, null=True)
    candidate_name = models.CharField(max_length=255, blank=True, null=True)
    actual_time = models.IntegerField(blank=True, null=True)
    user_name = models.CharField(max_length=255, blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    time_exceed = models.IntegerField(blank=True, null=True)
    compliance_date = models.DateTimeField(blank=True, null=True)
    source_id = models.IntegerField(blank=True, null=True)
    type_of_source = models.IntegerField(blank=True, null=True)
    is_active_non_compliance = models.IntegerField(blank=True, null=True)
    source_name = models.CharField(max_length=255, blank=True, null=True)
    applicant_status_date = models.DateTimeField(blank=True, null=True)
    location_id = models.IntegerField(blank=True, null=True)
    location_text = models.CharField(max_length=255, blank=True, null=True)
    contact_number = models.CharField(max_length=255, blank=True, null=True)
    office_number = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    noncompliancereportoutput = models.ForeignKey('NonComplianceReportOutputs', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'non_compliance_candidatess'


class NonComplianceReportOutputs(models.Model):
    version = models.IntegerField()
    job_id = models.IntegerField(blank=True, null=True)
    job_name = models.CharField(max_length=255, blank=True, null=True)
    job_primary_owner_id = models.IntegerField(blank=True, null=True)
    job_primary_owner_name = models.CharField(max_length=255, blank=True, null=True)
    compliance_id = models.IntegerField(blank=True, null=True)
    count = models.IntegerField(blank=True, null=True)
    job_code_id = models.IntegerField(blank=True, null=True)
    job_code_name = models.CharField(max_length=255, blank=True, null=True)
    hiring_manager_id = models.IntegerField(blank=True, null=True)
    hiring_manager_name = models.CharField(max_length=255, blank=True, null=True)
    unit_id = models.IntegerField(blank=True, null=True)
    unit_name = models.CharField(max_length=255, blank=True, null=True)
    job_location = models.IntegerField(blank=True, null=True)
    job_location_text = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'non_compliance_report_outputs'


class NotificationActionRoles(models.Model):
    version = models.IntegerField()
    user_role_value_id = models.IntegerField(blank=True, null=True)
    user_role_value_text = models.CharField(max_length=255, blank=True, null=True)
    action_value_id = models.IntegerField(blank=True, null=True)
    action_value_text = models.CharField(max_length=255, blank=True, null=True)
    entity_type = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'notification_action_roles'


class NotificationConfigurations(models.Model):
    version = models.IntegerField()
    notification_id = models.IntegerField(blank=True, null=True)
    notification_target = models.IntegerField(blank=True, null=True)
    notification_type = models.IntegerField(blank=True, null=True)
    is_enabled = models.IntegerField()
    mail_watcher = models.CharField(max_length=255, blank=True, null=True)
    sms_watcher = models.CharField(max_length=255, blank=True, null=True)
    is_system_notification = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'notification_configurations'


class NotificationRecepients(models.Model):
    version = models.IntegerField()
    recepient_name = models.CharField(max_length=255, blank=True, null=True)
    recepient_email = models.CharField(max_length=255, blank=True, null=True)
    contact_id = models.IntegerField(blank=True, null=True)
    contact_type = models.IntegerField(blank=True, null=True)
    is_ignored = models.IntegerField()
    is_sms_notification = models.IntegerField(blank=True, null=True)
    mobile_number = models.TextField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    notificationscheme = models.ForeignKey('NotificationSchemes', blank=True, null=True)
    notificationactionrole = models.ForeignKey(NotificationActionRoles, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'notification_recepients'


class NotificationSchemes(models.Model):
    version = models.IntegerField()
    notification_scheme_name = models.CharField(max_length=255, blank=True, null=True)
    is_enabled = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'notification_schemes'


class OfferApprovalLevels(models.Model):
    version = models.IntegerField()
    name = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    approver_user_id = models.IntegerField()
    approval_sequence = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'offer_approval_levels'


class OfferApprovers(models.Model):
    is_approved = models.IntegerField()
    user_id = models.IntegerField()
    approver_level_id = models.IntegerField()
    offer_approver_status = models.IntegerField(blank=True, null=True)
    comment = models.CharField(max_length=255, blank=True, null=True)
    is_current_approver = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    offer = models.ForeignKey('Offers', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'offer_approvers'


class OfferBillingHistorys(models.Model):
    status = models.IntegerField()
    comment = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    offer = models.ForeignKey('Offers', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'offer_billing_historys'


class OfferEvents(models.Model):
    version = models.IntegerField()
    subject = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    job_id = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    event_type = models.IntegerField(blank=True, null=True)
    offer_id = models.IntegerField(blank=True, null=True)
    candidate_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'offer_events'


class Offers(models.Model):
    date_of_resignation = models.DateTimeField(blank=True, null=True)
    date_of_relieving = models.DateTimeField(blank=True, null=True)
    date_of_joining = models.DateTimeField(blank=True, null=True)
    base_salary = models.CharField(max_length=255, blank=True, null=True)
    bonus = models.CharField(max_length=255, blank=True, null=True)
    benefits = models.CharField(max_length=255, blank=True, null=True)
    stocks = models.CharField(max_length=255, blank=True, null=True)
    reason_of_abort = models.CharField(max_length=255, blank=True, null=True)
    candidate_billing_amount = models.FloatField(blank=True, null=True)
    offered_ctc = models.FloatField()
    planned_date_of_joining = models.DateTimeField(blank=True, null=True)
    joining_location = models.IntegerField(blank=True, null=True)
    level_id = models.IntegerField()
    offer_approval_status = models.IntegerField(blank=True, null=True)
    offer_approval_note = models.TextField(blank=True, null=True)
    offer_approved_date = models.DateTimeField(blank=True, null=True)
    offer_letter_file_id = models.IntegerField(blank=True, null=True)
    basic_salary = models.FloatField()
    no_of_attachments = models.IntegerField(blank=True, null=True)
    vendor_contract_level_id = models.IntegerField(blank=True, null=True)
    vendor_billing_percentage = models.FloatField(blank=True, null=True)
    vendor_billing_amount = models.FloatField(blank=True, null=True)
    vendor_billing_comment = models.CharField(max_length=255, blank=True, null=True)
    ctc = models.CharField(max_length=255, blank=True, null=True)
    candidate_source_id = models.IntegerField(blank=True, null=True)
    type_of_source = models.IntegerField(blank=True, null=True)
    hirepro_billing_percentage = models.FloatField(blank=True, null=True)
    hirepro_billing_amount = models.FloatField(blank=True, null=True)
    hirepro_billing_comment = models.CharField(max_length=255, blank=True, null=True)
    billing_status = models.IntegerField(blank=True, null=True)
    hirepro_contract_level_id = models.IntegerField(blank=True, null=True)
    position_id = models.IntegerField(blank=True, null=True)
    designation_id = models.IntegerField(blank=True, null=True)
    true_false2 = models.IntegerField(blank=True, null=True)
    true_false1 = models.IntegerField(blank=True, null=True)
    integer5 = models.IntegerField(blank=True, null=True)
    integer4 = models.IntegerField(blank=True, null=True)
    integer3 = models.IntegerField(blank=True, null=True)
    integer2 = models.IntegerField(blank=True, null=True)
    integer1 = models.IntegerField(blank=True, null=True)
    text5 = models.CharField(max_length=50, blank=True, null=True)
    text4 = models.CharField(max_length=50, blank=True, null=True)
    text3 = models.CharField(max_length=50, blank=True, null=True)
    text2 = models.CharField(max_length=50, blank=True, null=True)
    text1 = models.CharField(max_length=50, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    salarystructurecustomized = models.ForeignKey('SalaryStructureCustomized', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'offers'


class OnLineUsers(models.Model):
    version = models.IntegerField()
    support_user_id = models.IntegerField(blank=True, null=True)
    last_request_time = models.DateTimeField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'on_line_users'


class OnlineSpecificQuestions(models.Model):
    section_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    testuser = models.ForeignKey('TestUsers', blank=True, null=True)
    question = models.ForeignKey('Questions', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'online_specific_questions'


class OptionalGroupSets(models.Model):
    version = models.IntegerField()
    name = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    questionpaperinfo = models.ForeignKey('QuestionPaperInfos', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'optional_group_sets'


class OptionalGroups(models.Model):
    version = models.IntegerField()
    group_id = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    optionalgroupset = models.ForeignKey(OptionalGroupSets, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'optional_groups'


class OwnerContactDetails(models.Model):
    name = models.CharField(max_length=70, blank=True, null=True)
    title = models.CharField(max_length=50, blank=True, null=True)
    email = models.CharField(max_length=50, blank=True, null=True)
    phone_number = models.CharField(max_length=50, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    job = models.ForeignKey(Jobs, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'owner_contact_details'


class PaperFrameworks(models.Model):
    client_information = models.CharField(max_length=255, blank=True, null=True)
    notes = models.CharField(max_length=255, blank=True, null=True)
    subject = models.CharField(max_length=255, blank=True, null=True)
    max_marks = models.FloatField(blank=True, null=True)
    total_attemt_time = models.IntegerField(blank=True, null=True)
    correct = models.FloatField(blank=True, null=True)
    in_correct = models.FloatField(blank=True, null=True)
    partial_correct = models.FloatField(blank=True, null=True)
    left_entries = models.FloatField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'paper_frameworks'


class PaperSetQuestions(models.Model):
    question_id = models.IntegerField()
    order_id = models.IntegerField()
    section_id = models.IntegerField(blank=True, null=True)
    question_tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    paperset = models.ForeignKey('PaperSets', blank=True, null=True)
    papersetquestion = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'paper_set_questions'


class PaperSets(models.Model):
    version = models.IntegerField()
    set_code = models.CharField(max_length=255, blank=True, null=True)
    no_of_attachments = models.IntegerField()
    set_preview_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    questionpaperinfo = models.ForeignKey('QuestionPaperInfos', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'paper_sets'


class PendingItems(models.Model):
    version = models.IntegerField()
    scheduled_task = models.CharField(max_length=255, blank=True, null=True)
    item_id = models.IntegerField(blank=True, null=True)
    item_type = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'pending_items'


class PersistOfflineXlsDetails(models.Model):
    xls_file_id = models.CharField(max_length=255, blank=True, null=True)
    serialized_offline_xls_data = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'persist_offline_xls_details'


class PhoneCalls(models.Model):
    version = models.IntegerField()
    subject = models.CharField(max_length=255, blank=True, null=True)
    name = models.CharField(max_length=75, blank=True, null=True)
    phone = models.CharField(max_length=20, blank=True, null=True)
    start_time = models.DateTimeField(blank=True, null=True)
    end_time = models.DateTimeField(blank=True, null=True)
    type = models.IntegerField()
    description = models.TextField(blank=True, null=True)
    direction = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    link_to_type = models.CharField(max_length=255, blank=True, null=True)
    link_to_id = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'phone_calls'


class PofuCallHistorys(models.Model):
    status_id = models.IntegerField()
    comment = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    pofucall = models.ForeignKey('PofuCalls', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'pofu_call_historys'


class PofuCalls(models.Model):
    assignee = models.IntegerField()
    activity_id = models.IntegerField()
    current_status_id = models.IntegerField()
    start_time = models.DateTimeField(blank=True, null=True)
    end_time = models.DateTimeField(blank=True, null=True)
    comment = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    pofu = models.ForeignKey('Pofus', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'pofu_calls'


class Pofus(models.Model):
    version = models.IntegerField()
    applicant_status_id = models.IntegerField()
    candidate_pofu_category_id = models.IntegerField()
    call_history = models.TextField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'pofus'


class PortalLoginInfos(models.Model):
    user_id = models.CharField(max_length=60, blank=True, null=True)
    password = models.CharField(max_length=60, blank=True, null=True)
    user_name = models.CharField(max_length=75, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    portal = models.ForeignKey('Portals', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'portal_login_infos'


class Portals(models.Model):
    source = models.ForeignKey('Sources', primary_key=True)
    company_id = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'portals'


class PortedCandidateInfos(models.Model):
    version = models.IntegerField()
    last_ported_id = models.IntegerField()
    last_ported_time = models.DateTimeField(blank=True, null=True)
    candidate_count = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'ported_candidate_infos'


class Presentations(models.Model):
    version = models.IntegerField()
    layout = models.CharField(max_length=255, blank=True, null=True)
    style = models.CharField(max_length=255, blank=True, null=True)
    logo1 = models.CharField(max_length=255, blank=True, null=True)
    logo2 = models.CharField(max_length=255, blank=True, null=True)
    slogan_text = models.CharField(max_length=255, blank=True, null=True)
    slogan_image = models.CharField(max_length=255, blank=True, null=True)
    url = models.CharField(max_length=255, blank=True, null=True)
    background_image = models.CharField(max_length=255, blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'presentations'


class QaPersonnels(models.Model):
    qa_id = models.IntegerField(blank=True, null=True)
    is_qa_completed = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    questionpaperinfo = models.ForeignKey('QuestionPaperInfos', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'qa_personnels'


class QpGroups(models.Model):
    name = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    instruction_text = models.CharField(max_length=255, blank=True, null=True)
    instruction_id = models.IntegerField(blank=True, null=True)
    category_id = models.IntegerField(blank=True, null=True)
    total_questions = models.IntegerField()
    sub_category_id = models.IntegerField(blank=True, null=True)
    foreign_group_id = models.IntegerField(blank=True, null=True)
    group_tenant_id = models.IntegerField(blank=True, null=True)
    question_tenant_type = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    questionpaperinfo = models.ForeignKey('QuestionPaperInfos', blank=True, null=True)
    blueprint = models.ForeignKey(BluePrints, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'qp_groups'


#class QuartzCronTriggers(models.Model):
#    trigger_name = models.ForeignKey('QuartzTriggers', db_column='trigger_name')
#    trigger_group = models.ForeignKey('QuartzTriggers', db_column='trigger_group')
#    cron_expression = models.CharField(max_length=50, blank=True, null=True)
#
#    class Meta:
#        managed = False
#        db_table = 'quartz_cron_triggers'
#        unique_together = (('trigger_name', 'trigger_group'),)


class QuartzJobs(models.Model):
    job_group = models.CharField(max_length=50)
    job_name = models.CharField(max_length=50)
    description = models.TextField(blank=True, null=True)
    job_class_name = models.TextField(blank=True, null=True)
    is_durable = models.IntegerField(blank=True, null=True)
    is_volatile = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'quartz_jobs'
        unique_together = (('job_group', 'job_name'),)


#class QuartzSimpleTriggers(models.Model):
#    trigger_name = models.ForeignKey('QuartzTriggers', db_column='trigger_name')
#    trigger_group = models.ForeignKey('QuartzTriggers', db_column='trigger_group')
#    repeat_count = models.IntegerField(blank=True, null=True)
#    repeat_interval = models.BigIntegerField(blank=True, null=True)
#
#    class Meta:
#        managed = False
#        db_table = 'quartz_simple_triggers'
#        unique_together = (('trigger_name', 'trigger_group'),)


#class QuartzTriggers(models.Model):
#    trigger_name = models.ForeignKey(QuartzJobs, db_column='trigger_name')
#    trigger_group = models.ForeignKey(QuartzJobs, db_column='trigger_group')
#    is_volatile = models.IntegerField(blank=True, null=True)
#    description = models.TextField(blank=True, null=True)
#    next_fire_time = models.DateTimeField(blank=True, null=True)
#    prev_fire_time = models.DateTimeField(blank=True, null=True)
#    priority = models.IntegerField(blank=True, null=True)
#    trigger_state = models.CharField(max_length=50, blank=True, null=True)
#    start_time = models.DateTimeField(blank=True, null=True)
#    end_time = models.DateTimeField(blank=True, null=True)
#    tenant_id = models.IntegerField(blank=True, null=True)
#    job_group = models.ForeignKey(QuartzJobs, db_column='job_group')
#    job_name = models.ForeignKey(QuartzJobs, db_column='job_name')
#
#    class Meta:
#        managed = False
#        db_table = 'quartz_triggers'
#        unique_together = (('trigger_name', 'trigger_group'),)


class QueryCategoryConfigurations(models.Model):
    version = models.IntegerField()
    tenant_id = models.IntegerField()
    category_id = models.IntegerField()
    user_ids = models.CharField(max_length=255, blank=True, null=True)
    department_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'query_category_configurations'


class QuestionApprovers(models.Model):
    question_id = models.IntegerField(blank=True, null=True)
    editor = models.IntegerField(blank=True, null=True)
    edited_date = models.DateTimeField(blank=True, null=True)
    edited_reason = models.CharField(max_length=255, blank=True, null=True)
    approver = models.IntegerField(blank=True, null=True)
    approval_status = models.IntegerField(blank=True, null=True)
    approval_date = models.DateTimeField(blank=True, null=True)
    approver_comment = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    editedquestion = models.ForeignKey(EditedQuestions, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'question_approvers'


class QuestionAttachments(models.Model):
    version = models.IntegerField()
    file_id = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    question = models.ForeignKey('Questions', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'question_attachments'


class QuestionFullTexts(models.Model):
    question_search_full_text = models.TextField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'question_full_texts'


class QuestionNoteAttachments(models.Model):
    version = models.IntegerField()
    file_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    question = models.ForeignKey('Questions', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'question_note_attachments'


class QuestionPaperCaches(models.Model):
    question_paper_id = models.IntegerField(blank=True, null=True)
    question_paper_json = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'question_paper_caches'


class QuestionPaperCompanys(models.Model):
    company_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    questionpaperinfo = models.ForeignKey('QuestionPaperInfos', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'question_paper_companys'


class QuestionPaperInfos(models.Model):
    version = models.IntegerField()
    question_paper_code = models.CharField(max_length=255, blank=True, null=True)
    qp_information = models.CharField(max_length=255, blank=True, null=True)
    question_paper_reuse = models.IntegerField()
    difficulty_level = models.IntegerField(blank=True, null=True)
    question_paper_name = models.CharField(max_length=255, blank=True, null=True)
    total_questions = models.IntegerField(blank=True, null=True)
    is_qa_pending = models.IntegerField()
    is_published = models.IntegerField()
    no_of_attachments = models.IntegerField()
    instruction_id = models.IntegerField(blank=True, null=True)
    tag_assessment_line = models.IntegerField(blank=True, null=True)
    qp_category_id = models.IntegerField(blank=True, null=True)
    status_id = models.IntegerField(blank=True, null=True)
    preview_id = models.IntegerField(blank=True, null=True)
    is_survey_question_paper = models.IntegerField()
    question_randomizing = models.IntegerField()
    is_optional_group = models.IntegerField()
    blue_print_id = models.IntegerField(blank=True, null=True)
    question_paper_info_tenant_id = models.IntegerField(blank=True, null=True)
    foreign_question_paper_info_id = models.IntegerField(blank=True, null=True)
    instruction_text = models.CharField(max_length=255, blank=True, null=True)
    question_paper_type = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    is_edited_blue_print_paper = models.IntegerField()
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'question_paper_infos'


class QuestionPaperInstuctionAttachments(models.Model):
    version = models.IntegerField()
    file_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    questionpaperinfo = models.ForeignKey(QuestionPaperInfos, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'question_paper_instuction_attachments'


class QuestionPaperQuestionInfos(models.Model):
    coding_language_id = models.IntegerField(blank=True, null=True)
    coding_snippet = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    questionpaperquestion = models.ForeignKey('QuestionPaperQuestions', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'question_paper_question_infos'


class QuestionPaperQuestions(models.Model):
    section_id = models.IntegerField(blank=True, null=True)
    question_tenant_id = models.IntegerField(blank=True, null=True)
    question_id = models.IntegerField()
    evalution_method = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    questionpaperinfo = models.ForeignKey(QuestionPaperInfos, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'question_paper_questions'


class QuestionStatisticss(models.Model):
    total_attempt = models.IntegerField()
    correct = models.IntegerField()
    in_correct = models.IntegerField()
    un_attempted = models.IntegerField()
    facility_value = models.FloatField()
    item_difficulty = models.FloatField()
    distractor_index_of_a = models.FloatField()
    distractor_index_of_b = models.FloatField()
    distractor_index_of_c = models.FloatField()
    distractor_index_of_d = models.FloatField()
    exposure_rate = models.IntegerField()
    avg_response_time = models.FloatField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'question_statisticss'


class Questions(models.Model):
    version = models.IntegerField()
    question_type = models.IntegerField(blank=True, null=True)
    sub_categories_id = models.IntegerField(blank=True, null=True)
    difficulty_level = models.IntegerField(blank=True, null=True)
    status_id = models.IntegerField(blank=True, null=True)
    source_id = models.IntegerField(blank=True, null=True)
    question_str = models.CharField(max_length=255, blank=True, null=True)
    question_reuse = models.IntegerField()
    is_qa_pending = models.IntegerField(blank=True, null=True)
    tag_id = models.IntegerField(blank=True, null=True)
    instruction_id = models.IntegerField(blank=True, null=True)
    notes = models.TextField(blank=True, null=True)
    no_of_attachments = models.IntegerField()
    html_string = models.TextField(blank=True, null=True)
    question_label = models.CharField(max_length=255, blank=True, null=True)
    preview_id = models.IntegerField(blank=True, null=True)
    category_id = models.IntegerField(blank=True, null=True)
    is_survey_question = models.IntegerField()
    total_attempt = models.IntegerField()
    correct = models.IntegerField()
    in_correct = models.IntegerField()
    un_attempted = models.IntegerField()
    source_text = models.CharField(max_length=255, blank=True, null=True)
    sub_topic_id = models.IntegerField(blank=True, null=True)
    sub_topic_unit_id = models.IntegerField(blank=True, null=True)
    is_revised = models.IntegerField()
    foreign_question_id = models.IntegerField(blank=True, null=True)
    foreign_tenant_id = models.IntegerField(blank=True, null=True)
    hirepro_question_id = models.IntegerField(blank=True, null=True)
    author = models.IntegerField(blank=True, null=True)
    question_originality = models.IntegerField(blank=True, null=True)
    question_flag = models.IntegerField(blank=True, null=True)
    is_edited_question_exist = models.IntegerField(blank=True, null=True)
    is_approved_edited_question_exist = models.IntegerField(blank=True, null=True)
    question_title = models.CharField(max_length=255, blank=True, null=True)
    memory_limit = models.CharField(max_length=255, blank=True, null=True)
    time_limit = models.CharField(max_length=255, blank=True, null=True)
    code_size = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    question = models.ForeignKey('self', blank=True, null=True)
    questionfulltext = models.ForeignKey(QuestionFullTexts, blank=True, null=True)
    questionstatistics = models.ForeignKey(QuestionStatisticss, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'questions'


class RandomizedQuestions(models.Model):
    version = models.IntegerField()
    question_id = models.IntegerField(blank=True, null=True)
    section_id = models.IntegerField(blank=True, null=True)
    question_tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    testuser = models.ForeignKey('TestUsers', blank=True, null=True)
    randomizedquestion = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'randomized_questions'


class RecruitEventCandidateQnPapers(models.Model):
    qn_paper_id = models.IntegerField(blank=True, null=True)
    qn_paper_code = models.CharField(max_length=255, blank=True, null=True)
    answer_string = models.CharField(max_length=255, blank=True, null=True)
    is_evaluated = models.IntegerField(blank=True, null=True)
    log = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    recruiteventcandidate = models.ForeignKey('RecruitEventCandidates', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'recruit_event_candidate_qn_papers'


class RecruitEventCandidateScores(models.Model):
    category_id = models.IntegerField(blank=True, null=True)
    score = models.FloatField(blank=True, null=True)
    correct = models.IntegerField(blank=True, null=True)
    in_correct = models.IntegerField(blank=True, null=True)
    qn_paper_id = models.IntegerField(blank=True, null=True)
    qn_paper_code = models.CharField(max_length=255, blank=True, null=True)
    log_error = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    recruiteventcandidate = models.ForeignKey('RecruitEventCandidates', blank=True, null=True)
    recruiteventcandidatescore = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'recruit_event_candidate_scores'


class RecruitEventCandidates(models.Model):
    total_score = models.FloatField(blank=True, null=True)
    status = models.IntegerField(blank=True, null=True)
    percentage = models.FloatField(blank=True, null=True)
    candidate_regn_id = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    recruiteventjob = models.ForeignKey('RecruitEventJobs', blank=True, null=True)
    recruitevent = models.ForeignKey('RecruitEvents', blank=True, null=True)
    candidate = models.ForeignKey(Candidates, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'recruit_event_candidates'


class RecruitEventConfigTemps(models.Model):
    version = models.IntegerField()
    requirement_content = models.CharField(max_length=255, blank=True, null=True)
    master_job_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'recruit_event_config_temps'


class RecruitEventJobTests(models.Model):
    job_id = models.IntegerField(blank=True, null=True)
    test_id = models.IntegerField(blank=True, null=True)
    stage_id = models.IntegerField(blank=True, null=True)
    valid_from = models.DateTimeField(blank=True, null=True)
    valid_to = models.DateTimeField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    recruitevent = models.ForeignKey('RecruitEvents', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'recruit_event_job_tests'


class RecruitEventJobs(models.Model):
    assessment_line_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    recruitevent = models.ForeignKey('RecruitEvents', blank=True, null=True)
    job = models.ForeignKey(Jobs, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'recruit_event_jobs'


class RecruitEventOwners(models.Model):
    user_id = models.IntegerField()
    role_id = models.IntegerField(blank=True, null=True)
    types_of_coordinator = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    recruitevent = models.ForeignKey('RecruitEvents', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'recruit_event_owners'


class RecruitEventQnPaperSets(models.Model):
    set_id = models.IntegerField(blank=True, null=True)
    set_code = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    recruiteventqnpaper = models.ForeignKey('RecruitEventQnPapers', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'recruit_event_qn_paper_sets'


class RecruitEventQnPapers(models.Model):
    question_paper_id = models.IntegerField()
    is_qn_paper_set_generated = models.IntegerField()
    is_excel_file_uploaded = models.IntegerField(blank=True, null=True)
    no_of_excel_file_attachments = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    recruiteventjob = models.ForeignKey(RecruitEventJobs, blank=True, null=True)
    paperframework = models.ForeignKey(PaperFrameworks, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'recruit_event_qn_papers'


class RecruitEvents(models.Model):
    version = models.IntegerField()
    name = models.CharField(max_length=255)
    location_id = models.IntegerField(blank=True, null=True)
    date_from = models.DateTimeField(blank=True, null=True)
    date_to = models.DateTimeField(blank=True, null=True)
    status = models.IntegerField()
    primary_owner_id = models.IntegerField()
    location_text = models.CharField(max_length=255, blank=True, null=True)
    no_of_attachments = models.IntegerField(blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    type_of_event = models.IntegerField(blank=True, null=True)
    no_of_participants = models.IntegerField(blank=True, null=True)
    event_code = models.CharField(max_length=255, blank=True, null=True)
    last_cand_regn_no = models.IntegerField(blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    state_id = models.IntegerField(blank=True, null=True)
    test_id = models.IntegerField(blank=True, null=True)
    college_venue_id = models.IntegerField(blank=True, null=True)
    company_name = models.CharField(max_length=255, blank=True, null=True)
    website = models.CharField(max_length=255, blank=True, null=True)
    domain = models.CharField(max_length=255, blank=True, null=True)
    contact_person = models.CharField(max_length=255, blank=True, null=True)
    qualification = models.CharField(max_length=255, blank=True, null=True)
    eligibility = models.CharField(max_length=255, blank=True, null=True)
    expirience = models.CharField(max_length=255, blank=True, null=True)
    job_description = models.CharField(max_length=255, blank=True, null=True)
    is_confidential = models.IntegerField(blank=True, null=True)
    campus_id = models.IntegerField(blank=True, null=True)
    num_of_tentative_hiring = models.IntegerField(blank=True, null=True)
    corporate_date_from = models.DateTimeField(blank=True, null=True)
    corporate_date_to = models.DateTimeField(blank=True, null=True)
    corporate_description = models.CharField(max_length=255, blank=True, null=True)
    campus_date_from = models.DateTimeField(blank=True, null=True)
    campus_date_to = models.DateTimeField(blank=True, null=True)
    campus_description = models.CharField(max_length=255, blank=True, null=True)
    is_utilized = models.IntegerField()
    anchor_text = models.TextField(blank=True, null=True)
    college_text = models.TextField(blank=True, null=True)
    no_of_jobs = models.IntegerField()
    no_of_tests = models.IntegerField()
    master_job_id = models.IntegerField(blank=True, null=True)
    is_tpo_enabled = models.IntegerField()
    is_auto_checked_ec = models.IntegerField()
    is_status_notification = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    job = models.ForeignKey(Jobs, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'recruit_events'


class RecruitmentTips(models.Model):
    version = models.IntegerField()
    tip = models.TextField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'recruitment_tips'


class Recurrences(models.Model):
    version = models.IntegerField()
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    recurrence_interval = models.IntegerField()
    month_of_year = models.IntegerField()
    occurrences = models.IntegerField(blank=True, null=True)
    pattern_end_date = models.DateTimeField(blank=True, null=True)
    pattern_start_date = models.DateTimeField()
    recurrence_mode = models.IntegerField()
    regenerate = models.IntegerField(blank=True, null=True)
    recurrence_end_mode = models.IntegerField()
    day_of_month = models.IntegerField(blank=True, null=True)
    activity_item_id = models.IntegerField(blank=True, null=True)
    activity_item_type = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'recurrences'


class ReferralCollections(models.Model):
    candidate_name = models.CharField(max_length=255, blank=True, null=True)
    candidate_email1 = models.CharField(max_length=255, blank=True, null=True)
    candidate_contact_number = models.CharField(max_length=255, blank=True, null=True)
    candidate_experience = models.IntegerField()
    file_id = models.IntegerField()
    resume_expiry_date = models.DateTimeField(blank=True, null=True)
    qastatus = models.IntegerField(blank=True, null=True)
    approved_candidate_id = models.IntegerField(blank=True, null=True)
    candidate_current_employer_text = models.CharField(max_length=255, blank=True, null=True)
    candidate_current_employer_id = models.IntegerField(blank=True, null=True)
    candidate_current_location_id = models.IntegerField(blank=True, null=True)
    candidate_current_location_text = models.CharField(max_length=255, blank=True, null=True)
    is_lead = models.IntegerField()
    is_name_show = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    referral = models.ForeignKey('Referrals', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'referral_collections'


class Referrals(models.Model):
    source = models.ForeignKey('Sources', primary_key=True)
    net_brownie_points = models.IntegerField()
    referral_contact_type = models.CharField(max_length=255, blank=True, null=True)
    referral_contact_id = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'referrals'


class Reminders(models.Model):
    version = models.IntegerField()
    reminder_time = models.DateTimeField()
    user_id = models.IntegerField()
    reminder_minutes_before_start = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    activityevent = models.ForeignKey(ActivityEvents, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'reminders'


class ReportDefinitions(models.Model):
    version = models.IntegerField()
    report_name = models.CharField(max_length=255, blank=True, null=True)
    is_cv_utilization_required = models.IntegerField()
    is_pre_defined_sla_required = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'report_definitions'


class ReportOutputs(models.Model):
    job_id = models.IntegerField(blank=True, null=True)
    count = models.FloatField(blank=True, null=True)
    definition_id = models.IntegerField()
    status_type = models.IntegerField(blank=True, null=True)
    report_version = models.IntegerField(blank=True, null=True)
    ratio_text = models.CharField(max_length=255, blank=True, null=True)
    job_code_name = models.CharField(max_length=255, blank=True, null=True)
    job_open_date = models.DateTimeField(blank=True, null=True)
    generated_on = models.DateTimeField(blank=True, null=True)
    hiring_manger_id = models.IntegerField(blank=True, null=True)
    hiring_manager = models.CharField(max_length=255, blank=True, null=True)
    is_deleted_or_archived_job = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'report_outputs'


class ReportStatusDefinitions(models.Model):
    definition_id = models.IntegerField(blank=True, null=True)
    status_type = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    reportdefinition = models.ForeignKey(ReportDefinitions, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'report_status_definitions'


class ResumeSourcesValues(models.Model):
    version = models.IntegerField()
    mac_number = models.CharField(max_length=25, blank=True, null=True)
    source_detail = models.TextField(blank=True, null=True)
    source_name = models.CharField(max_length=255, blank=True, null=True)
    resume_source_master_id = models.IntegerField()
    last_processed_time = models.DateTimeField(blank=True, null=True)
    source_id = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'resume_sources_values'


class ResumeStatuss(models.Model):
    version = models.IntegerField()
    sequence = models.IntegerField()
    base_name = models.CharField(max_length=255)
    label = models.CharField(max_length=255, blank=True, null=True)
    alias = models.CharField(max_length=255, blank=True, null=True)
    is_terminated = models.IntegerField()
    is_base = models.IntegerField()
    hopping_status_id = models.IntegerField(blank=True, null=True)
    is_interview = models.IntegerField(blank=True, null=True)
    is_assessment = models.IntegerField(blank=True, null=True)
    is_staffing = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    resumestatus = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'resume_statuss'


class Roles(models.Model):
    version = models.IntegerField()
    description = models.CharField(max_length=255, blank=True, null=True)
    role_name = models.CharField(max_length=75, blank=True, null=True)
    is_system_role = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'roles'


class RtcRandomizedQuestions(models.Model):
    question_paper_id = models.IntegerField(blank=True, null=True)
    question_id = models.IntegerField(blank=True, null=True)
    number_of_questions_to_display = models.IntegerField(blank=True, null=True)
    mode_of_randomization = models.IntegerField(blank=True, null=True)
    question_tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'rtc_randomized_questions'


class SalaryPackageBranchDegrees(models.Model):
    branch_id = models.IntegerField(blank=True, null=True)
    degree_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    salarypackage = models.ForeignKey('SalaryPackages', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'salary_package_branch_degrees'


class SalaryPackages(models.Model):
    version = models.IntegerField()
    name = models.CharField(max_length=255, blank=True, null=True)
    experience_from = models.IntegerField(blank=True, null=True)
    experience_to = models.IntegerField(blank=True, null=True)
    salary_package_from = models.DecimalField(max_digits=19, decimal_places=5, blank=True, null=True)
    salary_package_to = models.DecimalField(max_digits=19, decimal_places=5, blank=True, null=True)
    fixed_pay_from = models.DecimalField(max_digits=19, decimal_places=5, blank=True, null=True)
    fixed_pay_to = models.DecimalField(max_digits=19, decimal_places=5, blank=True, null=True)
    variable_pay_from = models.DecimalField(max_digits=19, decimal_places=5, blank=True, null=True)
    variable_pay_to = models.DecimalField(max_digits=19, decimal_places=5, blank=True, null=True)
    joining_bonus_from = models.DecimalField(max_digits=19, decimal_places=5, blank=True, null=True)
    joining_bonus_to = models.DecimalField(max_digits=19, decimal_places=5, blank=True, null=True)
    benefits_from = models.DecimalField(max_digits=19, decimal_places=5, blank=True, null=True)
    benefits_to = models.DecimalField(max_digits=19, decimal_places=5, blank=True, null=True)
    gross_pay_from = models.DecimalField(max_digits=19, decimal_places=5, blank=True, null=True)
    gross_pay_to = models.DecimalField(max_digits=19, decimal_places=5, blank=True, null=True)
    insurance = models.DecimalField(max_digits=19, decimal_places=5, blank=True, null=True)
    is_utilized = models.IntegerField()
    stock = models.IntegerField(blank=True, null=True)
    currency = models.CharField(max_length=15, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'salary_packages'


class SalaryStructureCustomized(models.Model):
    provident_fund_percent_amount = models.FloatField(blank=True, null=True)
    super_annuation_fund_percent_amount = models.FloatField(blank=True, null=True)
    hra_percent_amount = models.FloatField()
    custom_field_a2_percent_amount = models.FloatField(blank=True, null=True)
    component_ain_percent_amount = models.FloatField(blank=True, null=True)
    component_bin_percent_amount = models.FloatField(blank=True, null=True)
    custom_field_a1_percent_amount = models.FloatField(blank=True, null=True)
    custom_field_a3_flat = models.FloatField(blank=True, null=True)
    custom_field_a4_flat = models.FloatField(blank=True, null=True)
    custom_field_a5_flat = models.FloatField(blank=True, null=True)
    custom_field_b1_percent_amount = models.FloatField(blank=True, null=True)
    custom_field_b2_percent_amount = models.FloatField(blank=True, null=True)
    custom_field_b3_flat = models.FloatField(blank=True, null=True)
    custom_field_b4_flat = models.FloatField(blank=True, null=True)
    custom_field_b5_flat = models.FloatField(blank=True, null=True)
    custom_field_a6_percent_amount = models.FloatField(blank=True, null=True)
    custom_field_a7_percent_amount = models.FloatField(blank=True, null=True)
    custom_field_a8_flat = models.FloatField(blank=True, null=True)
    custom_field_a9_flat = models.FloatField(blank=True, null=True)
    custom_field_a10_flat = models.FloatField(blank=True, null=True)
    custom_field_a11_flat = models.FloatField(blank=True, null=True)
    custom_field_a12_flat = models.FloatField(blank=True, null=True)
    custom_field_a13_flat = models.FloatField(blank=True, null=True)
    custom_field_a14_flat = models.FloatField(blank=True, null=True)
    custom_field_b6_flat = models.FloatField(blank=True, null=True)
    custom_field_b7_flat = models.FloatField(blank=True, null=True)
    basic_salary_percent_amount = models.FloatField()
    ctc_structure_id = models.IntegerField(blank=True, null=True)
    component_clabel = models.CharField(max_length=255, blank=True, null=True)
    component_dlabel = models.CharField(max_length=255, blank=True, null=True)
    component_cmonthly = models.FloatField(blank=True, null=True)
    component_dmonthly = models.FloatField(blank=True, null=True)
    component_cyearly = models.FloatField(blank=True, null=True)
    component_dyearly = models.FloatField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'salary_structure_customized'


class ScreeningRuleGroupValues(models.Model):
    catalog_or_catalog_group_id = models.IntegerField()
    is_catalog_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    screeningrulegroup = models.ForeignKey('ScreeningRuleGroups', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'screening_rule_group_values'


class ScreeningRuleGroups(models.Model):
    screening_property = models.IntegerField(blank=True, null=True)
    weightage = models.FloatField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    screeningrule = models.ForeignKey('ScreeningRules', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'screening_rule_groups'


class ScreeningRules(models.Model):
    version = models.IntegerField()
    name = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    is_relocate = models.IntegerField(blank=True, null=True)
    relocation_weightage = models.FloatField(blank=True, null=True)
    age_from = models.IntegerField(blank=True, null=True)
    age_to = models.IntegerField(blank=True, null=True)
    age_weightage = models.FloatField(blank=True, null=True)
    experience_from = models.IntegerField(blank=True, null=True)
    experience_to = models.IntegerField(blank=True, null=True)
    experience_weightage = models.FloatField(blank=True, null=True)
    percentage_from = models.FloatField(blank=True, null=True)
    percentage_to = models.FloatField(blank=True, null=True)
    cgpa_from = models.FloatField(blank=True, null=True)
    cgpa_to = models.FloatField(blank=True, null=True)
    percentage_or_cgpa_weightage = models.FloatField(blank=True, null=True)
    gender = models.IntegerField(blank=True, null=True)
    gender_weightage = models.FloatField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'screening_rules'


class SecondaryInterviewers(models.Model):
    interviewer_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    interviewrequest = models.ForeignKey(InterviewRequests, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'secondary_interviewers'


class SectionQuestionDifficultyLevels(models.Model):
    difficult_level = models.IntegerField(blank=True, null=True)
    no_of_questions = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    section = models.ForeignKey('Sections', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'section_question_difficulty_levels'


class Sections(models.Model):
    name = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    instruction_text = models.CharField(max_length=255, blank=True, null=True)
    instruction_id = models.IntegerField(blank=True, null=True)
    sub_category_id = models.IntegerField(blank=True, null=True)
    question_type = models.IntegerField(blank=True, null=True)
    no_of_questions_to_display = models.IntegerField(blank=True, null=True)
    sub_topic_id = models.IntegerField(blank=True, null=True)
    is_revised = models.IntegerField()
    foreign_section_id = models.IntegerField(blank=True, null=True)
    section_tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    qpgroup = models.ForeignKey(QpGroups, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'sections'


class SelectionProcesss(models.Model):
    version = models.IntegerField()
    sequence = models.IntegerField(blank=True, null=True)
    name = models.CharField(max_length=255, blank=True, null=True)
    resume_status_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    selectionprocess = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'selection_processs'


class ServiceEngagements(models.Model):
    engagement_type_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    masterjob = models.ForeignKey(MasterJobs, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'service_engagements'


class ServiceLevelAgrements(models.Model):
    version = models.IntegerField()
    candidate_threshold_status_id = models.IntegerField(blank=True, null=True)
    internal_slavalue = models.IntegerField()
    external_slavalue = models.IntegerField()
    actual_value = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    job = models.ForeignKey(Jobs, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'service_level_agrements'


class SkillsAssesseds(models.Model):
    skill_id = models.IntegerField()
    skill_score = models.IntegerField(blank=True, null=True)
    skill_comment = models.TextField(blank=True, null=True)
    is_applicable = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    interviewfilledfeedbackform = models.ForeignKey(InterviewFilledFeedbackForms, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'skills_assesseds'


class SkillsToAssesss(models.Model):
    skill_id = models.IntegerField()
    skill_max_score = models.IntegerField(blank=True, null=True)
    skill_min_score = models.IntegerField(blank=True, null=True)
    weight = models.FloatField(blank=True, null=True)
    guidelines = models.CharField(max_length=255, blank=True, null=True)
    skill_type_id = models.IntegerField(blank=True, null=True)
    is_comments_required = models.IntegerField()
    is_mandatory = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    assessmenttemplate = models.ForeignKey(AssessmentTemplates, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'skills_to_assesss'


class SlaMetricss(models.Model):
    version = models.IntegerField()
    sla_name = models.CharField(max_length=255, blank=True, null=True)
    numerator_id = models.IntegerField(blank=True, null=True)
    denominator_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'sla_metricss'


class SmsItems(models.Model):
    version = models.IntegerField()
    subject = models.CharField(max_length=255, blank=True, null=True)
    body = models.CharField(max_length=200, blank=True, null=True)
    sender_type = models.IntegerField(blank=True, null=True)
    sender_name = models.CharField(max_length=255, blank=True, null=True)
    sender_mobile_no = models.CharField(max_length=255, blank=True, null=True)
    sent_time = models.DateTimeField(blank=True, null=True)
    recepient_type = models.IntegerField(blank=True, null=True)
    recepient_name = models.CharField(max_length=255, blank=True, null=True)
    recepient_mobile_no = models.CharField(max_length=255, blank=True, null=True)
    received_time = models.DateTimeField(blank=True, null=True)
    size = models.IntegerField(blank=True, null=True)
    message_type = models.IntegerField(blank=True, null=True)
    communication_direction = models.IntegerField(blank=True, null=True)
    sender_email_id = models.CharField(max_length=255, blank=True, null=True)
    sender_id = models.IntegerField(blank=True, null=True)
    recepient_id = models.IntegerField(blank=True, null=True)
    service_provider = models.IntegerField(blank=True, null=True)
    importance = models.IntegerField(blank=True, null=True)
    sensitivity = models.IntegerField(blank=True, null=True)
    sms_status = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'sms_items'


class SmsRequests(models.Model):
    version = models.IntegerField()
    receiver_number = models.CharField(max_length=50, blank=True, null=True)
    message = models.CharField(max_length=255, blank=True, null=True)
    entity_type = models.IntegerField(blank=True, null=True)
    notification_name = models.CharField(max_length=255, blank=True, null=True)
    message_id = models.CharField(max_length=255, blank=True, null=True)
    message_status = models.IntegerField(blank=True, null=True)
    error_status = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'sms_requests'


class SocialSiteOauthInfos(models.Model):
    version = models.IntegerField()
    site_url = models.CharField(max_length=255, blank=True, null=True)
    access_token = models.CharField(max_length=255, blank=True, null=True)
    token_secret = models.CharField(max_length=255, blank=True, null=True)
    varifier = models.CharField(max_length=255, blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'social_site_oauth_infos'


class SourceChangeEvents(models.Model):
    version = models.IntegerField()
    subject = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    candidate_id = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    event_type = models.IntegerField(blank=True, null=True)
    file_id = models.IntegerField(blank=True, null=True)
    file_name = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'source_change_events'


class SourceEvents(models.Model):
    version = models.IntegerField()
    subject = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    link_to_id = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    event_type = models.IntegerField(blank=True, null=True)
    source_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'source_events'


class SourceExtractRules(models.Model):
    version = models.IntegerField()
    email_domain = models.CharField(max_length=255, blank=True, null=True)
    from_email_address = models.CharField(max_length=255, blank=True, null=True)
    to_email_address = models.CharField(max_length=255, blank=True, null=True)
    source_id = models.IntegerField()
    is_job_tagging_enabled = models.IntegerField()
    is_list_tagging_enabled = models.IntegerField()
    type_of_source = models.IntegerField(blank=True, null=True)
    rule_priority = models.IntegerField()
    search_key_word = models.CharField(max_length=255, blank=True, null=True)
    search_location = models.IntegerField(blank=True, null=True)
    is_update_resume = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'source_extract_rules'


class SourceSelfServiceReportOutputs(models.Model):
    version = models.IntegerField()
    job_id = models.IntegerField()
    source_id = models.IntegerField()
    job_name = models.CharField(max_length=255, blank=True, null=True)
    experience_range = models.CharField(max_length=255, blank=True, null=True)
    published_date = models.DateTimeField(blank=True, null=True)
    expiry_date = models.DateTimeField(blank=True, null=True)
    total_submittals = models.IntegerField()
    matching = models.IntegerField()
    in_process = models.IntegerField()
    rejected = models.IntegerField()
    selected = models.IntegerField()
    on_hold = models.IntegerField()
    joined = models.IntegerField()
    is_job_closed = models.IntegerField()
    company_id = models.IntegerField(blank=True, null=True)
    job_code_id = models.IntegerField(blank=True, null=True)
    job_code_text = models.CharField(max_length=255, blank=True, null=True)
    job_title = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'source_self_service_report_outputs'


class SourceUsers(models.Model):
    version = models.IntegerField()
    source_id = models.IntegerField()
    user_id = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'source_users'


class Sources(models.Model):
    version = models.IntegerField()
    source_name = models.CharField(max_length=75, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    site_url = models.CharField(max_length=30, blank=True, null=True)
    types_of_source = models.IntegerField(blank=True, null=True)
    no_of_attachments = models.IntegerField()
    email1 = models.CharField(max_length=60, blank=True, null=True)
    address1 = models.TextField(blank=True, null=True)
    country_code = models.CharField(max_length=40, blank=True, null=True)
    mobile1 = models.CharField(max_length=40, blank=True, null=True)
    phone_office = models.CharField(max_length=40, blank=True, null=True)
    is_extractor_listener_required = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    color_code = models.CharField(max_length=255, blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    contract = models.ForeignKey(Contracts, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'sources'


class StaffingActivityAssigningRules(models.Model):
    version = models.IntegerField()
    activity_id = models.IntegerField(blank=True, null=True)
    sequence = models.IntegerField(blank=True, null=True)
    bu_id = models.IntegerField(blank=True, null=True)
    role_id = models.IntegerField(blank=True, null=True)
    level_id = models.IntegerField(blank=True, null=True)
    privilege = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'staffing_activity_assigning_rules'


class StaffingActivitys(models.Model):
    version = models.IntegerField()
    name = models.CharField(max_length=255, blank=True, null=True)
    duration = models.IntegerField(blank=True, null=True)
    owner = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    category = models.IntegerField(blank=True, null=True)
    hirepro_activity_id = models.IntegerField(blank=True, null=True)
    is_calls_required = models.IntegerField(blank=True, null=True)
    is_sequenced = models.IntegerField(blank=True, null=True)
    is_system_activity = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'staffing_activitys'


class StaffingAutomationRules(models.Model):
    version = models.IntegerField()
    tag_candidate_to_activity = models.IntegerField(blank=True, null=True)
    tag_activity_task_to_candidate = models.IntegerField(blank=True, null=True)
    move_candidate_to_next_activity = models.IntegerField(blank=True, null=True)
    send_credentials_to_candidate = models.IntegerField(blank=True, null=True)
    send_welcome_mail_to_candidate = models.IntegerField(blank=True, null=True)
    tag_content_to_candidate = models.IntegerField(blank=True, null=True)
    enable_activity_rule_engine = models.IntegerField(blank=True, null=True)
    enable_task_rule_engine = models.IntegerField(blank=True, null=True)
    enable_content_rule_engine = models.IntegerField(blank=True, null=True)
    complete_activity_on_complete_all_tasks = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'staffing_automation_rules'


class StaffingGroupMembers(models.Model):
    candidate_id = models.IntegerField(blank=True, null=True)
    staffinggroup = models.ForeignKey('StaffingGroups', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'staffing_group_members'


class StaffingGroups(models.Model):
    version = models.IntegerField()
    name = models.CharField(max_length=255, blank=True, null=True)
    total_members = models.IntegerField(blank=True, null=True)
    status = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'staffing_groups'


class StaffingPofuCallHistorys(models.Model):
    status_id = models.IntegerField()
    comment = models.CharField(max_length=255, blank=True, null=True)
    duration = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    staffingpofucall = models.ForeignKey('StaffingPofuCalls', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'staffing_pofu_call_historys'


class StaffingPofuCalls(models.Model):
    caller = models.IntegerField(blank=True, null=True)
    call_type = models.IntegerField(blank=True, null=True)
    current_status_id = models.IntegerField(blank=True, null=True)
    remarks_id = models.IntegerField(blank=True, null=True)
    start_time = models.DateTimeField(blank=True, null=True)
    end_time = models.DateTimeField(blank=True, null=True)
    is_commented = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    staffingpofu = models.ForeignKey('StaffingPofus', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'staffing_pofu_calls'


class StaffingPofus(models.Model):
    version = models.IntegerField()
    candidate_id = models.IntegerField()
    staffing_activity_id = models.IntegerField(blank=True, null=True)
    pofu_category_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'staffing_pofus'


class StaffingStatusHistorys(models.Model):
    status_id = models.IntegerField(blank=True, null=True)
    comments = models.TextField(blank=True, null=True)
    responsiveness = models.IntegerField(blank=True, null=True)
    observations = models.IntegerField(blank=True, null=True)
    resignation_status = models.IntegerField(blank=True, null=True)
    decline_reason = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    staffingstatus = models.ForeignKey('StaffingStatuss', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'staffing_status_historys'


class StaffingStatuss(models.Model):
    version = models.IntegerField()
    current_status_id = models.IntegerField()
    responsiveness = models.IntegerField(blank=True, null=True)
    observations = models.IntegerField(blank=True, null=True)
    resignation_status = models.IntegerField(blank=True, null=True)
    decline_reason = models.IntegerField(blank=True, null=True)
    comments = models.TextField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    candidate_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'staffing_statuss'


class StaffingTasks(models.Model):
    version = models.IntegerField()
    name = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    assignee_department = models.IntegerField(blank=True, null=True)
    reporter_department = models.IntegerField(blank=True, null=True)
    approver_department = models.IntegerField(blank=True, null=True)
    assignee_group = models.IntegerField(blank=True, null=True)
    reporter_group = models.IntegerField(blank=True, null=True)
    approver_group = models.IntegerField(blank=True, null=True)
    duration = models.IntegerField(blank=True, null=True)
    form_id = models.IntegerField(blank=True, null=True)
    is_visible_to_candidate = models.IntegerField(blank=True, null=True)
    is_auto_approved = models.IntegerField(blank=True, null=True)
    category = models.IntegerField(blank=True, null=True)
    hirepro_task_id = models.IntegerField(blank=True, null=True)
    is_system_task = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'staffing_tasks'


class StaffingUserProfiles(models.Model):
    version = models.IntegerField()
    candidate_id = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    linked_in_url = models.CharField(max_length=255, blank=True, null=True)
    facebook = models.CharField(max_length=255, blank=True, null=True)
    twitter = models.CharField(max_length=255, blank=True, null=True)
    photo_path = models.CharField(max_length=255, blank=True, null=True)
    website = models.CharField(max_length=255, blank=True, null=True)
    about = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'staffing_user_profiles'


class SyncMailAccounts(models.Model):
    version = models.IntegerField()
    email = models.CharField(max_length=255, blank=True, null=True)
    password = models.CharField(max_length=255, blank=True, null=True)
    mail_server = models.CharField(max_length=255, blank=True, null=True)
    port = models.IntegerField()
    is_mail_sync_enabled = models.IntegerField()
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    mailvalidator = models.ForeignKey(MailValidators, blank=True, null=True)
    syncmailaction = models.ForeignKey('SyncMailActions', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'sync_mail_accounts'


class SyncMailActions(models.Model):
    action_on_mail = models.IntegerField(blank=True, null=True)
    source_type_to_tag = models.IntegerField(blank=True, null=True)
    source_id_to_tag = models.IntegerField(blank=True, null=True)
    get_source_from = models.IntegerField(blank=True, null=True)
    job_id_to_tag = models.IntegerField(blank=True, null=True)
    list_id_to_tag = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'sync_mail_actions'


class TableInfos(models.Model):
    table_name = models.CharField(primary_key=True, max_length=255)
    table_rows = models.IntegerField(blank=True, null=True)
    reserved = models.CharField(max_length=255, blank=True, null=True)
    table_data = models.CharField(max_length=255, blank=True, null=True)
    index_size = models.CharField(max_length=255, blank=True, null=True)
    unused = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'table_infos'


class TagItems(models.Model):
    item_name = models.CharField(max_length=100, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    tag = models.ForeignKey('Tags', blank=True, null=True)
    item_type = models.CharField(max_length=255, blank=True, null=True)
    item_id = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tag_items'


class Tags(models.Model):
    version = models.IntegerField()
    tag_name = models.CharField(max_length=50, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'tags'


class TaskConfigurations(models.Model):
    version = models.IntegerField()
    task_id = models.IntegerField(blank=True, null=True)
    bu_id = models.IntegerField(blank=True, null=True)
    role_id = models.IntegerField(blank=True, null=True)
    level_id = models.IntegerField(blank=True, null=True)
    privilege = models.IntegerField(blank=True, null=True)
    activity_id = models.IntegerField(blank=True, null=True)
    job_role_id = models.IntegerField(blank=True, null=True)
    recruit_event_id = models.IntegerField(blank=True, null=True)
    stage_id = models.IntegerField(blank=True, null=True)
    status_id = models.IntegerField(blank=True, null=True)
    hard_limit_status_id = models.IntegerField(blank=True, null=True)
    hard_limit_stage_id = models.IntegerField(blank=True, null=True)
    positive_resume_satus_id = models.IntegerField(blank=True, null=True)
    negative_resume_satus_id = models.IntegerField(blank=True, null=True)
    duration = models.CharField(max_length=255, blank=True, null=True)
    sequence = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'task_configurations'


class TaskItems(models.Model):
    version = models.IntegerField()
    subject = models.TextField(blank=True, null=True)
    due_date_time = models.DateTimeField(blank=True, null=True)
    is_reminder_set = models.IntegerField()
    start_date_time = models.DateTimeField(blank=True, null=True)
    status = models.IntegerField()
    owner_email = models.CharField(max_length=60, blank=True, null=True)
    no_of_attachments = models.IntegerField(blank=True, null=True)
    is_read = models.IntegerField()
    percentage_of_work_done = models.IntegerField()
    reminder_minutes_before_start = models.IntegerField()
    to_email_ids = models.TextField(blank=True, null=True)
    is_recurring = models.IntegerField()
    reminder_time = models.DateTimeField(blank=True, null=True)
    owner_contact_id = models.IntegerField(blank=True, null=True)
    owner_contact_type = models.CharField(max_length=255, blank=True, null=True)
    importance = models.IntegerField(blank=True, null=True)
    sensitivity = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    body = models.ForeignKey(Bodys, blank=True, null=True)
    taskitem = models.ForeignKey('self', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'task_items'


class TaskStatusCallbackConfigs(models.Model):
    version = models.IntegerField()
    title = models.CharField(max_length=255, blank=True, null=True)
    task_id = models.IntegerField(blank=True, null=True)
    type_of_candidate = models.IntegerField(blank=True, null=True)
    entity_type = models.IntegerField(blank=True, null=True)
    entity_id = models.IntegerField(blank=True, null=True)
    task_status_api_action = models.IntegerField(blank=True, null=True)
    task_status = models.IntegerField(blank=True, null=True)
    next_action_valule = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'task_status_callback_configs'


class Tasks(models.Model):
    version = models.IntegerField()
    task_type_id = models.IntegerField()
    type_of_owner = models.IntegerField(blank=True, null=True)
    estimated_work_hours = models.FloatField(blank=True, null=True)
    status_id = models.IntegerField()
    subject = models.CharField(max_length=255, blank=True, null=True)
    body = models.CharField(max_length=255, blank=True, null=True)
    additional_work_hours = models.FloatField(blank=True, null=True)
    start_date = models.DateTimeField(blank=True, null=True)
    due_date = models.DateTimeField(blank=True, null=True)
    completion_date = models.DateTimeField(blank=True, null=True)
    actual_work_hours = models.FloatField(blank=True, null=True)
    user_id = models.IntegerField()
    job_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'tasks'


class Technologys(models.Model):
    technology_id = models.IntegerField()
    order_number = models.IntegerField()
    occurrence_count = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    candidate = models.ForeignKey(Candidates, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'technologys'


class TemplateObjectTypes(models.Model):
    type_code = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    template = models.ForeignKey('Templates', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'template_object_types'


class TemplateWordReplacers(models.Model):
    version = models.IntegerField()
    template_word_id_field = models.CharField(max_length=255)
    template_word_to_map = models.CharField(max_length=255)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'template_word_replacers'


class Templates(models.Model):
    version = models.IntegerField()
    template_name = models.CharField(max_length=150, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    is_domain = models.IntegerField()
    target_type = models.IntegerField(blank=True, null=True)
    place_owner = models.IntegerField(blank=True, null=True)
    file_id = models.IntegerField(blank=True, null=True)
    xml_content = models.TextField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'templates'


class TemporaryMailObjects(models.Model):
    version = models.IntegerField()
    bcc = models.CharField(max_length=255, blank=True, null=True)
    cc = models.CharField(max_length=255, blank=True, null=True)
    sender_email_ids = models.CharField(max_length=255, blank=True, null=True)
    is_body_html = models.IntegerField()
    subject = models.CharField(max_length=255, blank=True, null=True)
    receiver_email_ids = models.CharField(max_length=255, blank=True, null=True)
    body = models.TextField(blank=True, null=True)
    sent_count = models.IntegerField(blank=True, null=True)
    failed_date = models.DateTimeField(blank=True, null=True)
    display_name = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'temporary_mail_objects'


class TenantContracts(models.Model):
    version = models.IntegerField()
    tenant_id = models.IntegerField()
    no_of_modules = models.IntegerField(blank=True, null=True)
    initial_price = models.BigIntegerField(blank=True, null=True)
    validity_period = models.IntegerField(blank=True, null=True)
    from_date = models.DateTimeField(blank=True, null=True)
    to_date = models.DateTimeField(blank=True, null=True)
    invoice_period = models.IntegerField(blank=True, null=True)
    billing_plan_id = models.IntegerField(blank=True, null=True)
    discount = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'tenant_contracts'


class TenantEntityAverageSizes(models.Model):
    version = models.IntegerField()
    tenant_id = models.IntegerField()
    entity_name = models.CharField(max_length=255, blank=True, null=True)
    avg_row_size = models.FloatField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'tenant_entity_average_sizes'


class TenantEntityDefs(models.Model):
    property_id = models.IntegerField(blank=True, null=True)
    label = models.CharField(max_length=255, blank=True, null=True)
    is_visible = models.IntegerField(blank=True, null=True)
    validation_rule_name = models.CharField(max_length=255, blank=True, null=True)
    sequence = models.IntegerField(blank=True, null=True)
    is_custom_catalog = models.IntegerField()
    catalog_master_name = models.CharField(max_length=255, blank=True, null=True)
    is_visible_in_grid = models.IntegerField(blank=True, null=True)
    is_visible_in_search = models.IntegerField(blank=True, null=True)
    is_required = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    tenantentityfield = models.ForeignKey('TenantEntityFields', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tenant_entity_defs'


class TenantEntityFields(models.Model):
    version = models.IntegerField()
    entity_info_id = models.IntegerField(blank=True, null=True)
    entity = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'tenant_entity_fields'


class TenantInvoices(models.Model):
    version = models.IntegerField()
    tenant_id = models.IntegerField()
    from_date = models.DateTimeField(blank=True, null=True)
    to_date = models.DateTimeField(blank=True, null=True)
    total_amount = models.FloatField()
    no_of_new_candidates = models.IntegerField()
    no_of_new_sources = models.IntegerField()
    db_usage = models.FloatField()
    down_load_size = models.FloatField()
    total_no_of_users = models.IntegerField()
    new_users_created = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'tenant_invoices'


class TenantLoggings(models.Model):
    action_name = models.CharField(max_length=255, blank=True, null=True)
    request_time = models.DateTimeField(blank=True, null=True)
    response_time = models.DateTimeField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField()
    response_size = models.FloatField()
    created_on = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tenant_loggings'


class TenantValidations(models.Model):
    version = models.IntegerField()
    validator = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    tenantentitydef = models.ForeignKey(TenantEntityDefs, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tenant_validations'


class Tenants(models.Model):
    version = models.IntegerField()
    tenant_name = models.CharField(max_length=255, blank=True, null=True)
    alias = models.CharField(max_length=50, blank=True, null=True)
    domain_model = models.IntegerField(blank=True, null=True)
    splash_screen = models.TextField(blank=True, null=True)
    welcome_text = models.CharField(max_length=255, blank=True, null=True)
    tenant_type = models.IntegerField(blank=True, null=True)
    industry_id = models.IntegerField()
    category_id = models.IntegerField()
    location_id = models.IntegerField(blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    longitude = models.CharField(max_length=255, blank=True, null=True)
    latitude = models.CharField(max_length=255, blank=True, null=True)
    tenant_rank_id = models.IntegerField(blank=True, null=True)
    is_clms_enabled = models.IntegerField(blank=True, null=True)
    true_false2 = models.IntegerField(blank=True, null=True)
    true_false1 = models.IntegerField(blank=True, null=True)
    integer5 = models.IntegerField(blank=True, null=True)
    integer4 = models.IntegerField(blank=True, null=True)
    integer3 = models.IntegerField(blank=True, null=True)
    integer2 = models.IntegerField(blank=True, null=True)
    integer1 = models.IntegerField(blank=True, null=True)
    text5 = models.CharField(max_length=50, blank=True, null=True)
    text4 = models.CharField(max_length=50, blank=True, null=True)
    text3 = models.CharField(max_length=50, blank=True, null=True)
    text2 = models.CharField(max_length=50, blank=True, null=True)
    text1 = models.CharField(max_length=50, blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    presentation = models.ForeignKey(Presentations, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tenants'


class TenantsMenuItems(models.Model):
    is_public = models.IntegerField()
    sequence = models.IntegerField()
    menu_name = models.CharField(max_length=255, blank=True, null=True)
    url = models.CharField(max_length=255, blank=True, null=True)
    module_id = models.IntegerField(blank=True, null=True)
    html_content = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    tenant = models.ForeignKey(Tenants, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tenants_menu_items'


class TenantsModules(models.Model):
    is_visible = models.IntegerField()
    module_id = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    tenant = models.ForeignKey(Tenants, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tenants_modules'


class TestGroupInfos(models.Model):
    version = models.IntegerField()
    group_id = models.IntegerField()
    total_time = models.IntegerField()
    break_time = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    test = models.ForeignKey('Tests', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'test_group_infos'


class TestOwners(models.Model):
    version = models.IntegerField()
    user_id = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    test = models.ForeignKey('Tests', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'test_owners'


class TestPapers(models.Model):
    question_paper_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    test = models.ForeignKey('Tests', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'test_papers'


class TestQuestionInfos(models.Model):
    question_id = models.IntegerField(blank=True, null=True)
    mark = models.FloatField(blank=True, null=True)
    incorrect_mark = models.FloatField(blank=True, null=True)
    question_tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    test = models.ForeignKey('Tests', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'test_question_infos'


class TestResultInfos(models.Model):
    coding_question_attachment_id = models.IntegerField(blank=True, null=True)
    coding_output = models.TextField(blank=True, null=True)
    coding_error_message = models.TextField(blank=True, null=True)
    coding_error_code = models.IntegerField(blank=True, null=True)
    coding_memory_usage = models.FloatField(blank=True, null=True)
    coding_execution_time = models.FloatField(blank=True, null=True)
    coding_obtained_mark = models.FloatField(blank=True, null=True)
    coding_signal = models.IntegerField(blank=True, null=True)
    coding_signal_message = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    testresult = models.ForeignKey('TestResults', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'test_result_infos'


class TestResults(models.Model):
    question_id = models.IntegerField()
    answer_string = models.CharField(max_length=255, blank=True, null=True)
    is_subjective = models.IntegerField()
    obtained_marks = models.FloatField(blank=True, null=True)
    time_spent = models.FloatField(blank=True, null=True)
    section_id = models.IntegerField(blank=True, null=True)
    question_tenant_id = models.IntegerField(blank=True, null=True)
    coding_language_id = models.IntegerField(blank=True, null=True)
    result_status = models.IntegerField(blank=True, null=True)
    code_server_token = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    testuser = models.ForeignKey('TestUsers', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'test_results'


class TestSectionInfos(models.Model):
    section_id = models.IntegerField()
    mark = models.FloatField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    test = models.ForeignKey('Tests', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'test_section_infos'


class TestUserGroupInfos(models.Model):
    group_id = models.IntegerField()
    time_spent = models.FloatField(blank=True, null=True)
    is_selected_optional_group = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    testuser = models.ForeignKey('TestUsers', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'test_user_group_infos'


class TestUserLoginInfos(models.Model):
    login_time = models.DateTimeField(blank=True, null=True)
    client_system_info = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    testuser = models.ForeignKey('TestUsers', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'test_user_login_infos'


class TestUsers(models.Model):
    candidate_id = models.IntegerField(blank=True, null=True)
    total_score = models.FloatField(blank=True, null=True)
    percentage = models.FloatField(blank=True, null=True)
    candidate_regn_id = models.CharField(max_length=255, blank=True, null=True)
    login_time = models.DateTimeField(blank=True, null=True)
    log_out_time = models.DateTimeField(blank=True, null=True)
    login_id = models.CharField(max_length=255, blank=True, null=True)
    password = models.CharField(max_length=255, blank=True, null=True)
    status = models.IntegerField(blank=True, null=True)
    is_login_info_sent = models.IntegerField()
    is_test_user_exported = models.IntegerField(blank=True, null=True)
    normal_distribution = models.FloatField(blank=True, null=True)
    percentile = models.FloatField(blank=True, null=True)
    correct_answers = models.IntegerField(blank=True, null=True)
    in_correct_answers = models.IntegerField(blank=True, null=True)
    un_attended_questions = models.IntegerField(blank=True, null=True)
    is_password_disabled = models.IntegerField()
    rank = models.IntegerField(blank=True, null=True)
    total_no_of_subjective_questions = models.IntegerField(blank=True, null=True)
    is_partially_evaluated = models.IntegerField(blank=True, null=True)
    enable_last_session = models.IntegerField()
    is_dummy = models.IntegerField(blank=True, null=True)
    is_candidate_registered = models.IntegerField(blank=True, null=True)
    client_system_info = models.CharField(max_length=255, blank=True, null=True)
    is_offline = models.IntegerField()
    candidate_name = models.CharField(max_length=255, blank=True, null=True)
    candidate_email = models.CharField(max_length=255, blank=True, null=True)
    time_spent = models.FloatField(blank=True, null=True)
    reactivated_count = models.IntegerField()
    time_stamp = models.DateTimeField(blank=True, null=True)
    is_submission_failed = models.IntegerField(blank=True, null=True)
    current_employer_id = models.IntegerField(blank=True, null=True)
    current_employer_text = models.CharField(max_length=255, blank=True, null=True)
    total_experience = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    test = models.ForeignKey('Tests', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'test_users'


class Tests(models.Model):
    version = models.IntegerField()
    name = models.CharField(max_length=255)
    valid_from = models.DateTimeField()
    experience_from = models.IntegerField()
    expertise_id = models.IntegerField(blank=True, null=True)
    technology = models.CharField(max_length=255)
    no_of_candidates = models.IntegerField(blank=True, null=True)
    is_approved = models.IntegerField(blank=True, null=True)
    valid_to = models.DateTimeField()
    test_duration = models.FloatField(blank=True, null=True)
    test_code = models.CharField(max_length=255, blank=True, null=True)
    permissible_late_time = models.IntegerField(blank=True, null=True)
    test_start_time = models.DateTimeField(blank=True, null=True)
    test_end_time = models.DateTimeField(blank=True, null=True)
    is_all_time_permissible = models.IntegerField()
    is_accepted = models.IntegerField(blank=True, null=True)
    no_of_questions_per_page = models.IntegerField(blank=True, null=True)
    about_test = models.TextField(blank=True, null=True)
    purpose_of_test = models.TextField(blank=True, null=True)
    instructions = models.TextField(blank=True, null=True)
    hierarchy_id = models.IntegerField(blank=True, null=True)
    experience_to = models.IntegerField(blank=True, null=True)
    question_paper_id = models.IntegerField(blank=True, null=True)
    correct = models.FloatField(blank=True, null=True)
    in_correct = models.FloatField(blank=True, null=True)
    left_entries = models.FloatField(blank=True, null=True)
    max_marks = models.FloatField(blank=True, null=True)
    instant_evaluation = models.IntegerField()
    mean = models.FloatField(blank=True, null=True)
    standard_deviation = models.FloatField(blank=True, null=True)
    group_wise_timing = models.IntegerField()
    question_randomizing = models.IntegerField()
    que_paper_tenantid = models.IntegerField(blank=True, null=True)
    is_test_active = models.IntegerField()
    primary_owner_id = models.IntegerField()
    template_id = models.IntegerField(blank=True, null=True)
    automate_tagging = models.IntegerField()
    selecting_criteria = models.FloatField(blank=True, null=True)
    is_instant_result = models.IntegerField(blank=True, null=True)
    is_online = models.IntegerField(blank=True, null=True)
    blue_print_id = models.IntegerField(blank=True, null=True)
    event_name = models.CharField(max_length=255, blank=True, null=True)
    is_option_randomize = models.IntegerField()
    is_shuffle_question_order = models.IntegerField()
    number_of_question_papers = models.IntegerField(blank=True, null=True)
    header = models.CharField(max_length=255, blank=True, null=True)
    footer = models.CharField(max_length=255, blank=True, null=True)
    end_instruction = models.CharField(max_length=255, blank=True, null=True)
    is_published = models.IntegerField(blank=True, null=True)
    logo_file_id = models.IntegerField(blank=True, null=True)
    number_of_attachments = models.IntegerField()
    presentation_file_id = models.IntegerField(blank=True, null=True)
    is_sent_for_approval = models.IntegerField(blank=True, null=True)
    event_details = models.CharField(max_length=255, blank=True, null=True)
    rejecting_criteria = models.FloatField(blank=True, null=True)
    is_manual_selection_criteria = models.IntegerField()
    type_of_test = models.IntegerField()
    config = models.TextField(blank=True, null=True)
    ip_configuration_text = models.CharField(max_length=255, blank=True, null=True)
    ip_address_config = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    multiplicity_offline = models.IntegerField(blank=True, null=True)
    multiplicity_online = models.IntegerField(blank=True, null=True)
    page_number_position = models.IntegerField(blank=True, null=True)
    logo_position = models.IntegerField(blank=True, null=True)
    type_of_shortlisting_criteria = models.IntegerField(blank=True, null=True)
    true_false2 = models.IntegerField(blank=True, null=True)
    true_false1 = models.IntegerField(blank=True, null=True)
    integer5 = models.IntegerField(blank=True, null=True)
    integer4 = models.IntegerField(blank=True, null=True)
    integer3 = models.IntegerField(blank=True, null=True)
    integer2 = models.IntegerField(blank=True, null=True)
    integer1 = models.IntegerField(blank=True, null=True)
    text5 = models.CharField(max_length=50, blank=True, null=True)
    text4 = models.CharField(max_length=50, blank=True, null=True)
    text3 = models.CharField(max_length=50, blank=True, null=True)
    text2 = models.CharField(max_length=50, blank=True, null=True)
    text1 = models.CharField(max_length=50, blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'tests'


class UniqueRandomizedQuestions(models.Model):
    version = models.IntegerField()
    question_id = models.IntegerField(blank=True, null=True)
    section_id = models.IntegerField(blank=True, null=True)
    question_tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    testuser = models.ForeignKey(TestUsers, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'unique_randomized_questions'


class UserArticles(models.Model):
    version = models.IntegerField()
    article_id = models.IntegerField()
    user_id = models.IntegerField()
    is_enable = models.IntegerField(blank=True, null=True)
    is_hidden_to_user = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'user_articles'


class UserEvents(models.Model):
    version = models.IntegerField()
    subject = models.CharField(max_length=255, blank=True, null=True)
    description = models.CharField(max_length=255, blank=True, null=True)
    link_to_id = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    event_type = models.IntegerField(blank=True, null=True)
    actor_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'user_events'


class UserGroups(models.Model):
    user_id = models.IntegerField(blank=True, null=True)
    department_id = models.IntegerField(blank=True, null=True)
    group = models.ForeignKey(Groups, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'user_groups'


class UserOwners(models.Model):
    version = models.IntegerField()
    entity_type_id = models.IntegerField(blank=True, null=True)
    user_id = models.IntegerField(blank=True, null=True)
    entity_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'user_owners'


class UserProfiles(models.Model):
    property_values_binary = models.TextField(blank=True, null=True)
    property_name = models.CharField(max_length=255, blank=True, null=True)
    property_values_string = models.CharField(max_length=255, blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    user = models.ForeignKey('Users', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'user_profiles'


class UserRoles(models.Model):
    user = models.ForeignKey('Users', blank=True, null=True)
    role = models.ForeignKey(Roles, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'user_roles'


class Users(models.Model):
    version = models.IntegerField()
    login_name = models.CharField(max_length=25, blank=True, null=True)
    password = models.CharField(max_length=255, blank=True, null=True)
    password_question = models.CharField(max_length=100, blank=True, null=True)
    password_answer = models.CharField(max_length=50, blank=True, null=True)
    is_approved = models.IntegerField()
    last_login_date = models.DateTimeField(blank=True, null=True)
    is_on_line = models.IntegerField()
    is_locked_out = models.IntegerField()
    signature = models.CharField(max_length=255, blank=True, null=True)
    is_system = models.IntegerField()
    email1 = models.CharField(max_length=50, blank=True, null=True)
    email2 = models.CharField(max_length=50, blank=True, null=True)
    first_name = models.CharField(max_length=75, blank=True, null=True)
    last_name = models.CharField(max_length=75, blank=True, null=True)
    middle_name = models.CharField(max_length=75, blank=True, null=True)
    mobile1 = models.CharField(max_length=20, blank=True, null=True)
    phone_office = models.CharField(max_length=255, blank=True, null=True)
    phone_residence = models.CharField(max_length=20, blank=True, null=True)
    salutation = models.IntegerField()
    password_hash = models.CharField(max_length=255, blank=True, null=True)
    is_admin = models.IntegerField()
    type_of_user = models.IntegerField(blank=True, null=True)
    password_question_id = models.IntegerField(blank=True, null=True)
    address1 = models.CharField(max_length=255, blank=True, null=True)
    address2 = models.CharField(max_length=255, blank=True, null=True)
    address3 = models.CharField(max_length=255, blank=True, null=True)
    current_login_date = models.DateTimeField(blank=True, null=True)
    email_password = models.CharField(max_length=255, blank=True, null=True)
    is_pop3_listener = models.IntegerField(blank=True, null=True)
    is_email_extraction_required = models.IntegerField(blank=True, null=True)
    is_password_auto_generated = models.IntegerField(blank=True, null=True)
    country_code = models.CharField(max_length=255, blank=True, null=True)
    is_master_vendor_user = models.IntegerField(blank=True, null=True)
    last_password_changed_date = models.DateTimeField(blank=True, null=True)
    browser_details = models.CharField(max_length=255, blank=True, null=True)
    operating_system_details = models.CharField(max_length=255, blank=True, null=True)
    last_login_ip = models.CharField(max_length=255, blank=True, null=True)
    vendor_id = models.IntegerField(blank=True, null=True)
    is_disabled = models.IntegerField(blank=True, null=True)
    user_name = models.CharField(max_length=50, blank=True, null=True)
    login_failed_count = models.IntegerField()
    is_archived = models.IntegerField()
    department_id = models.IntegerField(blank=True, null=True)
    designation_id = models.IntegerField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    location_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'users'


class Validations(models.Model):
    version = models.IntegerField()
    validator = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)
    entitiesproperty = models.ForeignKey(EntitiesPropertys, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'validations'


class VendorConfigurations(models.Model):
    service_type_id = models.IntegerField(blank=True, null=True)
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    vendor = models.ForeignKey('Vendors', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'vendor_configurations'


class VendorOwners(models.Model):
    user_id = models.IntegerField()
    source_id = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    job = models.ForeignKey(Jobs, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'vendor_owners'


class Vendors(models.Model):
    version = models.IntegerField()
    name = models.CharField(max_length=255, blank=True, null=True)
    email = models.CharField(max_length=100, blank=True, null=True)
    contact_number = models.CharField(max_length=20, blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    location_id = models.IntegerField(blank=True, null=True)
    contract_start = models.DateTimeField(blank=True, null=True)
    contract_end = models.DateTimeField(blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'vendors'


class Widgets(models.Model):
    version = models.IntegerField()
    header = models.CharField(max_length=255, blank=True, null=True)
    widget_type = models.IntegerField(blank=True, null=True)
    hposition = models.IntegerField(blank=True, null=True)
    vposition = models.IntegerField(blank=True, null=True)
    widget_position = models.IntegerField()
    widget_name = models.CharField(max_length=255, blank=True, null=True)
    tenant_id = models.IntegerField(blank=True, null=True)
    published_on = models.DateTimeField(blank=True, null=True)
    published_by = models.IntegerField(blank=True, null=True)
    is_active = models.IntegerField(blank=True, null=True)
    is_draft = models.IntegerField(blank=True, null=True)
    is_archived = models.IntegerField(blank=True, null=True)
    is_alive = models.IntegerField()
    created_by = models.IntegerField()
    created_on = models.DateTimeField()
    modified_by = models.IntegerField(blank=True, null=True)
    modified_on = models.DateTimeField(blank=True, null=True)
    is_deleted = models.IntegerField()
    guid = models.CharField(max_length=16)

    class Meta:
        managed = False
        db_table = 'widgets'
