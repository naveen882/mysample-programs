def scraper_example(a, b):
	return a + b


