from django.db import models
from users.models import UserProfile #what ever userprofile to be derived from
from django import forms


#AG - We should set this up from 1 to 10 - we may need more  levels when we go for adaptive tests
class DIFFICULTY:
    EASY = 1
    MODERATE = 2
    DIFFICULT = 3

DIFFICULTY_CHOICE = (
         (DIFFICULTY.MODERATE, 'Moderate'),
         (DIFFICULTY.EASY, 'Easy'),
         (DIFFICULTY.DIFFICULT,'Difficult')
      )


class QUESTION_FORMAT:
    MULTIPLE_CHOICE = 0 #AG change this to MCQ_single_ans
    MULTIPLE_ANSWER = 1 #AG change to MCQ_multi_ans
    TRUE_FALSE = 2
    ORDER = 3
    BLANKS = 4
    MATCH = 5
    SHORT_ANSWER = 6
    LONG_ANSWER = 7
    NUMERICAL = 8
    FILE_RESPONSE = 9 
    AUDIO_RECORDING = 10
    MULTI_PART_QUESTION = 11
    SURVEY_QUESTION = 12
    RESOURCE_OPTION = 13

QUESTION_FORMAT_CHOICES = (
   (QUESTION_FORMAT.MULTIPLE_CHOICE , 'Multiple choice' ), #AG MCQ 
   (QUESTION_FORMAT.MULTIPLE_ANSWER ,  'Multiple answer'), #AG MCQ multi answers
   (QUESTION_FORMAT.TRUE_FALSE , 'True/False'),
   (QUESTION_FORMAT.SHORT_ANSWER , 'Short answer'),
   (QUESTION_FORMAT.RESOURCE_OPTION, 'Resource Options')
)


class RESOURCE:
    DOCUMENTS = 1
    VIDEO = 2
    IMAGE = 3
    AUDIO = 4
    SCORM = 5 #AG What is scorm? 
    RECORDAUDIO = 6

RESOURCE_FORMAT = (
( RESOURCE.DOCUMENTS, 'Documents'),
( RESOURCE.IMAGE, 'Image'),
( RESOURCE.AUDIO, 'Audio'),
( RESOURCE.VIDEO, 'Video'),
( RESOURCE.SCORM, 'SCORM'),
( RESOURCE.RECORDAUDIO, 'Record Audio')
)


ANSWER_AVAILABLE= (
( 0, 'No'),
( 1, 'Yes')
)


class Option(models.Model):
   text_format = models.IntegerField(default=1)
   index = models.CharField(max_length = 8)
   option = models.TextField()
   option_b = models.TextField()
   feedback = models.TextField()

class Answer(models.Model):
   text_format = models.IntegerField(default=1)
   answer  = models.TextField()
   index = models.CharField(max_length = 8, null = True, blank = True)
   keyword_exp = models.CharField(max_length = 1024, null = True, blank = True)

class Resource(models.Model):
    content = models.IntegerField(blank=True, null=True)

class Question(models.Model):
   created_by = models.ForeignKey(UserProfile)    #which ever user table
   modified_by = models.ForeignKey(UserProfile,related_name='modified_by')#which ever user table
   #access = models.IntegerField(choices=ACCESS_CHOICES)
   created_timestamp = models.DateTimeField(auto_now_add=True)
   modified_timestamp = models.DateTimeField(auto_now_add=True, auto_now=True)
   Qtype = models.IntegerField(choices=QUESTION_FORMAT_CHOICES)
   question = models.TextField()
   subject = models.ForeignKey(Subject, null = True, blank = True) #type of question
   subtopic = models.ManyToManyField(SubTopic) #subtype of question
   answer_available = models.IntegerField(choices=ANSWER_AVAILABLE)
   options = models.ManyToManyField(Option)
   answers = models.ManyToManyField(Answer)
   resource = models.ForeignKey(Resource, null = True, blank = True)
   marks = models.IntegerField(null = True, blank = True) #default marks to be set yet
   difficulty = models.IntegerField(default=1, choices = DIFFICULTY_CHOICE, null = True, blank = True)
   hint = models.CharField(max_length=512, null=True,blank=True)
   time = models.CharField(max_length=8, null=True,blank=True)
	is_final = models.BooleanField(default=0)       #Question finalized by reviewer
	edited_by = models.ForeignKey(UserProfile)    #which ever user table
	reviewed_by = models.ForeignKey(UserProfile)    #which ever user table

class QuestionPaper(models.Model): 
   created_by = models.ForeignKey(UserProfile)    #which ever user table
   modified_by = models.ForeignKey(UserProfile,related_name='modified_by')#which ever user table
   #access = models.IntegerField(choices=ACCESS_CHOICES)
   created_timestamp = models.DateTimeField(auto_now_add=True)
   modified_timestamp = models.DateTimeField(auto_now_add=True, auto_now=True)
   Qtype = models.IntegerField(choices=QUESTION_FORMAT_CHOICES)
   question = models.TextField()
   subject = models.ForeignKey(Subject, null = True, blank = True) #type of question
   subtopic = models.ManyToManyField(SubTopic) #subtype of question
   answer_available = models.IntegerField(choices=ANSWER_AVAILABLE)
   options = models.ManyToManyField(Option)
   answers = models.ManyToManyField(Answer)
   resource = models.ForeignKey(Resource, null = True, blank = True)
   marks = models.IntegerField(null = True, blank = True) #default marks to be set yet
   difficulty = models.IntegerField(default=1, choices = DIFFICULTY_CHOICE, null = True, blank = True)
   hint = models.CharField(max_length=512, null=True,blank=True)
   time = models.CharField(max_length=8, null=True,blank=True)
	is_final = models.BooleanField(default=0)       #Question finalized by reviewer
	reviewed_by = models.ForeignKey(UserProfile)    #which ever user table
