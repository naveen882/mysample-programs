from django.conf.urls import include, url
from django.contrib import admin
from  . import views

urlpatterns = [
	 url(r'^login/$',views.login ),
	 url(r'^files/$',views.get_files),
	 url(r'^listusers/$',views.list_users),
	 url(r'^db1save/$',views.db1save),
	 url(r'^db2save/$',views.db2save),
	 url(r'^app/$',views.app ),

	 url(r'^candidatesave/$',views.candidate_create),
	 #url(r'^getbycandidateid/(?P<m_id>[0-9]+)$',views.candidate_create),
	 url(r'^getbycandidateid/(?P<m_id>[0-9]+)/(?P<token>[0-9a-z-]+)$',views.candidate_create),
	 url(r'^getallcandidates/$',views.candidate_create),
	 url(r'^getassessment_candidate/(?P<m_id>[0-9]+)/$',views.get_candidate_assessment),

	 url(r'^candidateeducationsave/$',views.candidate_educationprofiles_create),
	 url(r'^getbycandidateeducationid/(?P<m_id>[0-9]+)$',views.candidate_create),
	 url(r'^getallcandidateseducationdetails/$',views.candidate_educationprofiles_create),

	 url(r'^candidateworkprofilesave/$',views.candidate_work_profiles),
	 url(r'^getbycandidateworkprofileid/(?P<m_id>[0-9]+)$',views.candidate_work_profiles),
	 url(r'^getallcandidatesworkprofiles/$',views.candidate_work_profiles),

	 url(r'^candidatelocationsave/$',views.candidate_location_preferences),
	 url(r'^getbycandidatelocationid/(?P<m_id>[0-9]+)$',views.candidate_location_preferences),
	 url(r'^getallcandidateslocations/$',views.candidate_location_preferences),

	 url(r'^attachmentssave/$',views.attachments),
	 url(r'^getbycandidateattachmentsid/(?P<m_id>[0-9]+)$',views.attachments),
	 url(r'^getallcandidatesattachments/$',views.attachments),

	 url(r'^candidatesocialnetworkdetailssave/$',views.candidate_social_network_details),
	 url(r'^candidatesocialnetworkdetailsid/(?P<m_id>[0-9]+)$',views.candidate_social_network_details),
	 url(r'^getallcandidatesocialnetworkdetails/$',views.attachments),


	 url(r'^candidatefilessave/$',views.files),
	 url(r'^getbycandidatefilesid/(?P<m_id>[0-9]+)$',views.files),
	 url(r'^getallcandidatesfiles/$',views.files),

	 url(r'^candidatefulltextssave/$',views.candidate_full_texts),
	 url(r'^getbycandidatefulltextsid/(?P<m_id>[0-9]+)$',views.candidate_full_texts),
	 url(r'^getallcandidatefulltexts/$',views.candidate_full_texts),

	 url(r'^candidatesalaryssave/$',views.candidate_salarys),
	 url(r'^getbycandidatesalarysid/(?P<m_id>[0-9]+)$',views.candidate_salarys),
	 url(r'^getallcandidatesalarys/$',views.candidate_salarys),

	 url(r'^candidatesocialnetworkdetailssave/$',views.candidate_salarys),
	 url(r'^candidatesocialnetworkdetailsid/(?P<m_id>[0-9]+)$',views.candidate_salarys),
	 url(r'^getallcandidatesocialnetworkdetails/$',views.candidate_salarys),

	 url(r'^candidate_assesment/(?P<c_id>[0-9]+)/$',views.candidate_assesment),
	 url(r'^candidate_assesment/(?P<c_id>[0-9]+)/(?P<test_id>[0-9]+)/$',views.candidate_assesment),
	 url(r'^actionplanning/(?P<c_id>[0-9]+)/$',views.actionplanning),
	 url(r'^personaldevelopmenttips/(?P<c_id>[0-9]+)/$',views.personaldevelopmenttips),
	 url(r'^potentialtargetcompanies/(?P<c_id>[0-9]+)/$',views.potentialtargetcompanies),

	 # For all the following APIs
	 # i)   api/v1/locationwise/eventreportsfor/ 
	 # ii)  api/v1/jobwise/eventreportsfor/ 
	 # iii) api/v1/locationwise/collegereportsfor/ 
	 # 1. -1 is taken as wild-card param.
	 # 2. As long as the candidate has gone through some step in the hiring process, he is considered a participant i.e., 
	 #    a candidate's current status might say Registered(which is generally the first step but, he might have gone to Screening 
	 #    and again might have moved back to Registered state(the first state). In such a case, he is still a participant. 
	 # 3. Offered count is based on Offer stage only. The status within Offered stage is of no concern here.

	 #ZoneId, and ProviceId represent the location/CITY where the RecruitEvent is held
	 url(r'^api/v1/locationwise/eventreportsfor/(?P<zone_id>\-1|\d+)/(?P<province_id>\-1|\d+)/(?P<reqt_id>\-1|\d+)/(?P<ev_type>\-1|\d+)/$',views.get_locationwise_ev_reports_for_reqt),
	 #ZoneId, and ProviceId represent the location/CITY of College where the event is held for the given RequirementId. 
	 #Basically, all the colleges which are in
	 # all the CITYs(locations) within the given Province and Zone are considered for report generation. 
	 url(r'^api/v1/locationwise/collegereportsfor/(?P<zone_id>\-1|\d+)/(?P<province_id>\-1|\d+)/(?P<reqt_id>\-1|\d+)/$',views.get_eventlocationwise_college_reports_for_reqt),
	 #dates in the foll form YYYY-MM-DD and represent the dates when the recruit-event is held
	 url(r'^api/v1/jobwise/eventreportsfor/(?P<reqt_id>\-1|\d+)/(?P<job_id>\-1|\d+)//(?P<ev_type>\-1|\d+)/(?P<date_from>-1|\d{4}\-\d{2}\-\d{2})/(?P<date_to>-1|\d{4}\-\d{2}\-\d{2})/$',views.get_jobrolewise_ev_reports_for_reqt),
]
