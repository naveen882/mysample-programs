echo "Tenant " $1 
echo "UserName/Email " $2 
echo "Password" $3
mysql -u root -pHire!!123 --database='hpro1' -e "insert into proc_tenant_credentials (tenant_id,userName,password) VALUES ($1, '$2','$3')";

