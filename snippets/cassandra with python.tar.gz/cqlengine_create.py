# To run this script you need python libraries to be installed
# cassandra-driver
# cqlengine
# and you need apache cassandra installed and cassandra services has to start

import uuid
from cqlengine.models import Model
from cqlengine.columns import Integer, Text, UUID


from cqlengine import connection as cql_connection
from cqlengine.management import create_keyspace, sync_table


NOSQL_SERVERS = ['127.0.0.1']
CASSANDRA_KEYSPACE = 'sample_db'

class Employee(Model):
    emp_id = UUID(primary_key=True, default=uuid.uuid4)
    emp_name = Text()
    emp_age = Integer()


cql_connection.setup(NOSQL_SERVERS, CASSANDRA_KEYSPACE)
create_keyspace(CASSANDRA_KEYSPACE, replication_factor=1, strategy_class='SimpleStrategy')
sync_table(Employee)


ep = Employee.create(emp_name='abc', emp_age=20)
ep.save()
ep1 = Employee.create(emp_name='xyz', emp_age=21)
ep1.save()

